#!/usr/bin/env bash
set -euo pipefail

echo "=================================================="
echo "  Installer TeleBalas - Bot Auto-Reply Telegram   "
echo "=================================================="
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "[ERROR] Node.js tidak ditemukan. Silakan aktifkan Node.js 18+ di cPanel (Setup Node.js App)."
  exit 1
fi

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "[ERROR] Versi Node.js minimal 18. Versi terdeteksi: $(node -v)"
  exit 1
fi

echo "[1/4] Memeriksa & memasang dependensi Node.js..."
if [ -f "dist/index.html" ] && [ -f "app.cjs" ]; then
  npm install --omit=dev
else
  npm install
  npm run build
  npx esbuild server.ts --bundle --platform=node --format=cjs --outfile=app.cjs --external:express --external:dotenv --external:telegram --external:vite --external:jszip --external:esbuild --external:qrcode
fi

echo "[2/4] Menyiapkan direktori database (data/store.json)..."
mkdir -p data
chmod 700 data
if [ ! -f "data/store.json" ] && [ -f "database/telebalas-database.json" ]; then
  cp database/telebalas-database.json data/store.json
fi
if [ -f "data/store.json" ]; then
  chmod 600 data/store.json
fi

echo "[3/4] Menyiapkan file konfigurasi .env..."
if [ ! -f ".env" ]; then
  SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  ADMIN_PIN_VALUE=""
  if [ -t 0 ]; then
    read -r -p "Masukkan PIN Admin (4-8 digit, kosongkan untuk atur lewat web): " ADMIN_PIN_VALUE || true
  fi
  cat > .env <<EOF
NODE_ENV=production
PORT=3000
ADMIN_SESSION_SECRET=$SECRET
ADMIN_PIN=$ADMIN_PIN_VALUE
EOF
  chmod 600 .env
  echo "File .env berhasil dibuat."
else
  echo "File .env sudah ada, tidak ditimpa."
fi

echo "[4/4] Instalasi selesai!"
echo ""
echo "Cara menjalankan di cPanel (Setup Node.js App):"
echo "  - Application root         : $(pwd)"
echo "  - Application startup file : app.cjs"
echo "  - Application mode         : Production"
echo "  Lalu klik tombol RESTART di cPanel Node.js App."
echo ""
echo "Atau jalankan langsung via terminal / PM2:"
echo "  NODE_ENV=production node app.cjs"
echo "=================================================="
