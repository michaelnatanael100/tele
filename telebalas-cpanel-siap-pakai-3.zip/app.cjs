var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_config = require("dotenv/config");
var import_express = __toESM(require("express"), 1);
var import_node_crypto5 = __toESM(require("node:crypto"), 1);
var import_node_fs3 = __toESM(require("node:fs"), 1);
var import_node_path3 = __toESM(require("node:path"), 1);

// src/shared/autoReplyEngine.ts
var DEFAULT_FALLBACK_REPLY_TEXT = 'Halo {nama}, terima kasih sudah menghubungi saya di Telegram. Pesan Anda ("{pesan}") sudah diterima pada pukul {waktu} WIB dan akan segera saya balas.\n\nBerikut katalog layanan yang tersedia saat ini:\n{katalog}';
function formatRupiah(amount) {
  const safe = Number.isFinite(amount) ? Math.max(0, Math.round(amount)) : 0;
  return `Rp ${safe.toLocaleString("id-ID")}`;
}
function stockStatusLabel(status) {
  switch (status) {
    case "tersedia":
      return "Tersedia";
    case "terbatas":
      return "Stok Terbatas";
    case "habis":
      return "Stok Habis";
  }
}
function getAvailableAccountCount(product) {
  return (product.accounts ?? []).filter((a) => a.status === "available").length;
}
function validateProductAccountInput(input) {
  const errors = {};
  const email = input.email?.trim() ?? "";
  const password = input.password?.trim() ?? "";
  const extraData = input.extraData?.trim() ?? "";
  if (!email && !extraData) {
    errors.email = "Minimal isi Email/Username atau Data Lain akun.";
  } else if (email.length > 160) {
    errors.email = "Email/Username maksimal 160 karakter.";
  }
  if (password.length > 160) {
    errors.password = "Password maksimal 160 karakter.";
  }
  if (extraData.length > 1e3) {
    errors.extraData = "Data tambahan maksimal 1000 karakter.";
  }
  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}
var ORDER_COMMAND_PREFIXES = ["order", "beli", "checkout", "bayar", "pesan", "buy", "qris"];
function detectOrderIntent(text, products) {
  const clean = text.trim().toLowerCase();
  if (!clean) return null;
  const hasOrderVerb = ORDER_COMMAND_PREFIXES.some((verb) => {
    const re = new RegExp(`(?:^|\\s)${verb}(?:\\s|$)`, "i");
    return re.test(clean);
  });
  if (!hasOrderVerb) return null;
  const activeProducts = products.filter((p) => p.autoReplyEnabled);
  return activeProducts.find((product) => doesProductMatchText(product, clean)) ?? null;
}
function formatAccountDeliveryMessage(params) {
  const { buyerName, order, account } = params;
  const lines = [
    `\u2705 *Pembayaran QRIS GoPay Terverifikasi!*`,
    ``,
    `Halo ${buyerName || "Kak"}, pembayaran untuk pesanan *${order.orderCode}* sebesar *${formatRupiah(order.totalAmount)}* telah otomatis terbaca oleh sistem mutasi GoPay Merchant.`,
    ``,
    `\u{1F4E6} *Detail Produk:* ${order.productName}`
  ];
  if (account) {
    lines.push(`\u{1F510} *Detail Akun Anda:*`);
    if (account.email) lines.push(`\u2022 Email / Login: \`${account.email}\``);
    if (account.password) lines.push(`\u2022 Password: \`${account.password}\``);
    if (account.extraData) lines.push(`\u2022 Info / Data Lain: ${account.extraData}`);
  } else {
    lines.push(
      `\u{1F4CC} Pesanan Anda sudah lunas dan dicatat. Admin akan segera memproses pengiriman/aktivasi ke akun Anda.`
    );
  }
  lines.push("", "Terima kasih sudah berbelanja! Simpan data akun ini baik-baik.");
  return lines.join("\n");
}
function validateRuleInput(input) {
  const errors = {};
  if (!input.name || input.name.trim().length < 2) {
    errors.name = "Nama aturan minimal 2 karakter.";
  } else if (input.name.trim().length > 80) {
    errors.name = "Nama aturan maksimal 80 karakter.";
  }
  if (input.matchType !== "all_incoming") {
    if (!input.pattern || input.pattern.trim().length === 0) {
      errors.pattern = "Kata kunci atau pola wajib diisi.";
    } else if (input.pattern.trim().length > 300) {
      errors.pattern = "Pola maksimal 300 karakter.";
    } else if (input.matchType === "regex") {
      try {
        new RegExp(input.pattern.trim(), "u");
      } catch {
        errors.pattern = "Format ekspresi reguler (Regex) tidak valid.";
      }
    }
  }
  if (!input.replyText || input.replyText.trim().length === 0) {
    errors.replyText = "Teks balasan otomatis wajib diisi.";
  } else if (input.replyText.trim().length > 4e3) {
    errors.replyText = "Teks balasan maksimal 4000 karakter.";
  }
  if (!Number.isFinite(input.delayMs) || input.delayMs < 0 || input.delayMs > 3e4) {
    errors.delayMs = "Jeda balasan harus antara 0 hingga 30.000 ms.";
  }
  if (!Number.isFinite(input.cooldownSeconds) || input.cooldownSeconds < 0 || input.cooldownSeconds > 86400) {
    errors.cooldownSeconds = "Cooldown harus antara 0 hingga 86.400 detik.";
  }
  if (!Number.isFinite(input.priority) || input.priority < 1 || input.priority > 999) {
    errors.priority = "Prioritas harus antara 1 hingga 999.";
  }
  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}
function validateProductInput(input) {
  const errors = {};
  if (!input.name || input.name.trim().length < 2) {
    errors.name = "Nama produk minimal 2 karakter.";
  } else if (input.name.trim().length > 80) {
    errors.name = "Nama produk maksimal 80 karakter.";
  }
  if (!input.category || input.category.trim().length < 2) {
    errors.category = "Kategori produk wajib diisi.";
  }
  if (!Number.isFinite(input.price) || input.price < 0 || input.price > 1e8) {
    errors.price = "Harga produk harus antara Rp 0 hingga Rp 100.000.000.";
  }
  if (!input.duration || input.duration.trim().length === 0) {
    errors.duration = "Durasi atau satuan paket wajib diisi.";
  }
  if (!input.keywords || input.keywords.trim().length === 0) {
    errors.keywords = "Kata kunci pemicu produk wajib diisi (misal: netflix, nf).";
  }
  if (!input.replyTemplate || input.replyTemplate.trim().length === 0) {
    errors.replyTemplate = "Template balasan produk wajib diisi.";
  } else if (input.replyTemplate.trim().length > 4e3) {
    errors.replyTemplate = "Template balasan maksimal 4000 karakter.";
  }
  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}
function parseMinutes(hhmm) {
  const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(hhmm.trim());
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}
function isWithinSchedule(schedule, now = /* @__PURE__ */ new Date()) {
  if (!schedule.enabled) return true;
  const startMin = parseMinutes(schedule.startTime);
  const endMin = parseMinutes(schedule.endTime);
  if (startMin === null || endMin === null) return true;
  if (startMin === endMin) return true;
  const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
  const offset = Number.isFinite(schedule.timezoneOffsetMinutes) ? schedule.timezoneOffsetMinutes : 420;
  const localMinutes = ((utcMinutes + offset) % 1440 + 1440) % 1440;
  if (startMin < endMin) {
    return localMinutes >= startMin && localMinutes < endMin;
  }
  return localMinutes >= startMin || localMinutes < endMin;
}
function normalizeIdentifier(value) {
  return value.trim().replace(/^@/, "").toLowerCase();
}
function isInIdentifierList(senderId, senderUsername, list) {
  if (!list || list.length === 0) return false;
  const normalizedList = new Set(list.map(normalizeIdentifier).filter(Boolean));
  if (normalizedList.has(normalizeIdentifier(senderId))) return true;
  if (senderUsername && normalizedList.has(normalizeIdentifier(senderUsername))) return true;
  return false;
}
function doesRuleMatchText(rule, text) {
  const incoming = text.trim();
  if (!incoming && rule.matchType !== "all_incoming") return false;
  if (rule.matchType === "all_incoming") {
    return true;
  }
  const hay = rule.caseSensitive ? incoming : incoming.toLowerCase();
  const needleRaw = rule.pattern.trim();
  const needle = rule.caseSensitive ? needleRaw : needleRaw.toLowerCase();
  switch (rule.matchType) {
    case "exact":
      return hay === needle;
    case "contains": {
      const parts = needle.split(",").map((p) => p.trim()).filter(Boolean);
      return parts.some((part) => hay.includes(part));
    }
    case "starts_with":
      return hay.startsWith(needle);
    case "regex": {
      try {
        const flags = rule.caseSensitive ? "u" : "iu";
        const re = new RegExp(needleRaw, flags);
        return re.test(incoming);
      } catch {
        return false;
      }
    }
    default:
      return false;
  }
}
function doesProductMatchText(product, text) {
  const hay = text.trim().toLowerCase();
  if (!hay) return false;
  const parts = product.keywords.split(",").map((k) => k.trim().toLowerCase()).filter(Boolean);
  return parts.some((kw) => hay.includes(kw));
}
function buildProductCatalogText(products) {
  const active = products.filter((p) => p.autoReplyEnabled && p.stockStatus !== "habis");
  if (active.length === 0) {
    return "Saat ini belum ada produk yang tersedia di katalog.";
  }
  return active.map(
    (p) => `\u2022 ${p.name} (${p.duration}) \u2014 ${formatRupiah(p.price)} [${stockStatusLabel(p.stockStatus)}]`
  ).join("\n");
}
function renderReplyTemplate(template, context) {
  const now = context.now ?? /* @__PURE__ */ new Date();
  const offsetMin = context.timezoneOffsetMinutes ?? 420;
  const localMs = now.getTime() + offsetMin * 6e4;
  const localDate = new Date(localMs);
  const hh = String(localDate.getUTCHours()).padStart(2, "0");
  const mm = String(localDate.getUTCMinutes()).padStart(2, "0");
  const waktu = `${hh}:${mm}`;
  const dd = String(localDate.getUTCDate()).padStart(2, "0");
  const mo = String(localDate.getUTCMonth() + 1).padStart(2, "0");
  const yyyy = localDate.getUTCFullYear();
  const tanggal = `${dd}/${mo}/${yyyy}`;
  const safeName = context.senderName.trim() || "Kak";
  const safeUsername = context.senderUsername ? `@${context.senderUsername.replace(/^@/, "")}` : safeName;
  let rendered = template.replace(/\{nama\}/gi, safeName).replace(/\{username\}/gi, safeUsername).replace(/\{pesan\}/gi, context.incomingText.trim()).replace(/\{waktu\}/gi, waktu).replace(/\{tanggal\}/gi, tanggal);
  if (context.products) {
    rendered = rendered.replace(/\{katalog\}/gi, buildProductCatalogText(context.products));
  }
  if (context.product) {
    rendered = rendered.replace(/\{produk\}/gi, context.product.name).replace(/\{harga\}/gi, formatRupiah(context.product.price)).replace(/\{durasi\}/gi, context.product.duration).replace(/\{stok\}/gi, stockStatusLabel(context.product.stockStatus)).replace(/\{deskripsi\}/gi, context.product.description || "-");
  }
  return rendered;
}
function matchMessageToRules(input, rules, settings, cooldownMap, now = /* @__PURE__ */ new Date(), options = {}, products = []) {
  if (!settings.botEnabled) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: "Bot auto-reply sedang dinonaktifkan.",
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null
    };
  }
  if (input.chatType === "group" && settings.ignoreGroupsByDefault) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: "Pesan grup diabaikan sesuai pengaturan.",
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null
    };
  }
  if (isInIdentifierList(input.senderId, input.senderUsername, settings.blacklist)) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: "Pengirim masuk dalam daftar blokir (blacklist).",
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null
    };
  }
  if (settings.ignoreContactsInWhitelistOnly && !isInIdentifierList(input.senderId, input.senderUsername, settings.whitelist)) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: "Mode whitelist aktif: pengirim tidak terdaftar di whitelist.",
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null
    };
  }
  if (!options.ignoreScheduleAndCooldown && !isWithinSchedule(settings.schedule, now)) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: `Di luar jam aktif (${settings.schedule.startTime}\u2013${settings.schedule.endTime}).`,
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null
    };
  }
  const orderedRules = [...rules].filter((r) => r.enabled && (r.chatScope === "all" || r.chatScope === input.chatType)).sort((a, b) => a.priority - b.priority);
  const specificRule = orderedRules.find(
    (rule) => rule.matchType !== "all_incoming" && doesRuleMatchText(rule, input.text)
  );
  if (specificRule) {
    const cooldownSec = specificRule.cooldownSeconds >= 0 ? specificRule.cooldownSeconds : settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:${specificRule.id}`;
    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === "number") {
        const elapsedSec = (now.getTime() - lastSentMs) / 1e3;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: specificRule,
            matchedProduct: null,
            matchedDefaultReply: false,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey
          };
        }
      }
    }
    const renderedReply = renderReplyTemplate(specificRule.replyText, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products
    });
    return {
      shouldReply: true,
      matchedRule: specificRule,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply,
      reason: `Cocok dengan aturan "${specificRule.name}" (${specificRule.matchType}).`,
      delayMs: specificRule.delayMs,
      quoteOriginal: specificRule.quoteOriginal,
      cooldownKey
    };
  }
  const matchedProduct = products.find(
    (product) => product.autoReplyEnabled && doesProductMatchText(product, input.text)
  );
  if (matchedProduct) {
    const cooldownSec = settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:prod_${matchedProduct.id}`;
    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === "number") {
        const elapsedSec = (now.getTime() - lastSentMs) / 1e3;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: null,
            matchedProduct,
            matchedDefaultReply: false,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam produk (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey
          };
        }
      }
    }
    const renderedReply = renderReplyTemplate(matchedProduct.replyTemplate, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products,
      product: matchedProduct
    });
    return {
      shouldReply: true,
      matchedRule: null,
      matchedProduct,
      matchedDefaultReply: false,
      renderedReply,
      reason: `Cocok dengan produk "${matchedProduct.name}".`,
      delayMs: 800,
      quoteOriginal: true,
      cooldownKey
    };
  }
  const fallbackRule = orderedRules.find((rule) => rule.matchType === "all_incoming");
  if (fallbackRule) {
    const cooldownSec = fallbackRule.cooldownSeconds >= 0 ? fallbackRule.cooldownSeconds : settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:${fallbackRule.id}`;
    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === "number") {
        const elapsedSec = (now.getTime() - lastSentMs) / 1e3;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: fallbackRule,
            matchedProduct: null,
            matchedDefaultReply: false,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey
          };
        }
      }
    }
    const renderedReply = renderReplyTemplate(fallbackRule.replyText, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products
    });
    return {
      shouldReply: true,
      matchedRule: fallbackRule,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply,
      reason: `Cocok dengan aturan "${fallbackRule.name}" (${fallbackRule.matchType}).`,
      delayMs: fallbackRule.delayMs,
      quoteOriginal: fallbackRule.quoteOriginal,
      cooldownKey
    };
  }
  if (settings.defaultReplyEnabled) {
    const templateText = settings.defaultReplyText?.trim() || DEFAULT_FALLBACK_REPLY_TEXT;
    const cooldownSec = settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:default_reply`;
    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === "number") {
        const elapsedSec = (now.getTime() - lastSentMs) / 1e3;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: null,
            matchedProduct: null,
            matchedDefaultReply: true,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam balasan default (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey
          };
        }
      }
    }
    const renderedReply = renderReplyTemplate(templateText, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products
    });
    return {
      shouldReply: true,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: true,
      renderedReply,
      reason: "Menggunakan balasan default untuk semua pesan masuk.",
      delayMs: 800,
      quoteOriginal: false,
      cooldownKey
    };
  }
  return {
    shouldReply: false,
    matchedRule: null,
    matchedProduct: null,
    matchedDefaultReply: false,
    renderedReply: null,
    reason: "Tidak ada aturan aktif atau produk yang cocok dengan isi pesan.",
    delayMs: 0,
    quoteOriginal: false,
    cooldownKey: null
  };
}

// src/shared/qris.ts
function crc16Ccitt(input) {
  let crc = 65535;
  for (let i = 0; i < input.length; i++) {
    crc ^= input.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 32768) !== 0) {
        crc = (crc << 1 ^ 4129) & 65535;
      } else {
        crc = crc << 1 & 65535;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}
function parseQrisTags(payload) {
  const clean = payload.trim();
  if (clean.length < 16 || !clean.startsWith("0002")) return null;
  const tags = [];
  let cursor = 0;
  while (cursor < clean.length) {
    if (cursor + 4 > clean.length) return null;
    const id = clean.slice(cursor, cursor + 2);
    const lenStr = clean.slice(cursor + 2, cursor + 4);
    if (!/^\d{2}$/.test(id) || !/^\d{2}$/.test(lenStr)) return null;
    const len = Number(lenStr);
    const valStart = cursor + 4;
    const valEnd = valStart + len;
    if (valEnd > clean.length) return null;
    const value = clean.slice(valStart, valEnd);
    tags.push({ id, value });
    cursor = valEnd;
  }
  return tags;
}
function serializeQrisTags(tags) {
  return tags.map((t) => `${t.id}${String(t.value.length).padStart(2, "0")}${t.value}`).join("");
}
function validateStaticQris(payload) {
  const clean = payload.trim();
  if (!clean) {
    return { valid: false, error: "String QRIS GoPay Merchant tidak boleh kosong." };
  }
  const tags = parseQrisTags(clean);
  if (!tags || tags.length < 5) {
    return { valid: false, error: "Format TLV QRIS tidak valid. Pastikan diawali 000201..." };
  }
  const crcTag = tags.find((t) => t.id === "63");
  if (!crcTag || crcTag.value.length !== 4) {
    return { valid: false, error: "Tag checksum CRC (63) QRIS tidak ditemukan." };
  }
  const withoutCrc = clean.slice(0, clean.length - 4);
  const expectedCrc = crc16Ccitt(withoutCrc);
  if (expectedCrc !== crcTag.value.toUpperCase()) {
    return {
      valid: false,
      error: `Checksum CRC QRIS tidak cocok (seharusnya ${expectedCrc}, terbaca ${crcTag.value}).`
    };
  }
  return { valid: true };
}
function generateDynamicQris(staticQris, amount) {
  const cleanAmount = Math.max(1, Math.round(amount));
  const check = validateStaticQris(staticQris);
  if (!check.valid) {
    throw new Error(check.error || "String QRIS GoPay Merchant tidak valid.");
  }
  const tags = parseQrisTags(staticQris.trim());
  const withoutCrc = tags.filter((t) => t.id !== "63");
  const tag01 = withoutCrc.find((t) => t.id === "01");
  if (tag01) {
    tag01.value = "12";
  } else {
    withoutCrc.splice(1, 0, { id: "01", value: "12" });
  }
  if (!withoutCrc.some((t) => t.id === "53")) {
    withoutCrc.push({ id: "53", value: "360" });
  }
  const amountTag = { id: "54", value: String(cleanAmount) };
  const existing54Idx = withoutCrc.findIndex((t) => t.id === "54");
  if (existing54Idx >= 0) {
    withoutCrc[existing54Idx] = amountTag;
  } else {
    const idx58 = withoutCrc.findIndex((t) => Number(t.id) >= 58);
    if (idx58 >= 0) {
      withoutCrc.splice(idx58, 0, amountTag);
    } else {
      withoutCrc.push(amountTag);
    }
  }
  const bodyWithCrcPrefix = `${serializeQrisTags(withoutCrc)}6304`;
  const crc = crc16Ccitt(bodyWithCrcPrefix);
  return `${bodyWithCrcPrefix}${crc}`;
}
function extractMerchantNameFromQris(qrisPayload) {
  const tags = parseQrisTags(qrisPayload);
  if (!tags) return null;
  return tags.find((t) => t.id === "59")?.value || null;
}
function buildSampleStaticQris(merchantName = "TELEBALAS GOPAY") {
  const body = serializeQrisTags([
    { id: "00", value: "01" },
    { id: "01", value: "11" },
    { id: "26", value: "0011ID.GOPAY.WWW011893600914000000000102152000000000000010303UMI" },
    { id: "52", value: "5732" },
    { id: "53", value: "360" },
    { id: "58", value: "ID" },
    { id: "59", value: merchantName.slice(0, 25).toUpperCase() },
    { id: "60", value: "JAKARTA" },
    { id: "61", value: "12190" }
  ]);
  const base = `${body}6304`;
  return `${base}${crc16Ccitt(base)}`;
}
var SAMPLE_GOPAY_STATIC_QRIS = buildSampleStaticQris("TOKO DIGITAL TELEBALAS");
function parseGoPayNotificationAmount(text) {
  const clean = text.trim();
  if (!clean) return null;
  const match = /(?:rp|idr)\.?\s*([0-9][0-9.,]*)/i.exec(clean);
  if (!match) return null;
  let rawNum = match[1];
  rawNum = rawNum.replace(/([.,]00)$/, "");
  const digitsOnly = rawNum.replace(/[^0-9]/g, "");
  if (!digitsOnly) return null;
  const parsed = Number(digitsOnly);
  if (!Number.isSafeInteger(parsed) || parsed <= 0 || parsed > 1e8) {
    return null;
  }
  return parsed;
}

// server/auth.ts
var import_node_crypto2 = __toESM(require("node:crypto"), 1);

// server/store.ts
var import_node_fs = __toESM(require("node:fs"), 1);
var import_node_path = __toESM(require("node:path"), 1);
var import_node_crypto = __toESM(require("node:crypto"), 1);
var DATA_DIR = import_node_path.default.resolve(process.cwd(), "data");
var STORE_FILE = import_node_path.default.resolve(DATA_DIR, "store.json");
if (!STORE_FILE.startsWith(DATA_DIR + import_node_path.default.sep)) {
  throw new Error("Invalid store file path outside data directory.");
}
function createInitialGopayConfig() {
  return {
    enabled: true,
    merchantName: "TOKO DIGITAL TELEBALAS",
    staticQris: SAMPLE_GOPAY_STATIC_QRIS,
    mutationApiUrl: "",
    apiToken: "",
    webhookSecret: import_node_crypto.default.randomBytes(20).toString("hex"),
    pollingEnabled: false,
    pollIntervalSeconds: 20,
    orderExpiryMinutes: 15,
    lastPolledAt: null,
    lastPollStatus: null
  };
}
function normalizeProductAccounts(raw) {
  if (!Array.isArray(raw)) return [];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const normalized = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const rec = item;
    const email = typeof rec.email === "string" ? rec.email.trim().slice(0, 160) : "";
    const password = typeof rec.password === "string" ? rec.password.trim().slice(0, 160) : "";
    const extraData = typeof rec.extraData === "string" ? rec.extraData.trim().slice(0, 1e3) : "";
    if (!email && !extraData) continue;
    const status = rec.status === "reserved" || rec.status === "sold" ? rec.status : "available";
    normalized.push({
      id: typeof rec.id === "string" && rec.id.trim() ? rec.id.trim().slice(0, 64) : `acc_${import_node_crypto.default.randomUUID().slice(0, 8)}`,
      email,
      password,
      extraData,
      status,
      soldToOrderId: typeof rec.soldToOrderId === "string" ? rec.soldToOrderId : null,
      soldAt: typeof rec.soldAt === "string" ? rec.soldAt : null,
      createdAt: typeof rec.createdAt === "string" ? rec.createdAt : now
    });
  }
  return normalized.slice(0, 500);
}
function createInitialStore() {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return {
    rules: [
      {
        id: "rule_sapaan",
        name: "Sapaan Pembuka & Menu Bantuan",
        enabled: true,
        matchType: "exact",
        pattern: "halo, hai, p, assalamualaikum",
        caseSensitive: false,
        chatScope: "private",
        replyText: 'Halo {nama}, selamat datang! Ketik "harga" untuk melihat katalog produk (Netflix, Spotify, dll) atau ketik "order netflix" untuk langsung checkout QRIS GoPay otomatis.',
        quoteOriginal: false,
        delayMs: 800,
        cooldownSeconds: 120,
        priority: 1,
        hitCount: 14,
        createdAt: now,
        updatedAt: now
      },
      {
        id: "rule_harga",
        name: "Katalog Harga & Produk",
        enabled: true,
        matchType: "contains",
        pattern: "harga, tarif, biaya, pricelist, katalog, produk",
        caseSensitive: false,
        chatScope: "private",
        replyText: 'Halo {nama}, berikut daftar produk digital yang tersedia saat ini:\n\n{katalog}\n\nSebutkan nama produk (misal: "netflix") untuk detail atau ketik "order netflix" untuk bayar via QRIS GoPay.',
        quoteOriginal: true,
        delayMs: 900,
        cooldownSeconds: 60,
        priority: 2,
        hitCount: 9,
        createdAt: now,
        updatedAt: now
      },
      {
        id: "rule_jadwal",
        name: "Cek Jam Kerja & Respon",
        enabled: true,
        matchType: "contains",
        pattern: "jadwal, buka, online, sibuk, kapan",
        caseSensitive: false,
        chatScope: "private",
        replyText: "Saat ini pukul {waktu} WIB ({tanggal}). Sistem order & verifikasi QRIS GoPay aktif otomatis 24 jam penuh.",
        quoteOriginal: false,
        delayMs: 700,
        cooldownSeconds: 180,
        priority: 3,
        hitCount: 5,
        createdAt: now,
        updatedAt: now
      },
      {
        id: "rule_afk",
        name: "Mode Sibuk / Balasan Semua Pesan",
        enabled: false,
        matchType: "all_incoming",
        pattern: "",
        caseSensitive: false,
        chatScope: "private",
        replyText: 'Halo {nama}, saya sedang tidak berada di depan layar. Pesan "{pesan}" sudah diterima pada {waktu} WIB dan akan saya balas setelah kembali.',
        quoteOriginal: false,
        delayMs: 1200,
        cooldownSeconds: 300,
        priority: 99,
        hitCount: 2,
        createdAt: now,
        updatedAt: now
      }
    ],
    products: [
      {
        id: "prod_netflix",
        name: "Netflix Premium 4K",
        category: "Streaming Video",
        price: 35e3,
        duration: "1 Bulan",
        stockStatus: "tersedia",
        keywords: "netflix, nf",
        description: "Profil private 1P1U UHD 4K, support Smart TV/HP/Laptop, garansi penuh 30 hari.",
        replyTemplate: 'Halo {nama}, detail produk *{produk}*:\n\u2022 Durasi: {durasi}\n\u2022 Harga: {harga}\n\u2022 Status: {stok}\n\u2022 Keterangan: {deskripsi}\n\nBalas "order netflix" untuk mendapatkan QRIS GoPay & kirim akun otomatis.',
        autoReplyEnabled: true,
        accounts: [
          {
            id: "acc_nf_demo_1",
            email: "demo.netflix1@contoh.id",
            password: "NfDemo2026!",
            extraData: "Profil: VIP 1 \u2022 PIN: 1122 \u2022 Garansi 30 Hari",
            status: "available",
            soldToOrderId: null,
            soldAt: null,
            createdAt: now
          },
          {
            id: "acc_nf_demo_2",
            email: "demo.netflix2@contoh.id",
            password: "NfDemo2026@",
            extraData: "Profil: VIP 2 \u2022 PIN: 3344 \u2022 Garansi 30 Hari",
            status: "available",
            soldToOrderId: null,
            soldAt: null,
            createdAt: now
          }
        ],
        hitCount: 12,
        createdAt: now,
        updatedAt: now
      },
      {
        id: "prod_spotify",
        name: "Spotify Premium Individual",
        category: "Streaming Musik",
        price: 25e3,
        duration: "1 Bulan",
        stockStatus: "tersedia",
        keywords: "spotify, musik",
        description: "Akun legal bebas iklan, siap pakai dan bergaransi penuh.",
        replyTemplate: 'Halo {nama}, detail produk *{produk}*:\n\u2022 Durasi: {durasi}\n\u2022 Harga: {harga}\n\u2022 Status: {stok}\n\u2022 Keterangan: {deskripsi}\n\nBalas "order spotify" untuk pembayaran otomatis via QRIS GoPay.',
        autoReplyEnabled: true,
        accounts: [
          {
            id: "acc_sp_demo_1",
            email: "demo.spotify1@contoh.id",
            password: "SpotDemo2026!",
            extraData: "Plan Individual 1 Bulan \u2022 Region Indonesia",
            status: "available",
            soldToOrderId: null,
            soldAt: null,
            createdAt: now
          }
        ],
        hitCount: 8,
        createdAt: now,
        updatedAt: now
      },
      {
        id: "prod_canva",
        name: "Canva Pro Education / Team",
        category: "Desain & Produktivitas",
        price: 18e3,
        duration: "1 Tahun",
        stockStatus: "terbatas",
        keywords: "canva, desain",
        description: "Invite link / akun Pro siap pakai, akses semua aset Pro & Brand Kit.",
        replyTemplate: 'Halo {nama}, detail produk *{produk}*:\n\u2022 Durasi: {durasi}\n\u2022 Harga: {harga}\n\u2022 Status: {stok}\n\u2022 Keterangan: {deskripsi}\n\nBalas "order canva" untuk checkout via QRIS GoPay.',
        autoReplyEnabled: true,
        accounts: [],
        hitCount: 4,
        createdAt: now,
        updatedAt: now
      }
    ],
    settings: {
      botEnabled: true,
      defaultReplyEnabled: true,
      defaultReplyText: DEFAULT_FALLBACK_REPLY_TEXT,
      ignoreGroupsByDefault: true,
      ignoreContactsInWhitelistOnly: false,
      whitelist: [],
      blacklist: [],
      defaultCooldownSeconds: 60,
      typingIndicator: true,
      schedule: {
        enabled: false,
        startTime: "08:00",
        endTime: "21:00",
        timezoneOffsetMinutes: 420
      }
    },
    credentials: {
      apiId: null,
      apiHash: null,
      sessionString: null,
      phoneMasked: null,
      firstName: null,
      lastName: null,
      username: null,
      telegramId: null,
      connectedAt: null
    },
    logs: [
      {
        id: "log_seed_1",
        timestamp: new Date(Date.now() - 42 * 6e4).toISOString(),
        senderId: "sim_101",
        senderName: "Raka Pratama",
        senderUsername: "rakapratama",
        chatType: "private",
        incomingText: "Kak, Netflix 1 bulan ready?",
        matchedRuleId: "prod_netflix",
        matchedRuleName: "Produk: Netflix Premium 4K",
        replyText: "Halo Raka Pratama, detail produk *Netflix Premium 4K*:\n\u2022 Durasi: 1 Bulan\n\u2022 Harga: Rp 35.000\n\u2022 Status: Tersedia",
        outcome: "simulated",
        reason: 'Cocok dengan produk "Netflix Premium 4K".'
      },
      {
        id: "log_seed_2",
        timestamp: new Date(Date.now() - 18 * 6e4).toISOString(),
        senderId: "sim_102",
        senderName: "Nadia Putri",
        senderUsername: "nadiaputri",
        chatType: "group",
        incomingText: "Ada yang jual Spotify?",
        matchedRuleId: null,
        matchedRuleName: null,
        replyText: null,
        outcome: "skipped",
        reason: "Pesan grup diabaikan sesuai pengaturan."
      }
    ],
    adminAuth: {
      pinHash: null,
      updatedAt: null
    },
    orders: [],
    mutations: [],
    gopayConfig: createInitialGopayConfig()
  };
}
var cachedStore = null;
function ensureDataDir() {
  if (!import_node_fs.default.existsSync(DATA_DIR)) {
    import_node_fs.default.mkdirSync(DATA_DIR, { recursive: true, mode: 448 });
  }
}
function loadStore() {
  if (cachedStore) return cachedStore;
  ensureDataDir();
  if (import_node_fs.default.existsSync(STORE_FILE)) {
    try {
      const raw = import_node_fs.default.readFileSync(STORE_FILE, "utf8");
      const parsed = JSON.parse(raw);
      const base = createInitialStore();
      const rawProducts = Array.isArray(parsed.products) ? parsed.products : base.products;
      const products = rawProducts.map((p) => ({
        ...p,
        accounts: normalizeProductAccounts(p.accounts)
      }));
      cachedStore = {
        rules: Array.isArray(parsed.rules) ? parsed.rules : base.rules,
        products,
        settings: parsed.settings ? {
          ...base.settings,
          ...parsed.settings,
          schedule: {
            ...base.settings.schedule,
            ...parsed.settings.schedule ?? {}
          }
        } : base.settings,
        credentials: parsed.credentials ? { ...base.credentials, ...parsed.credentials } : base.credentials,
        logs: Array.isArray(parsed.logs) ? parsed.logs : base.logs,
        adminAuth: parsed.adminAuth ? { ...base.adminAuth, ...parsed.adminAuth } : base.adminAuth,
        orders: Array.isArray(parsed.orders) ? parsed.orders : [],
        mutations: Array.isArray(parsed.mutations) ? parsed.mutations : [],
        gopayConfig: parsed.gopayConfig ? {
          ...base.gopayConfig,
          ...parsed.gopayConfig,
          webhookSecret: parsed.gopayConfig.webhookSecret || base.gopayConfig.webhookSecret
        } : base.gopayConfig
      };
      return cachedStore;
    } catch {
      cachedStore = createInitialStore();
      saveStore(cachedStore);
      return cachedStore;
    }
  }
  cachedStore = createInitialStore();
  saveStore(cachedStore);
  return cachedStore;
}
function saveStore(store) {
  ensureDataDir();
  cachedStore = store;
  const tempFile = import_node_path.default.resolve(DATA_DIR, `store.${import_node_crypto.default.randomUUID()}.tmp`);
  if (!tempFile.startsWith(DATA_DIR + import_node_path.default.sep)) {
    throw new Error("Invalid temporary file path.");
  }
  import_node_fs.default.writeFileSync(tempFile, JSON.stringify(store, null, 2), { encoding: "utf8", mode: 384 });
  import_node_fs.default.renameSync(tempFile, STORE_FILE);
}
function maskSecretTail(secret, keepLast = 4) {
  if (!secret || secret.length === 0) return null;
  if (secret.length <= keepLast) return "\u2022\u2022\u2022\u2022";
  return `\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022${secret.slice(-keepLast)}`;
}
function maskPhone(phone) {
  if (!phone) return null;
  const cleaned = phone.trim();
  if (cleaned.length <= 5) return "\u2022\u2022\u2022\u2022\u2022";
  return `${cleaned.slice(0, 4)}\u2022\u2022\u2022\u2022${cleaned.slice(-3)}`;
}
function buildPublicAccount(status, errorMessage) {
  const { credentials } = loadStore();
  return {
    status,
    apiId: credentials.apiId,
    apiHashMasked: maskSecretTail(credentials.apiHash, 4),
    hasSession: Boolean(credentials.sessionString),
    phoneMasked: credentials.phoneMasked,
    firstName: credentials.firstName,
    lastName: credentials.lastName,
    username: credentials.username,
    telegramId: credentials.telegramId,
    connectedAt: credentials.connectedAt,
    errorMessage
  };
}
function buildPublicGopayConfig(store) {
  const cfg = store.gopayConfig;
  return {
    enabled: cfg.enabled,
    merchantName: cfg.merchantName,
    staticQris: cfg.staticQris,
    mutationApiUrl: cfg.mutationApiUrl,
    hasApiToken: Boolean(cfg.apiToken),
    apiTokenMasked: maskSecretTail(cfg.apiToken, 4),
    hasWebhookSecret: Boolean(cfg.webhookSecret),
    webhookSecretMasked: maskSecretTail(cfg.webhookSecret, 4),
    pollingEnabled: cfg.pollingEnabled,
    pollIntervalSeconds: cfg.pollIntervalSeconds,
    orderExpiryMinutes: cfg.orderExpiryMinutes,
    lastPolledAt: cfg.lastPolledAt,
    lastPollStatus: cfg.lastPollStatus
  };
}
function computeStats(store) {
  let totalReplied = 0;
  let totalSkipped = 0;
  let totalSimulated = 0;
  for (const entry of store.logs) {
    if (entry.outcome === "replied") totalReplied += 1;
    else if (entry.outcome === "skipped") totalSkipped += 1;
    else if (entry.outcome === "simulated") totalSimulated += 1;
  }
  let pendingOrdersCount = 0;
  let paidOrdersCount = 0;
  let totalRevenue = 0;
  for (const ord of store.orders) {
    if (ord.status === "pending") pendingOrdersCount += 1;
    if (ord.status === "paid" || ord.status === "delivered") {
      paidOrdersCount += 1;
      totalRevenue += ord.totalAmount;
    }
  }
  let availableAccountStockCount = 0;
  for (const p of store.products) {
    for (const acc of p.accounts ?? []) {
      if (acc.status === "available") availableAccountStockCount += 1;
    }
  }
  return {
    totalReplied,
    totalSkipped,
    totalSimulated,
    activeRuleCount: store.rules.filter((r) => r.enabled).length,
    totalRuleCount: store.rules.length,
    activeProductCount: store.products.filter((p) => p.autoReplyEnabled).length,
    totalProductCount: store.products.length,
    pendingOrdersCount,
    paidOrdersCount,
    totalRevenue,
    availableAccountStockCount
  };
}
function appendLog(entry) {
  const store = loadStore();
  const fullEntry = {
    ...entry,
    id: `log_${import_node_crypto.default.randomUUID().slice(0, 8)}`,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  store.logs = [fullEntry, ...store.logs].slice(0, 200);
  saveStore(store);
  return fullEntry;
}

// server/auth.ts
var SESSION_TTL_MS = 12 * 60 * 60 * 1e3;
var MAX_LOGIN_FAILURES = 5;
var LOCKOUT_WINDOW_MS = 5 * 60 * 1e3;
var SESSION_SECRET = process.env.ADMIN_SESSION_SECRET && process.env.ADMIN_SESSION_SECRET.trim().length >= 16 ? process.env.ADMIN_SESSION_SECRET.trim() : import_node_crypto2.default.randomBytes(32).toString("hex");
var revokedTokens = /* @__PURE__ */ new Map();
var failedLoginAttempts = /* @__PURE__ */ new Map();
function validatePinFormat(pin) {
  if (typeof pin !== "string" || !/^\d{4,8}$/.test(pin)) {
    return "PIN harus terdiri dari 4 hingga 8 digit angka.";
  }
  return null;
}
function hashPinScrypt(pin) {
  const salt = import_node_crypto2.default.randomBytes(16).toString("hex");
  const derived = import_node_crypto2.default.scryptSync(pin, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}
function verifyPinScrypt(pin, storedHash) {
  const parts = storedHash.split(":");
  if (parts.length !== 2) return false;
  const [salt, hashHex] = parts;
  if (!salt || !hashHex) return false;
  try {
    const expected = Buffer.from(hashHex, "hex");
    const actual = import_node_crypto2.default.scryptSync(pin, salt, 64);
    if (expected.length !== actual.length) return false;
    return import_node_crypto2.default.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}
function verifyPinAgainstEnv(pin, envPin) {
  const a = import_node_crypto2.default.createHash("sha256").update(pin, "utf8").digest();
  const b = import_node_crypto2.default.createHash("sha256").update(envPin, "utf8").digest();
  return import_node_crypto2.default.timingSafeEqual(a, b);
}
function issueSessionToken(secret = SESSION_SECRET, ttlMs = SESSION_TTL_MS) {
  const now = Date.now();
  const expiresAt = now + ttlMs;
  const jti = import_node_crypto2.default.randomUUID();
  const payload = Buffer.from(JSON.stringify({ jti, iat: now, exp: expiresAt }), "utf8").toString(
    "base64url"
  );
  const sig = import_node_crypto2.default.createHmac("sha256", secret).update(payload).digest("base64url");
  return { token: `${payload}.${sig}`, expiresAt, jti };
}
function verifySessionToken(token, secret = SESSION_SECRET, revoked = revokedTokens, nowMs = Date.now()) {
  if (!token || typeof token !== "string") return { valid: false };
  const parts = token.split(".");
  if (parts.length !== 2) return { valid: false };
  const [payloadB64, sigB64] = parts;
  if (!payloadB64 || !sigB64) return { valid: false };
  const expectedSig = import_node_crypto2.default.createHmac("sha256", secret).update(payloadB64).digest("base64url");
  const sigBuf = Buffer.from(sigB64, "utf8");
  const expectedBuf = Buffer.from(expectedSig, "utf8");
  if (sigBuf.length !== expectedBuf.length || !import_node_crypto2.default.timingSafeEqual(sigBuf, expectedBuf)) {
    return { valid: false };
  }
  try {
    const decoded = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8"));
    if (!decoded.jti || typeof decoded.exp !== "number") return { valid: false };
    if (decoded.exp <= nowMs) return { valid: false };
    if (revoked.has(decoded.jti)) return { valid: false };
    return { valid: true, jti: decoded.jti, expiresAt: decoded.exp };
  } catch {
    return { valid: false };
  }
}
function getEnvPin() {
  const val = process.env.ADMIN_PIN?.trim();
  return val && val.length > 0 ? val : null;
}
function getAuthStatus(authenticated) {
  const envPin = getEnvPin();
  const store = loadStore();
  const hasStoredHash = Boolean(store.adminAuth?.pinHash);
  return {
    authenticated,
    needsSetup: !envPin && !hasStoredHash,
    managedByEnv: Boolean(envPin),
    pinUpdatedAt: envPin ? null : store.adminAuth?.updatedAt ?? null
  };
}
function extractBearerToken(req) {
  const header = req.headers.authorization;
  if (!header || typeof header !== "string") return null;
  if (!header.startsWith("Bearer ")) return null;
  return header.slice(7).trim() || null;
}
function requireAdminAuth(req, res, next) {
  const token = extractBearerToken(req);
  const check = token ? verifySessionToken(token) : { valid: false };
  if (!check.valid) {
    res.status(401).json({ error: "Sesi admin tidak valid atau sudah berakhir. Silakan login PIN." });
    return;
  }
  next();
}
function revokeBearerToken(req) {
  const token = extractBearerToken(req);
  if (!token) return;
  const check = verifySessionToken(token);
  if (check.valid && check.jti && check.expiresAt) {
    revokedTokens.set(check.jti, check.expiresAt);
    const now = Date.now();
    for (const [key, exp] of revokedTokens.entries()) {
      if (exp <= now) revokedTokens.delete(key);
    }
  }
}
function getClientKey(req) {
  return req.ip || req.socket.remoteAddress || "unknown";
}
function checkLoginRateLimit(req) {
  const key = getClientKey(req);
  const rec = failedLoginAttempts.get(key);
  if (!rec) return { blocked: false, retryAfterSec: 0 };
  const elapsed = Date.now() - rec.firstAttemptMs;
  if (elapsed >= LOCKOUT_WINDOW_MS) {
    failedLoginAttempts.delete(key);
    return { blocked: false, retryAfterSec: 0 };
  }
  if (rec.count >= MAX_LOGIN_FAILURES) {
    return {
      blocked: true,
      retryAfterSec: Math.max(1, Math.ceil((LOCKOUT_WINDOW_MS - elapsed) / 1e3))
    };
  }
  return { blocked: false, retryAfterSec: 0 };
}
function recordLoginFailure(req) {
  const key = getClientKey(req);
  const now = Date.now();
  const rec = failedLoginAttempts.get(key);
  if (!rec || now - rec.firstAttemptMs >= LOCKOUT_WINDOW_MS) {
    failedLoginAttempts.set(key, { count: 1, firstAttemptMs: now });
  } else {
    rec.count += 1;
  }
}
function clearLoginFailures(req) {
  failedLoginAttempts.delete(getClientKey(req));
}
function verifyAdminPin(pin) {
  const envPin = getEnvPin();
  if (envPin) {
    return verifyPinAgainstEnv(pin, envPin);
  }
  const store = loadStore();
  if (!store.adminAuth?.pinHash) return false;
  return verifyPinScrypt(pin, store.adminAuth.pinHash);
}
function claimInitialPin(pin) {
  const envPin = getEnvPin();
  if (envPin) {
    return { ok: false, error: "PIN admin sudah dikonfigurasi melalui environment server." };
  }
  const store = loadStore();
  if (store.adminAuth?.pinHash) {
    return { ok: false, error: "PIN admin sudah pernah dibuat sebelumnya." };
  }
  const formatErr = validatePinFormat(pin);
  if (formatErr) {
    return { ok: false, error: formatErr };
  }
  store.adminAuth = {
    pinHash: hashPinScrypt(pin),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  saveStore(store);
  return { ok: true };
}
function updateAdminPin(currentPin, newPin) {
  const envPin = getEnvPin();
  if (envPin) {
    return {
      ok: false,
      error: "PIN dikelola melalui secret environment server (ADMIN_PIN) dan tidak dapat diubah di UI."
    };
  }
  if (!verifyAdminPin(currentPin)) {
    return { ok: false, error: "PIN saat ini salah." };
  }
  const formatErr = validatePinFormat(newPin);
  if (formatErr) {
    return { ok: false, error: formatErr };
  }
  const store = loadStore();
  store.adminAuth = {
    pinHash: hashPinScrypt(newPin),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  saveStore(store);
  return { ok: true };
}

// server/exporter.ts
var import_node_crypto3 = __toESM(require("node:crypto"), 1);
var import_node_fs2 = __toESM(require("node:fs"), 1);
var import_node_path2 = __toESM(require("node:path"), 1);
var import_jszip = __toESM(require("jszip"), 1);
var VALID_MATCH_TYPES = /* @__PURE__ */ new Set([
  "exact",
  "contains",
  "starts_with",
  "regex",
  "all_incoming"
]);
var VALID_SCOPES = /* @__PURE__ */ new Set(["private", "group", "all"]);
var VALID_STOCK_STATUSES = /* @__PURE__ */ new Set(["tersedia", "terbatas", "habis"]);
function buildSanitizedDatabaseExport(store, includeLogs = true) {
  return {
    rules: structuredClone(store.rules),
    products: structuredClone(store.products),
    settings: structuredClone(store.settings),
    credentials: {
      apiId: null,
      apiHash: null,
      sessionString: null,
      phoneMasked: null,
      firstName: null,
      lastName: null,
      username: null,
      telegramId: null,
      connectedAt: null
    },
    logs: includeLogs ? structuredClone(store.logs) : [],
    adminAuth: {
      pinHash: null,
      updatedAt: null
    },
    orders: [],
    mutations: [],
    gopayConfig: {
      ...structuredClone(store.gopayConfig),
      apiToken: "",
      webhookSecret: "",
      lastPolledAt: null,
      lastPollStatus: null
    }
  };
}
function escapeSqlString(value) {
  return value.replace(/\\/g, "\\\\").replace(/\0/g, "\\0").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\x1a/g, "\\Z").replace(/'/g, "\\'");
}
function sqlVal(value) {
  if (value === null || value === void 0) return "NULL";
  return `'${escapeSqlString(String(value))}'`;
}
function generateSqlDump(store) {
  const sanitized = buildSanitizedDatabaseExport(store, true);
  const lines = [
    "-- ============================================================",
    "-- TeleBalas Database SQL Export (MySQL / MariaDB / phpMyAdmin)",
    `-- Generated at: ${(/* @__PURE__ */ new Date()).toISOString()}`,
    "-- Catatan: Sesi Telegram & PIN Admin tidak disertakan demi keamanan.",
    "-- ============================================================",
    "",
    "SET NAMES utf8mb4;",
    "",
    "CREATE TABLE IF NOT EXISTS `telebalas_products` (",
    "  `id` VARCHAR(64) NOT NULL PRIMARY KEY,",
    "  `name` VARCHAR(120) NOT NULL,",
    "  `category` VARCHAR(80) NOT NULL,",
    "  `price` INT NOT NULL DEFAULT 0,",
    "  `duration` VARCHAR(64) NOT NULL,",
    "  `stock_status` VARCHAR(20) NOT NULL DEFAULT 'tersedia',",
    "  `keywords` TEXT NOT NULL,",
    "  `description` TEXT NOT NULL,",
    "  `reply_template` TEXT NOT NULL,",
    "  `auto_reply_enabled` TINYINT(1) NOT NULL DEFAULT 1,",
    "  `hit_count` INT NOT NULL DEFAULT 0,",
    "  `created_at` VARCHAR(40) NOT NULL,",
    "  `updated_at` VARCHAR(40) NOT NULL",
    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
    "",
    "CREATE TABLE IF NOT EXISTS `telebalas_rules` (",
    "  `id` VARCHAR(64) NOT NULL PRIMARY KEY,",
    "  `name` VARCHAR(120) NOT NULL,",
    "  `enabled` TINYINT(1) NOT NULL DEFAULT 1,",
    "  `match_type` VARCHAR(32) NOT NULL,",
    "  `pattern` TEXT NOT NULL,",
    "  `case_sensitive` TINYINT(1) NOT NULL DEFAULT 0,",
    "  `chat_scope` VARCHAR(16) NOT NULL DEFAULT 'private',",
    "  `reply_text` TEXT NOT NULL,",
    "  `quote_original` TINYINT(1) NOT NULL DEFAULT 0,",
    "  `delay_ms` INT NOT NULL DEFAULT 800,",
    "  `cooldown_seconds` INT NOT NULL DEFAULT 60,",
    "  `priority` INT NOT NULL DEFAULT 10,",
    "  `hit_count` INT NOT NULL DEFAULT 0,",
    "  `created_at` VARCHAR(40) NOT NULL,",
    "  `updated_at` VARCHAR(40) NOT NULL",
    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
    "",
    "CREATE TABLE IF NOT EXISTS `telebalas_settings` (",
    "  `setting_key` VARCHAR(64) NOT NULL PRIMARY KEY,",
    "  `setting_json` LONGTEXT NOT NULL,",
    "  `updated_at` VARCHAR(40) NOT NULL",
    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
    ""
  ];
  if (sanitized.products.length > 0) {
    lines.push("DELETE FROM `telebalas_products`;");
    for (const p of sanitized.products) {
      lines.push(
        `INSERT INTO \`telebalas_products\` (\`id\`, \`name\`, \`category\`, \`price\`, \`duration\`, \`stock_status\`, \`keywords\`, \`description\`, \`reply_template\`, \`auto_reply_enabled\`, \`hit_count\`, \`created_at\`, \`updated_at\`) VALUES (${sqlVal(p.id)}, ${sqlVal(p.name)}, ${sqlVal(p.category)}, ${Math.round(Number(p.price) || 0)}, ${sqlVal(p.duration)}, ${sqlVal(p.stockStatus)}, ${sqlVal(p.keywords)}, ${sqlVal(p.description)}, ${sqlVal(p.replyTemplate)}, ${p.autoReplyEnabled ? 1 : 0}, ${Math.max(0, Math.round(Number(p.hitCount) || 0))}, ${sqlVal(p.createdAt)}, ${sqlVal(p.updatedAt)});`
      );
    }
    lines.push("");
  }
  if (sanitized.rules.length > 0) {
    lines.push("DELETE FROM `telebalas_rules`;");
    for (const r of sanitized.rules) {
      lines.push(
        `INSERT INTO \`telebalas_rules\` (\`id\`, \`name\`, \`enabled\`, \`match_type\`, \`pattern\`, \`case_sensitive\`, \`chat_scope\`, \`reply_text\`, \`quote_original\`, \`delay_ms\`, \`cooldown_seconds\`, \`priority\`, \`hit_count\`, \`created_at\`, \`updated_at\`) VALUES (${sqlVal(r.id)}, ${sqlVal(r.name)}, ${r.enabled ? 1 : 0}, ${sqlVal(r.matchType)}, ${sqlVal(r.pattern)}, ${r.caseSensitive ? 1 : 0}, ${sqlVal(r.chatScope)}, ${sqlVal(r.replyText)}, ${r.quoteOriginal ? 1 : 0}, ${Math.max(0, Math.round(Number(r.delayMs) || 0))}, ${Math.max(0, Math.round(Number(r.cooldownSeconds) || 0))}, ${Math.max(1, Math.round(Number(r.priority) || 10))}, ${Math.max(0, Math.round(Number(r.hitCount) || 0))}, ${sqlVal(r.createdAt)}, ${sqlVal(r.updatedAt)});`
      );
    }
    lines.push("");
  }
  lines.push(
    `REPLACE INTO \`telebalas_settings\` (\`setting_key\`, \`setting_json\`, \`updated_at\`) VALUES ('bot_settings', ${sqlVal(JSON.stringify(sanitized.settings))}, ${sqlVal((/* @__PURE__ */ new Date()).toISOString())});`
  );
  lines.push("");
  return lines.join("\n");
}
function validateRestorePayload(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { ok: false, error: "Format file database JSON tidak valid." };
  }
  const obj = raw;
  if (!Array.isArray(obj.rules) || !Array.isArray(obj.products)) {
    return { ok: false, error: 'File JSON harus berisi array "rules" dan "products".' };
  }
  if (obj.rules.length > 500 || obj.products.length > 500) {
    return { ok: false, error: "Jumlah aturan atau produk melebihi batas maksimum (500)." };
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const validatedRules = [];
  for (let i = 0; i < obj.rules.length; i++) {
    const item = obj.rules[i];
    if (!item || typeof item !== "object") {
      return { ok: false, error: `Aturan ke-${i + 1} tidak valid.` };
    }
    const name = typeof item.name === "string" ? item.name.trim() : "";
    const matchType = VALID_MATCH_TYPES.has(item.matchType) ? item.matchType : "contains";
    const pattern = typeof item.pattern === "string" ? item.pattern.trim() : "";
    const replyText = typeof item.replyText === "string" ? item.replyText.trim() : "";
    const delayMs = Number(item.delayMs ?? 800);
    const cooldownSeconds = Number(item.cooldownSeconds ?? 60);
    const priority = Number(item.priority ?? 10);
    const check = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority
    });
    if (!check.valid) {
      const firstErr = Object.values(check.errors)[0] ?? "Aturan tidak valid.";
      return { ok: false, error: `Aturan #${i + 1} (${name || "tanpa nama"}): ${firstErr}` };
    }
    validatedRules.push({
      id: typeof item.id === "string" && item.id.trim() ? item.id.trim().slice(0, 64) : `rule_${import_node_crypto3.default.randomUUID().slice(0, 8)}`,
      name,
      enabled: item.enabled !== void 0 ? Boolean(item.enabled) : true,
      matchType,
      pattern: matchType === "all_incoming" ? "" : pattern,
      caseSensitive: Boolean(item.caseSensitive),
      chatScope: VALID_SCOPES.has(item.chatScope) ? item.chatScope : "private",
      replyText,
      quoteOriginal: Boolean(item.quoteOriginal),
      delayMs,
      cooldownSeconds,
      priority,
      hitCount: Math.max(0, Math.round(Number(item.hitCount) || 0)),
      createdAt: typeof item.createdAt === "string" ? item.createdAt : now,
      updatedAt: now
    });
  }
  const validatedProducts = [];
  for (let i = 0; i < obj.products.length; i++) {
    const item = obj.products[i];
    if (!item || typeof item !== "object") {
      return { ok: false, error: `Produk ke-${i + 1} tidak valid.` };
    }
    const name = typeof item.name === "string" ? item.name.trim() : "";
    const category = typeof item.category === "string" ? item.category.trim() : "";
    const price = Number(item.price ?? 0);
    const duration = typeof item.duration === "string" ? item.duration.trim() : "";
    const keywords = typeof item.keywords === "string" ? item.keywords.trim() : "";
    const replyTemplate = typeof item.replyTemplate === "string" ? item.replyTemplate.trim() : "";
    const check = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate
    });
    if (!check.valid) {
      const firstErr = Object.values(check.errors)[0] ?? "Produk tidak valid.";
      return { ok: false, error: `Produk #${i + 1} (${name || "tanpa nama"}): ${firstErr}` };
    }
    const rawAccounts = Array.isArray(item.accounts) ? item.accounts : [];
    const accounts = [];
    for (const accRaw of rawAccounts.slice(0, 500)) {
      if (!accRaw || typeof accRaw !== "object") continue;
      const rec = accRaw;
      const email = typeof rec.email === "string" ? rec.email.trim().slice(0, 160) : "";
      const password = typeof rec.password === "string" ? rec.password.trim().slice(0, 160) : "";
      const extraData = typeof rec.extraData === "string" ? rec.extraData.trim().slice(0, 1e3) : "";
      const accCheck = validateProductAccountInput({ email, password, extraData });
      if (!accCheck.valid) continue;
      const status = rec.status === "reserved" || rec.status === "sold" ? rec.status : "available";
      accounts.push({
        id: typeof rec.id === "string" && rec.id.trim() ? rec.id.trim().slice(0, 64) : `acc_${import_node_crypto3.default.randomUUID().slice(0, 8)}`,
        email,
        password,
        extraData,
        status,
        soldToOrderId: typeof rec.soldToOrderId === "string" ? rec.soldToOrderId : null,
        soldAt: typeof rec.soldAt === "string" ? rec.soldAt : null,
        createdAt: typeof rec.createdAt === "string" ? rec.createdAt : now
      });
    }
    validatedProducts.push({
      id: typeof item.id === "string" && item.id.trim() ? item.id.trim().slice(0, 64) : `prod_${import_node_crypto3.default.randomUUID().slice(0, 8)}`,
      name,
      category,
      price: Math.round(price),
      duration,
      stockStatus: VALID_STOCK_STATUSES.has(item.stockStatus) ? item.stockStatus : "tersedia",
      keywords,
      description: typeof item.description === "string" ? item.description.trim() : "",
      replyTemplate,
      autoReplyEnabled: item.autoReplyEnabled !== void 0 ? Boolean(item.autoReplyEnabled) : true,
      accounts,
      hitCount: Math.max(0, Math.round(Number(item.hitCount) || 0)),
      createdAt: typeof item.createdAt === "string" ? item.createdAt : now,
      updatedAt: now
    });
  }
  const rawSettings = obj.settings && typeof obj.settings === "object" ? obj.settings : {};
  const rawSched = rawSettings.schedule && typeof rawSettings.schedule === "object" ? rawSettings.schedule : {};
  const settings = {
    botEnabled: rawSettings.botEnabled !== void 0 ? Boolean(rawSettings.botEnabled) : true,
    defaultReplyEnabled: rawSettings.defaultReplyEnabled !== void 0 ? Boolean(rawSettings.defaultReplyEnabled) : true,
    defaultReplyText: typeof rawSettings.defaultReplyText === "string" && rawSettings.defaultReplyText.trim() ? rawSettings.defaultReplyText.trim().slice(0, 4e3) : DEFAULT_FALLBACK_REPLY_TEXT,
    ignoreGroupsByDefault: rawSettings.ignoreGroupsByDefault !== void 0 ? Boolean(rawSettings.ignoreGroupsByDefault) : true,
    ignoreContactsInWhitelistOnly: Boolean(rawSettings.ignoreContactsInWhitelistOnly),
    whitelist: Array.isArray(rawSettings.whitelist) ? rawSettings.whitelist.map((s) => String(s).trim()).filter(Boolean).slice(0, 200) : [],
    blacklist: Array.isArray(rawSettings.blacklist) ? rawSettings.blacklist.map((s) => String(s).trim()).filter(Boolean).slice(0, 200) : [],
    defaultCooldownSeconds: Math.max(
      0,
      Math.min(86400, Number(rawSettings.defaultCooldownSeconds ?? 60) || 0)
    ),
    typingIndicator: rawSettings.typingIndicator !== void 0 ? Boolean(rawSettings.typingIndicator) : true,
    schedule: {
      enabled: Boolean(rawSched.enabled),
      startTime: typeof rawSched.startTime === "string" && /^([01]\d|2[0-3]):([0-5]\d)$/.test(rawSched.startTime) ? rawSched.startTime : "08:00",
      endTime: typeof rawSched.endTime === "string" && /^([01]\d|2[0-3]):([0-5]\d)$/.test(rawSched.endTime) ? rawSched.endTime : "21:00",
      timezoneOffsetMinutes: Number.isFinite(Number(rawSched.timezoneOffsetMinutes)) ? Number(rawSched.timezoneOffsetMinutes) : 420
    }
  };
  let logs;
  if (Array.isArray(obj.logs)) {
    logs = obj.logs.filter((l) => Boolean(l && typeof l === "object")).slice(0, 200);
  }
  return {
    ok: true,
    data: {
      rules: validatedRules,
      products: validatedProducts,
      settings,
      logs
    }
  };
}
function buildInstallScript() {
  return `#!/usr/bin/env bash
set -euo pipefail

echo "=================================================="
echo "  Installer TeleBalas - Bot Auto-Reply Telegram   "
echo "=================================================="
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "[ERROR] Node.js tidak ditemukan. Silakan aktifkan Node.js 18+ di cPanel (Setup Node.js App)."
  exit 1
fi

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "[ERROR] Versi Node.js minimal 18. Versi terdeteksi: $(node -v)"
  exit 1
fi

echo "[1/4] Memeriksa & memasang dependensi Node.js..."
if [ -f "dist/index.html" ] && [ -f "app.cjs" ]; then
  npm install --omit=dev
else
  npm install
  npm run build
  npx esbuild server.ts --bundle --platform=node --format=cjs --outfile=app.cjs --external:express --external:dotenv --external:telegram --external:vite --external:jszip --external:esbuild --external:qrcode
fi

echo "[2/4] Menyiapkan direktori database (data/store.json)..."
mkdir -p data
chmod 700 data
if [ ! -f "data/store.json" ] && [ -f "database/telebalas-database.json" ]; then
  cp database/telebalas-database.json data/store.json
fi
if [ -f "data/store.json" ]; then
  chmod 600 data/store.json
fi

echo "[3/4] Menyiapkan file konfigurasi .env..."
if [ ! -f ".env" ]; then
  SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  ADMIN_PIN_VALUE=""
  if [ -t 0 ]; then
    read -r -p "Masukkan PIN Admin (4-8 digit, kosongkan untuk atur lewat web): " ADMIN_PIN_VALUE || true
  fi
  cat > .env <<EOF
NODE_ENV=production
PORT=3000
ADMIN_SESSION_SECRET=$SECRET
ADMIN_PIN=$ADMIN_PIN_VALUE
EOF
  chmod 600 .env
  echo "File .env berhasil dibuat."
else
  echo "File .env sudah ada, tidak ditimpa."
fi

echo "[4/4] Instalasi selesai!"
echo ""
echo "Cara menjalankan di cPanel (Setup Node.js App):"
echo "  - Application root         : $(pwd)"
echo "  - Application startup file : app.cjs"
echo "  - Application mode         : Production"
echo "  Lalu klik tombol RESTART di cPanel Node.js App."
echo ""
echo "Atau jalankan langsung via terminal / PM2:"
echo "  NODE_ENV=production node app.cjs"
echo "=================================================="
`;
}
function buildPhpWebInstaller() {
  return `<?php
/**
 * TeleBalas - Web Installer cPanel Shared Hosting (Tanpa SSH / Terminal)
 * ----------------------------------------------------------------------
 * Unggah file install.php ini bersama telebalas-cpanel-siap-pakai.zip
 * ke folder aplikasi cPanel Anda, lalu buka: https://domain-anda.com/install.php
 */
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

$baseDir = __DIR__;
$lockFile = $baseDir . '/.install.lock';
$defaultZip = 'telebalas-cpanel-siap-pakai.zip';

function h(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function detectSiteUrl(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'domain-anda.com';
    $host = preg_replace('/[^a-zA-Z0-9.:\\-]/', '', (string)$host);
    return $scheme . '://' . ($host ?: 'domain-anda.com');
}

function isSafeZipEntry(string $name): bool {
    if ($name === '' || strpos($name, "\\0") !== false) return false;
    if ($name[0] === '/' || $name[0] === '\\\\') return false;
    if (preg_match('/^[a-zA-Z]:/', $name)) return false;
    $normalized = str_replace('\\\\', '/', $name);
    $parts = explode('/', $normalized);
    foreach ($parts as $part) {
        if ($part === '..') return false;
    }
    return true;
}

function readLockData(string $lockFile): ?array {
    if (!is_file($lockFile)) return null;
    $raw = @file_get_contents($lockFile);
    if ($raw === false) return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

$lockData = readLockData($lockFile);

// Handle 1-click self-delete after install
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_installer') {
    $submittedToken = (string)($_POST['delete_token'] ?? '');
    $expectedToken = is_array($lockData) ? (string)($lockData['deleteToken'] ?? '') : '';
    if ($expectedToken !== '' && hash_equals($expectedToken, $submittedToken)) {
        $deleted = @unlink(__FILE__);
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installer Dihapus - TeleBalas</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#070b14;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px}.card{max-width:520px;background:#0f172a;border:1px solid #1e293b;border-radius:16px;padding:28px}h1{margin:0 0 10px;font-size:20px;color:#34d399}p{margin:0 0 14px;font-size:14px;line-height:1.6;color:#cbd5e1}a{display:inline-block;background:#0284c7;color:#fff;text-decoration:none;padding:10px 18px;border-radius:10px;font-weight:600;font-size:14px}</style></head><body><div class="card">';
        if ($deleted) {
            echo '<h1>File install.php Berhasil Dihapus</h1><p>Demi keamanan, file installer telah dihapus dari hosting Anda. Silakan lanjutkan langkah Setup Node.js App &amp; Cron Jobs di cPanel lalu buka website Anda.</p>';
        } else {
            echo '<h1>Gagal Menghapus Otomatis</h1><p>Silakan hapus file <code>install.php</code> secara manual melalui File Manager cPanel demi keamanan.</p>';
        }
        echo '<a href="/">Buka TeleBalas</a></div></body></html>';
        exit;
    }
}

$zipFiles = [];
foreach (glob($baseDir . '/*.zip') ?: [] as $zf) {
    $zipFiles[] = basename($zf);
}
usort($zipFiles, function ($a, $b) use ($defaultZip) {
    if ($a === $defaultZip) return -1;
    if ($b === $defaultZip) return 1;
    return strcmp($a, $b);
});

$phpOk = version_compare(PHP_VERSION, '7.4.0', '>=');
$zipExtOk = class_exists('ZipArchive');
$dirWritable = is_writable($baseDir);
$alreadyExtracted = is_file($baseDir . '/app.cjs') && is_file($baseDir . '/dist/index.html');
$siteUrl = detectSiteUrl();

$errors = [];
$installSuccess = false;
$summary = [];
$deleteToken = is_array($lockData) ? (string)($lockData['deleteToken'] ?? '') : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'install') {
    if ($lockData !== null) {
        $errors[] = 'Installer terkunci karena file .install.lock sudah ada. Hapus file .install.lock lewat File Manager cPanel hanya jika Anda benar-benar ingin mengulang instalasi.';
    } else {
        $selectedZip = basename((string)($_POST['zip_file'] ?? ''));
        $adminPin = trim((string)($_POST['admin_pin'] ?? ''));
        $overwriteStore = isset($_POST['overwrite_store']) && $_POST['overwrite_store'] === '1';

        if ($adminPin !== '' && !preg_match('/^\\d{4,8}$/', $adminPin)) {
            $errors[] = 'PIN Admin harus berupa 4 sampai 8 digit angka, atau kosongkan untuk diatur lewat web.';
        }

        if (!$dirWritable) {
            $errors[] = 'Direktori saat ini tidak memiliki izin tulis (writable). Periksa permission folder di File Manager cPanel (755).';
        }

        if (empty($errors)) {
            // 1. Extract ZIP if available and selected
            if ($selectedZip !== '' && in_array($selectedZip, $zipFiles, true)) {
                if (!$zipExtOk) {
                    $errors[] = 'Ekstensi PHP ZipArchive tidak aktif di hosting Anda. Ekstrak file ZIP secara manual lewat File Manager cPanel (klik kanan -> Extract), lalu jalankan ulang installer ini tanpa memilih ZIP.';
                } else {
                    $zip = new ZipArchive();
                    $zipPath = $baseDir . '/' . $selectedZip;
                    if ($zip->open($zipPath) !== true) {
                        $errors[] = 'Gagal membuka file ZIP: ' . $selectedZip;
                    } else {
                        $extractedCount = 0;
                        for ($i = 0; $i < $zip->numFiles; $i++) {
                            $entryName = (string)$zip->getNameIndex($i);
                            if (!isSafeZipEntry($entryName)) {
                                continue;
                            }
                            $cleanName = ltrim(str_replace('\\\\', '/', $entryName), '/');
                            if ($cleanName === '' || $cleanName === '.env' || $cleanName === 'install.php') {
                                continue;
                            }
                            if (!$overwriteStore && $cleanName === 'data/store.json' && is_file($baseDir . '/data/store.json')) {
                                continue;
                            }
                            $targetPath = $baseDir . '/' . $cleanName;
                            if (substr($cleanName, -1) === '/') {
                                if (!is_dir($targetPath)) {
                                    @mkdir($targetPath, 0755, true);
                                }
                                continue;
                            }
                            $parentDir = dirname($targetPath);
                            if (!is_dir($parentDir)) {
                                @mkdir($parentDir, 0755, true);
                            }
                            $content = $zip->getFromIndex($i);
                            if ($content !== false) {
                                @file_put_contents($targetPath, $content);
                                $extractedCount++;
                            }
                        }
                        $zip->close();
                        $summary[] = 'Berhasil mengekstrak ' . $extractedCount . ' file dari ' . $selectedZip . '.';
                    }
                }
            } elseif (!$alreadyExtracted) {
                $errors[] = 'File ZIP belum dipilih dan file aplikasi (app.cjs & dist/) belum ditemukan. Upload telebalas-cpanel-siap-pakai.zip terlebih dahulu.';
            } else {
                $summary[] = 'Menggunakan file aplikasi TeleBalas yang sudah terekstrak.';
            }
        }

        if (empty($errors)) {
            // 2. Prepare data/store.json
            $dataDir = $baseDir . '/data';
            if (!is_dir($dataDir)) {
                @mkdir($dataDir, 0700, true);
            } else {
                @chmod($dataDir, 0700);
            }
            $storePath = $dataDir . '/store.json';
            $backupJson = $baseDir . '/database/telebalas-database.json';
            if ((!is_file($storePath) || $overwriteStore) && is_file($backupJson)) {
                @copy($backupJson, $storePath);
                $summary[] = 'Database awal data/store.json berhasil disiapkan.';
            }
            if (is_file($storePath)) {
                @chmod($storePath, 0600);
            }

            // 3. Create .env safely if not present
            $envPath = $baseDir . '/.env';
            if (!is_file($envPath)) {
                $secret = bin2hex(random_bytes(32));
                $envLines = [
                    'NODE_ENV=production',
                    'PORT=3000',
                    'ADMIN_SESSION_SECRET=' . $secret,
                    'ADMIN_PIN=' . $adminPin,
                ];
                $written = @file_put_contents($envPath, implode(PHP_EOL, $envLines) . PHP_EOL);
                if ($written === false) {
                    $errors[] = 'Gagal menulis file .env. Periksa izin folder cPanel Anda.';
                } else {
                    @chmod($envPath, 0600);
                    $summary[] = $adminPin !== ''
                        ? 'File .env berhasil dibuat dengan ADMIN_PIN pilihan Anda.'
                        : 'File .env berhasil dibuat (PIN admin akan diatur saat pertama kali membuka website).';
                }
            } else {
                $summary[] = 'File .env sudah ada dan tetap dipertahankan.';
            }
        }

        if (empty($errors)) {
            $deleteToken = bin2hex(random_bytes(24));
            @file_put_contents(
                $lockFile,
                json_encode([
                    'installedAt' => gmdate('c'),
                    'deleteToken' => $deleteToken,
                ], JSON_PRETTY_PRINT)
            );
            @chmod($lockFile, 0600);
            $lockData = ['installedAt' => gmdate('c'), 'deleteToken' => $deleteToken];
            $installSuccess = true;
        }
    }
}

$cronCommand = 'curl -fsS ' . $siteUrl . '/api/keepalive >/dev/null 2>&1';
$appRootHint = basename($baseDir);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Installer cPanel Shared Hosting - TeleBalas</title>
  <style>
    :root{color-scheme:dark light}
    *{box-sizing:border-box}
    body{margin:0;padding:28px 16px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#060a13;color:#e2e8f0;line-height:1.55}
    .wrap{max-width:780px;margin:0 auto}
    .hero{background:linear-gradient(135deg,#0b1120,#111d38,#0e294d);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:24px 28px;margin-bottom:20px}
    .hero h1{margin:0 0 6px;font-size:22px;color:#fff}
    .hero p{margin:0;font-size:13.5px;color:#cbd5e1}
    .card{background:#0f1624;border:1px solid #1e293b;border-radius:16px;padding:22px 24px;margin-bottom:18px}
    .card h2{margin:0 0 12px;font-size:15.5px;color:#f8fafc}
    .checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
    .check{background:#0b1120;border:1px solid #1e293b;border-radius:12px;padding:12px 14px;font-size:13px}
    .ok{color:#34d399;font-weight:600}.bad{color:#fb7185;font-weight:600}.warn{color:#fbbf24;font-weight:600}
    label{display:block;font-size:12.5px;font-weight:600;color:#cbd5e1;margin-bottom:6px}
    input[type=text],input[type=password],select{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #334155;background:#090f1d;color:#f8fafc;font-size:14px;margin-bottom:14px}
    .checkline{display:flex;align-items:center;gap:8px;font-size:13px;color:#cbd5e1;margin-bottom:16px;cursor:pointer}
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:11px;padding:11px 20px;font-size:14px;font-weight:600;cursor:pointer;color:#fff;background:linear-gradient(90deg,#0284c7,#4f46e5)}
    .btn:hover{opacity:.95}
    .btn-danger{background:linear-gradient(90deg,#e11d48,#be123c)}
    .alert{border-radius:12px;padding:13px 16px;font-size:13.5px;margin-bottom:16px}
    .alert-err{background:rgba(225,29,72,.14);border:1px solid rgba(244,63,94,.35);color:#fecdd3}
    .alert-ok{background:rgba(16,185,129,.12);border:1px solid rgba(52,211,153,.35);color:#a7f3d0}
    .alert-warn{background:rgba(245,158,11,.12);border:1px solid rgba(251,191,36,.35);color:#fde68a}
    code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#070b14;border:1px solid #1e293b;border-radius:8px;color:#7dd3fc}
    code{padding:2px 6px;font-size:12.5px}
    pre{padding:12px 14px;overflow-x:auto;font-size:12.5px;margin:8px 0}
    ol{margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#cbd5e1}
    li{margin-bottom:9px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>TeleBalas \u2014 Installer Web cPanel Shared Hosting</h1>
      <p>Pasang website &amp; bot auto-reply Telegram 24/7 langsung dari browser tanpa SSH atau Terminal.</p>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-err">
        <strong>Instalasi belum dapat dilanjutkan:</strong>
        <ul style="margin:6px 0 0;padding-left:18px">
          <?php foreach ($errors as $err): ?>
            <li><?php echo h($err); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($installSuccess): ?>
      <div class="alert alert-ok">
        <strong>Instalasi File &amp; Database Selesai!</strong>
        <ul style="margin:6px 0 0;padding-left:18px">
          <?php foreach ($summary as $item): ?>
            <li><?php echo h($item); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="card">
        <h2>Langkah Berikutnya di cPanel (Tanpa SSH / Terminal)</h2>
        <ol>
          <li>Buka menu <strong>Setup Node.js App</strong> di cPanel Anda, lalu klik <strong>Create Application</strong>:
            <br>Node.js version: <code>18 / 20 / 22</code> \xB7 Mode: <code>Production</code> \xB7 Application root: <code><?php echo h($appRootHint); ?></code> \xB7 Application startup file: <code>app.cjs</code>
          </li>
          <li>Klik <strong>Create</strong>, lalu klik tombol <strong>Run NPM Install</strong> pada bagian Detected configuration files.</li>
          <li>Klik tombol <strong>Restart</strong> di bagian atas Setup Node.js App.</li>
          <li><strong>Agar Bot Aktif 24 Jam / 7 Hari Non-Stop:</strong> Buka menu <strong>Cron Jobs</strong> di cPanel, pilih jadwal <em>Once Per Five Minutes</em> (<code>*/5 * * * *</code>), lalu masukkan perintah ini:
            <pre><?php echo h($cronCommand); ?></pre>
            Cron Job GUI ini mencegah Shared Hosting menidurkan aplikasi Node.js dan menjaga koneksi MTProto Telegram tetap hidup 24/7.
          </li>
        </ol>
      </div>

      <?php if ($deleteToken !== ''): ?>
        <div class="card">
          <h2>Langkah Keamanan Wajib</h2>
          <p style="font-size:13.5px;color:#cbd5e1;margin-top:0">Hapus file <code>install.php</code> sekarang agar tidak bisa diakses pihak lain.</p>
          <form method="post">
            <input type="hidden" name="action" value="delete_installer">
            <input type="hidden" name="delete_token" value="<?php echo h($deleteToken); ?>">
            <button type="submit" class="btn btn-danger">Hapus install.php Sekarang</button>
          </form>
        </div>
      <?php endif; ?>

    <?php elseif ($lockData !== null): ?>
      <div class="alert alert-warn">
        <strong>Installer Sudah Terkunci (.install.lock ditemukan)</strong><br>
        TeleBalas sudah pernah diinstal pada folder ini pada <code><?php echo h((string)($lockData['installedAt'] ?? '-')); ?></code>. Jika Anda perlu menginstal ulang, hapus file <code>.install.lock</code> melalui File Manager cPanel.
      </div>
      <?php if ($deleteToken !== ''): ?>
        <div class="card">
          <form method="post">
            <input type="hidden" name="action" value="delete_installer">
            <input type="hidden" name="delete_token" value="<?php echo h($deleteToken); ?>">
            <button type="submit" class="btn btn-danger">Hapus install.php Sekarang</button>
          </form>
        </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="card">
        <h2>1. Pemeriksaan Hosting cPanel</h2>
        <div class="checks">
          <div class="check">Versi PHP: <span class="<?php echo $phpOk ? 'ok' : 'bad'; ?>"><?php echo h(PHP_VERSION); ?></span></div>
          <div class="check">Ekstensi ZipArchive: <span class="<?php echo $zipExtOk ? 'ok' : 'warn'; ?>"><?php echo $zipExtOk ? 'Tersedia' : 'Tidak Aktif (Ekstrak manual)'; ?></span></div>
          <div class="check">Izin Folder: <span class="<?php echo $dirWritable ? 'ok' : 'bad'; ?>"><?php echo $dirWritable ? 'Bisa Ditulis' : 'Read-Only'; ?></span></div>
          <div class="check">Status Aplikasi: <span class="ok"><?php echo $alreadyExtracted ? 'Sudah Terekstrak' : (count($zipFiles) > 0 ? 'ZIP Siap Ekstrak' : 'Menunggu ZIP'); ?></span></div>
        </div>
      </div>

      <form method="post" class="card">
        <input type="hidden" name="action" value="install">
        <h2>2. Konfigurasi &amp; Ekstrak Otomatis</h2>

        <label for="zip_file">Pilih Paket ZIP TeleBalas</label>
        <select id="zip_file" name="zip_file">
          <?php if ($alreadyExtracted): ?>
            <option value="">(Lewati ekstrak \u2014 file aplikasi sudah tersedia di folder ini)</option>
          <?php endif; ?>
          <?php foreach ($zipFiles as $zf): ?>
            <option value="<?php echo h($zf); ?>" <?php echo $zf === $defaultZip ? 'selected' : ''; ?>><?php echo h($zf); ?></option>
          <?php endforeach; ?>
          <?php if (empty($zipFiles) && !$alreadyExtracted): ?>
            <option value="">Belum ada file .zip di folder ini</option>
          <?php endif; ?>
        </select>

        <label for="admin_pin">PIN Admin Panel (4\u20138 digit angka, opsional)</label>
        <input id="admin_pin" name="admin_pin" type="password" inputmode="numeric" pattern="[0-9]{4,8}" maxlength="8" placeholder="Kosongkan untuk membuat PIN saat membuka website pertama kali">

        <label class="checkline">
          <input type="checkbox" name="overwrite_store" value="1">
          <span>Timpa <code>data/store.json</code> dengan database bawaan ZIP (centang hanya untuk instalasi baru)</span>
        </label>

        <button type="submit" class="btn">Ekstrak &amp; Pasang TeleBalas Sekarang</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
`;
}
function buildCpanelGuide() {
  return `PANDUAN INSTALASI TELEBALAS DI CPANEL SHARED HOSTING (TANPA SSH / TERMINAL)
===============================================================================

Paket ZIP ini sudah berisi:
1. install.php                    -> Installer Web GUI untuk cPanel Shared Hosting (TANPA SSH)
2. app.cjs                        -> File startup Node.js siap jalan untuk cPanel (Phusion Passenger)
3. dist/                          -> Frontend React yang sudah selesai di-build (siap pakai)
4. data/store.json                -> Database awal berisi aturan, produk jualan, dan pengaturan Anda
5. database/telebalas-database.json & .sql -> Cadangan database JSON & SQL (MySQL/phpMyAdmin)
6. install.sh                     -> Script installer otomatis (opsional jika punya SSH / VPS)

-------------------------------------------------------------------------------
CARA 1 (DIREKOMENDASIKAN): SHARED HOSTING CPANEL TANPA SSH / TERMINAL
-------------------------------------------------------------------------------
A. Pasang via Browser Installer (install.php):
1. Login ke cPanel hosting Anda, buka **File Manager**.
2. Masuk ke folder domain Anda (misal public_html atau folder khusus /home/user/telebalas).
3. Upload file \`telebalas-cpanel-siap-pakai.zip\` dan file \`install.php\` ke folder yang sama.
   (Atau upload ZIP, klik kanan -> Extract di File Manager jika lebih suka).
4. Buka browser dan kunjungi: https://domain-anda.com/install.php
5. Klik **"Ekstrak & Pasang TeleBalas Sekarang"**. Installer akan menyiapkan folder data,
   database store.json, dan file konfigurasi .env secara otomatis.
6. Klik tombol **"Hapus install.php Sekarang"** setelah instalasi selesai.

B. Aktifkan Aplikasi di cPanel (Setup Node.js App):
1. Di halaman utama cPanel, buka menu **Setup Node.js App**.
2. Klik **Create Application**:
   - Node.js version         : Pilih 18.x / 20.x / 22.x
   - Application mode        : Production
   - Application root        : folder tempat Anda mengekstrak file (misal: telebalas)
   - Application URL         : Pilih domain atau subdomain Anda
   - Application startup file: app.cjs
3. Klik **Create**, lalu klik tombol **Run NPM Install** (tidak perlu buka Terminal/SSH).
4. Klik tombol **Restart** di bagian atas halaman Setup Node.js App.

C. Wajib Agar Bot Aktif 24 Jam / 7 Hari Non-Stop (Menu Cron Jobs):
Shared hosting cPanel akan menidurkan aplikasi Node.js jika tidak ada akses HTTP selama
beberapa menit. Agar bot Telegram Anda tetap online & membalas otomatis 24/7 tanpa terputus:
1. Buka menu **Cron Jobs** di halaman utama cPanel (tersedia tanpa SSH).
2. Pada bagian *Common Settings*, pilih **Once Per Five Minutes (*/5 * * * *)**.
3. Pada kolom *Command*, masukkan:
   curl -fsS https://domain-anda.com/api/keepalive >/dev/null 2>&1
4. Klik **Add New Cron Job**.
Endpoint /api/keepalive menjaga Phusion Passenger tetap bangun sekaligus memicu
watchdog Telegram agar koneksi MTProto akun pribadi Anda otomatis menyambung kembali
jika sempat terputus jaringan.

-------------------------------------------------------------------------------
CARA 2 (OPSIONAL): INSTALL OTOMATIS VIA CPANEL TERMINAL / SSH / VPS
-------------------------------------------------------------------------------
1. Upload dan Extract file ZIP ini di folder tujuan (misal ~/telebalas).
2. Jalankan perintah berikut:
   cd ~/telebalas && chmod +x install.sh && bash install.sh
3. Jalankan dengan PM2 di VPS:
   pm2 start app.cjs --name telebalas && pm2 save
`;
}
function addDirectoryToZip(zip, rootDir, relDir, options = {}) {
  const fullDir = import_node_path2.default.resolve(rootDir, relDir);
  if (!fullDir.startsWith(rootDir + import_node_path2.default.sep) || !import_node_fs2.default.existsSync(fullDir)) {
    return;
  }
  const entries = import_node_fs2.default.readdirSync(fullDir, { withFileTypes: true });
  for (const entry of entries) {
    const relPath = import_node_path2.default.posix.join(relDir.split(import_node_path2.default.sep).join("/"), entry.name);
    const fullPath = import_node_path2.default.resolve(rootDir, relPath);
    if (!fullPath.startsWith(rootDir + import_node_path2.default.sep)) continue;
    if (entry.isDirectory()) {
      addDirectoryToZip(zip, rootDir, relPath, options);
    } else if (entry.isFile()) {
      if (options.excludeTestFiles && entry.name.endsWith(".test.ts")) continue;
      zip.file(relPath, import_node_fs2.default.readFileSync(fullPath));
    }
  }
}
async function buildCpanelBundleZip(store, includeLogs = true) {
  const rootDir = process.cwd();
  const zip = new import_jszip.default();
  const distIndex = import_node_path2.default.resolve(rootDir, "dist", "index.html");
  if (!import_node_fs2.default.existsSync(distIndex)) {
    const { build } = await import("vite");
    await build({ root: rootDir, logLevel: "silent" });
  }
  let appCjsBuffer = null;
  const serverEntry = import_node_path2.default.resolve(rootDir, "server.ts");
  if (import_node_fs2.default.existsSync(serverEntry)) {
    try {
      const esbuild = await import("esbuild");
      const result = await esbuild.build({
        entryPoints: [serverEntry],
        bundle: true,
        platform: "node",
        format: "cjs",
        write: false,
        external: ["express", "dotenv", "telegram", "vite", "jszip", "esbuild", "qrcode"]
      });
      if (result.outputFiles && result.outputFiles[0]) {
        appCjsBuffer = Buffer.from(result.outputFiles[0].contents);
      }
    } catch {
      const prebuiltAppCjs = import_node_path2.default.resolve(rootDir, "app.cjs");
      if (import_node_fs2.default.existsSync(prebuiltAppCjs)) {
        appCjsBuffer = import_node_fs2.default.readFileSync(prebuiltAppCjs);
      }
    }
  } else {
    const prebuiltAppCjs = import_node_path2.default.resolve(rootDir, "app.cjs");
    if (import_node_fs2.default.existsSync(prebuiltAppCjs)) {
      appCjsBuffer = import_node_fs2.default.readFileSync(prebuiltAppCjs);
    }
  }
  if (appCjsBuffer) {
    zip.file("app.cjs", appCjsBuffer);
  }
  const rootFiles = [
    "package.json",
    ".env.example",
    ".gitignore",
    "index.html",
    "metadata.json",
    "tsconfig.json",
    "vite.config.ts",
    "server.ts"
  ];
  for (const filename of rootFiles) {
    const full = import_node_path2.default.resolve(rootDir, filename);
    if (full.startsWith(rootDir + import_node_path2.default.sep) && import_node_fs2.default.existsSync(full)) {
      zip.file(filename, import_node_fs2.default.readFileSync(full));
    }
  }
  addDirectoryToZip(zip, rootDir, "src", { excludeTestFiles: true });
  addDirectoryToZip(zip, rootDir, "server", { excludeTestFiles: true });
  addDirectoryToZip(zip, rootDir, "dist");
  const sanitizedStore = buildSanitizedDatabaseExport(store, includeLogs);
  const storeJsonText = JSON.stringify(sanitizedStore, null, 2);
  zip.file("data/store.json", storeJsonText);
  zip.file("database/telebalas-database.json", storeJsonText);
  zip.file("database/telebalas-database.sql", generateSqlDump(store));
  zip.file("install.php", buildPhpWebInstaller());
  zip.file("install.sh", buildInstallScript(), { unixPermissions: "755" });
  zip.file("PANDUAN-CPANEL.txt", buildCpanelGuide());
  return zip.generateAsync({
    type: "nodebuffer",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
    platform: "UNIX"
  });
}

// server/gopayMerchant.ts
var import_node_crypto4 = __toESM(require("node:crypto"), 1);
var import_node_net = __toESM(require("node:net"), 1);
var import_qrcode = __toESM(require("qrcode"), 1);
var telegramSender = null;
var watchdogTimer = null;
var pollInFlight = false;
function registerTelegramSender(bridge) {
  telegramSender = bridge;
}
function validateMutationApiUrl(rawUrl) {
  const clean = rawUrl.trim();
  if (!clean) return { valid: true };
  let parsed;
  try {
    parsed = new URL(clean);
  } catch {
    return { valid: false, error: "Format URL Endpoint Mutasi GoPay tidak valid." };
  }
  if (parsed.protocol !== "https:") {
    return {
      valid: false,
      error: "URL Endpoint Mutasi GoPay wajib menggunakan protokol HTTPS yang aman."
    };
  }
  if (parsed.username || parsed.password) {
    return { valid: false, error: "URL tidak boleh menyertakan kredensial username/password." };
  }
  const host = parsed.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal")) {
    return { valid: false, error: "Host lokal/internal tidak diizinkan untuk polling API." };
  }
  const ipVersion = import_node_net.default.isIP(host);
  if (ipVersion === 4) {
    const parts = host.split(".").map(Number);
    const [a, b] = parts;
    if (a === 10 || a === 127 || a === 0 || a === 169 && b === 254 || a === 172 && b >= 16 && b <= 31 || a === 192 && b === 168 || a === 100 && b >= 64 && b <= 127) {
      return { valid: false, error: "Alamat IP privat/loopback tidak diizinkan." };
    }
  } else if (ipVersion === 6) {
    const cleanV6 = host.replace(/^\[|\]$/g, "").toLowerCase();
    if (cleanV6 === "::1" || cleanV6 === "::" || cleanV6.startsWith("fc") || cleanV6.startsWith("fd") || cleanV6.startsWith("fe80:")) {
      return { valid: false, error: "Alamat IPv6 privat/loopback tidak diizinkan." };
    }
  }
  return { valid: true };
}
function releaseAccountReservation(product, accountId) {
  if (!product || !accountId) return;
  const acc = product.accounts?.find((a) => a.id === accountId);
  if (acc && acc.status === "reserved") {
    acc.status = "available";
    acc.soldToOrderId = null;
    acc.soldAt = null;
  }
}
function expireStaleOrders(store = loadStore()) {
  const nowMs = Date.now();
  let changed = 0;
  for (const order of store.orders) {
    if (order.status !== "pending") continue;
    const expMs = Date.parse(order.expiresAt);
    if (Number.isFinite(expMs) && nowMs > expMs) {
      order.status = "expired";
      const product = store.products.find((p) => p.id === order.productId);
      releaseAccountReservation(product, order.reservedAccountId);
      changed += 1;
    }
  }
  if (changed > 0) {
    saveStore(store);
  }
  return changed;
}
function allocateUniqueAmount(store, basePrice) {
  const activeAmounts = new Set(
    store.orders.filter((o) => o.status === "pending").map((o) => o.totalAmount)
  );
  const startOffset = import_node_crypto4.default.randomInt(1, 500);
  for (let i = 0; i < 499; i++) {
    const code = (startOffset + i - 1) % 499 + 1;
    const candidate = basePrice + code;
    if (!activeAmounts.has(candidate)) {
      return { uniqueCode: code, totalAmount: candidate };
    }
  }
  for (let code = 500; code <= 999; code++) {
    const candidate = basePrice + code;
    if (!activeAmounts.has(candidate)) {
      return { uniqueCode: code, totalAmount: candidate };
    }
  }
  throw new Error("Antrean nominal unik sedang penuh. Coba beberapa saat lagi.");
}
function formatQrisInvoiceCaption(order, merchantName) {
  const expiryDate = new Date(order.expiresAt);
  const wibMs = expiryDate.getTime() + 420 * 6e4;
  const d = new Date(wibMs);
  const hh = String(d.getUTCHours()).padStart(2, "0");
  const mm = String(d.getUTCMinutes()).padStart(2, "0");
  return [
    `\u{1F9FE} *INVOICE QRIS GOPAY MERCHANT*`,
    `Merchant: *${merchantName}*`,
    `Kode Order: \`${order.orderCode}\``,
    `Produk: *${order.productName}*`,
    ``,
    `\u{1F4B0} *Nominal Transfer WAJIB PERSIS:*`,
    `*${formatRupiah(order.totalAmount)}*`,
    `_(Harga ${formatRupiah(order.basePrice)} + Kode Unik ${order.uniqueCode})_`,
    ``,
    `Scan QRIS di atas via *GoPay / Dana / OVO / ShopeePay / BCA / Mobile Banking*.`,
    `\u26A0\uFE0F Pastikan transfer nominal persis sampai 3 digit terakhir agar terbaca otomatis oleh sistem mutasi GoPay.`,
    `\u23F1 Berlaku sampai pukul ${hh}:${mm} WIB. Akun langsung dikirim ke chat ini begitu pembayaran masuk!`
  ].join("\n");
}
async function createQrisOrder(params) {
  const store = loadStore();
  expireStaleOrders(store);
  if (!store.gopayConfig.enabled) {
    return {
      ok: false,
      error: "Integrasi pembayaran QRIS GoPay Merchant sedang dinonaktifkan admin."
    };
  }
  const staticCheck = validateStaticQris(store.gopayConfig.staticQris);
  if (!staticCheck.valid) {
    return {
      ok: false,
      error: staticCheck.error || "String QRIS Statis GoPay Merchant belum dikonfigurasi dengan valid."
    };
  }
  const product = store.products.find((p) => p.id === params.productId);
  if (!product) {
    return { ok: false, error: "Produk tidak ditemukan." };
  }
  if (product.price <= 0) {
    return { ok: false, error: `Produk "${product.name}" belum memiliki harga di atas Rp 0.` };
  }
  const availableAcc = (product.accounts ?? []).find(
    (a) => a.status === "available"
  );
  if (product.stockStatus === "habis" || !availableAcc) {
    return {
      ok: false,
      error: `Maaf, stok detail akun untuk *${product.name}* sedang habis. Hubungi admin untuk isi ulang stok.`
    };
  }
  const { uniqueCode, totalAmount } = allocateUniqueAmount(store, Math.round(product.price));
  const dynamicQris = generateDynamicQris(store.gopayConfig.staticQris, totalAmount);
  const qrPngBuffer = await import_qrcode.default.toBuffer(dynamicQris, {
    type: "png",
    width: 420,
    margin: 2,
    errorCorrectionLevel: "M"
  });
  const qrDataUrl = `data:image/png;base64,${qrPngBuffer.toString("base64")}`;
  const now = /* @__PURE__ */ new Date();
  const expiryMinutes = Math.max(3, Math.min(180, store.gopayConfig.orderExpiryMinutes || 15));
  const expiresAt = new Date(now.getTime() + expiryMinutes * 6e4).toISOString();
  const orderId = `ord_${import_node_crypto4.default.randomUUID().slice(0, 8)}`;
  const orderCode = `GP-${import_node_crypto4.default.randomUUID().slice(0, 6).toUpperCase()}`;
  availableAcc.status = "reserved";
  availableAcc.soldToOrderId = orderId;
  const order = {
    id: orderId,
    orderCode,
    productId: product.id,
    productName: product.name,
    basePrice: Math.round(product.price),
    uniqueCode,
    totalAmount,
    buyerChatId: params.buyerChatId,
    buyerSenderId: params.buyerSenderId,
    buyerName: params.buyerName || "Pembeli",
    buyerUsername: params.buyerUsername ?? null,
    source: params.source,
    qrisPayload: dynamicQris,
    status: "pending",
    reservedAccountId: availableAcc.id,
    deliveredAccount: null,
    deliveryPending: false,
    deliveryError: null,
    mutationRef: null,
    paidVia: null,
    createdAt: now.toISOString(),
    expiresAt,
    paidAt: null,
    deliveredAt: null
  };
  store.orders = [order, ...store.orders].slice(0, 250);
  saveStore(store);
  const merchantName = store.gopayConfig.merchantName.trim() || extractMerchantNameFromQris(store.gopayConfig.staticQris) || "GOPAY MERCHANT";
  return {
    ok: true,
    order,
    qrPngBuffer,
    qrDataUrl,
    invoiceCaption: formatQrisInvoiceCaption(order, merchantName)
  };
}
async function deliverPaidOrder(order) {
  const deliveryText = formatAccountDeliveryMessage({
    buyerName: order.buyerName,
    order,
    account: order.deliveredAccount
  });
  const store = loadStore();
  const storedOrder = store.orders.find((o) => o.id === order.id);
  if (!storedOrder) return;
  if (storedOrder.source === "simulator") {
    storedOrder.status = "delivered";
    storedOrder.deliveredAt = (/* @__PURE__ */ new Date()).toISOString();
    storedOrder.deliveryPending = false;
    storedOrder.deliveryError = null;
    saveStore(store);
    appendLog({
      senderId: storedOrder.buyerSenderId,
      senderName: storedOrder.buyerName,
      senderUsername: storedOrder.buyerUsername,
      chatType: "private",
      incomingText: `[Mutasi QRIS GoPay ${formatRupiah(storedOrder.totalAmount)}]`,
      matchedRuleId: storedOrder.productId,
      matchedRuleName: `QRIS Auto-Delivery: ${storedOrder.productName}`,
      replyText: deliveryText.slice(0, 500),
      outcome: "simulated",
      reason: `Pembayaran ${storedOrder.orderCode} terbaca (${storedOrder.paidVia ?? "GoPay"}) & akun terkirim.`
    });
    return;
  }
  if (!telegramSender || !telegramSender.isReady()) {
    storedOrder.deliveryPending = true;
    storedOrder.deliveryError = "Koneksi Telegram belum aktif; akan dikirim otomatis saat tersambung.";
    saveStore(store);
    return;
  }
  try {
    await telegramSender.sendDirectMessage(storedOrder.buyerChatId, deliveryText);
    storedOrder.status = "delivered";
    storedOrder.deliveredAt = (/* @__PURE__ */ new Date()).toISOString();
    storedOrder.deliveryPending = false;
    storedOrder.deliveryError = null;
    saveStore(store);
    appendLog({
      senderId: storedOrder.buyerSenderId,
      senderName: storedOrder.buyerName,
      senderUsername: storedOrder.buyerUsername,
      chatType: "private",
      incomingText: `[Mutasi GoPay ${formatRupiah(storedOrder.totalAmount)}]`,
      matchedRuleId: storedOrder.productId,
      matchedRuleName: `QRIS Auto-Delivery: ${storedOrder.productName}`,
      replyText: deliveryText.slice(0, 500),
      outcome: "replied",
      reason: `Pembayaran ${storedOrder.orderCode} otomatis terverifikasi via mutasi GoPay & detail akun terkirim.`
    });
  } catch (err) {
    storedOrder.deliveryPending = true;
    storedOrder.deliveryError = err instanceof Error ? err.message : "Gagal mengirim detail akun ke Telegram pembeli.";
    saveStore(store);
  }
}
async function processIncomingMutation(params) {
  const cleanAmount = Math.round(params.amount);
  const store = loadStore();
  expireStaleOrders(store);
  const cleanRef = params.mutationRef?.trim().slice(0, 120) || `MUT-${import_node_crypto4.default.randomUUID().slice(0, 8).toUpperCase()}`;
  if (params.mutationRef?.trim()) {
    const existingMut = store.mutations.find((m) => m.mutationRef === cleanRef);
    if (existingMut) {
      return { matched: Boolean(existingMut.matchedOrderCode), duplicate: true, mutation: existingMut };
    }
  }
  const matchedOrder = store.orders.find(
    (o) => o.status === "pending" && o.totalAmount === cleanAmount
  );
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const mutationEntry = {
    id: `mut_${import_node_crypto4.default.randomUUID().slice(0, 8)}`,
    mutationRef: cleanRef,
    amount: cleanAmount,
    source: params.source,
    senderName: params.senderName?.trim() || null,
    matchedOrderCode: matchedOrder?.orderCode ?? null,
    rawSummary: params.rawSummary.slice(0, 300),
    receivedAt: nowIso
  };
  store.mutations = [mutationEntry, ...store.mutations].slice(0, 200);
  if (matchedOrder) {
    matchedOrder.status = "paid";
    matchedOrder.paidAt = nowIso;
    matchedOrder.mutationRef = cleanRef;
    matchedOrder.paidVia = params.source === "api_poll" ? "GoPay Merchant API" : params.source === "webhook" ? "Webhook Notifikasi GoPay" : "Simulasi Mutasi";
    const product = store.products.find((p) => p.id === matchedOrder.productId);
    if (product) {
      const account = matchedOrder.reservedAccountId && product.accounts?.find((a) => a.id === matchedOrder.reservedAccountId) || product.accounts?.find((a) => a.status === "available");
      if (account) {
        account.status = "sold";
        account.soldToOrderId = matchedOrder.id;
        account.soldAt = nowIso;
        matchedOrder.deliveredAccount = {
          email: account.email,
          password: account.password,
          extraData: account.extraData
        };
      }
      product.hitCount += 1;
      product.updatedAt = nowIso;
      if (getAvailableAccountCount(product) === 0) {
        product.stockStatus = "habis";
      }
    }
  }
  saveStore(store);
  if (matchedOrder) {
    await deliverPaidOrder(matchedOrder);
    const refreshed = loadStore().orders.find((o) => o.id === matchedOrder.id) ?? matchedOrder;
    return {
      matched: true,
      duplicate: false,
      mutation: mutationEntry,
      order: refreshed
    };
  }
  return {
    matched: false,
    duplicate: false,
    mutation: mutationEntry
  };
}
async function retryOrderDelivery(orderId) {
  const store = loadStore();
  const order = store.orders.find((o) => o.id === orderId);
  if (!order) {
    return { ok: false, error: "Order tidak ditemukan." };
  }
  if (order.status !== "paid" && order.status !== "delivered") {
    return { ok: false, error: "Order belum berstatus lunas." };
  }
  await deliverPaidOrder(order);
  const updated = loadStore().orders.find((o) => o.id === orderId);
  return { ok: true, order: updated };
}
async function retryPendingDeliveries() {
  const store = loadStore();
  const pending = store.orders.filter(
    (o) => o.status === "paid" && o.deliveryPending && o.source === "telegram"
  );
  for (const ord of pending) {
    await deliverPaidOrder(ord);
  }
}
function cancelOrder(orderId) {
  const store = loadStore();
  const order = store.orders.find((o) => o.id === orderId);
  if (!order) {
    return { ok: false, error: "Order tidak ditemukan." };
  }
  if (order.status !== "pending") {
    return { ok: false, error: "Hanya order berstatus Menunggu yang dapat dibatalkan." };
  }
  order.status = "cancelled";
  const product = store.products.find((p) => p.id === order.productId);
  releaseAccountReservation(product, order.reservedAccountId);
  saveStore(store);
  return { ok: true, order };
}
function extractAmountFromApiItem(rec) {
  const typeVal = String(rec.type ?? rec.mutation_type ?? rec.direction ?? "").toLowerCase();
  if (typeVal === "db" || typeVal === "debit" || typeVal === "out" || typeVal === "expense") {
    return null;
  }
  const candidateFields = [
    rec.amount,
    rec.nominal,
    rec.credit,
    rec.gross_amount,
    rec.total,
    rec.value
  ];
  for (const raw of candidateFields) {
    if (typeof raw === "number" && Number.isFinite(raw) && raw > 0) {
      return Math.round(raw);
    }
    if (typeof raw === "string" && raw.trim()) {
      const parsedFromStr = parseGoPayNotificationAmount(`Rp ${raw.trim()}`);
      if (parsedFromStr) return parsedFromStr;
    }
  }
  const textField = rec.text ?? rec.message ?? rec.notification ?? rec.description ?? rec.title;
  if (typeof textField === "string" && textField.trim()) {
    return parseGoPayNotificationAmount(textField);
  }
  return null;
}
async function pollGoPayMerchantMutations() {
  if (pollInFlight) {
    return {
      ok: true,
      statusMessage: "Pengecekan mutasi sedang berjalan.",
      processedCount: 0,
      matchedCount: 0
    };
  }
  const store = loadStore();
  expireStaleOrders(store);
  const url = store.gopayConfig.mutationApiUrl.trim();
  if (!url) {
    return {
      ok: false,
      statusMessage: "URL Endpoint Mutasi GoPay belum diisi.",
      processedCount: 0,
      matchedCount: 0
    };
  }
  const urlCheck = validateMutationApiUrl(url);
  if (!urlCheck.valid) {
    store.gopayConfig.lastPolledAt = (/* @__PURE__ */ new Date()).toISOString();
    store.gopayConfig.lastPollStatus = urlCheck.error ?? "URL tidak valid.";
    saveStore(store);
    return {
      ok: false,
      statusMessage: urlCheck.error ?? "URL tidak valid.",
      processedCount: 0,
      matchedCount: 0
    };
  }
  pollInFlight = true;
  try {
    const headers = {
      Accept: "application/json"
    };
    if (store.gopayConfig.apiToken) {
      headers.Authorization = `Bearer ${store.gopayConfig.apiToken}`;
    }
    const res = await fetch(url, {
      method: "GET",
      headers,
      redirect: "error",
      signal: AbortSignal.timeout(8e3)
    });
    if (!res.ok) {
      const msg = `Endpoint Mutasi merespons HTTP ${res.status}`;
      store.gopayConfig.lastPolledAt = (/* @__PURE__ */ new Date()).toISOString();
      store.gopayConfig.lastPollStatus = msg;
      saveStore(store);
      return { ok: false, statusMessage: msg, processedCount: 0, matchedCount: 0 };
    }
    const payload = await res.json();
    let items = [];
    if (Array.isArray(payload)) {
      items = payload;
    } else if (payload && typeof payload === "object") {
      const obj = payload;
      const nested = obj.data ?? obj.mutations ?? obj.transactions ?? obj.records ?? obj.results ?? obj.items;
      if (Array.isArray(nested)) {
        items = nested;
      } else if (nested && typeof nested === "object") {
        const inner = nested.mutations ?? nested.transactions ?? nested.hits;
        if (Array.isArray(inner)) items = inner;
      }
    }
    let processedCount = 0;
    let matchedCount = 0;
    for (const rawItem of items.slice(0, 50)) {
      if (!rawItem || typeof rawItem !== "object") continue;
      const rec = rawItem;
      const amount = extractAmountFromApiItem(rec);
      if (!amount) continue;
      const refCandidate = rec.mutation_id ?? rec.transaction_id ?? rec.reference_id ?? rec.order_id ?? rec.id;
      const mutationRef = refCandidate ? String(refCandidate) : void 0;
      const senderName = typeof rec.sender_name === "string" ? rec.sender_name : typeof rec.customer_name === "string" ? rec.customer_name : typeof rec.buyer_name === "string" ? rec.buyer_name : null;
      const summary = typeof rec.description === "string" ? rec.description : typeof rec.note === "string" ? rec.note : `Mutasi masuk ${formatRupiah(amount)}`;
      const outcome = await processIncomingMutation({
        amount,
        mutationRef,
        source: "api_poll",
        senderName,
        rawSummary: summary
      });
      if (!outcome.duplicate) {
        processedCount += 1;
        if (outcome.matched) matchedCount += 1;
      }
    }
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    const fresh = loadStore();
    fresh.gopayConfig.lastPolledAt = nowIso;
    fresh.gopayConfig.lastPollStatus = `Terhubung OK \xB7 ${processedCount} mutasi baru (${matchedCount} order cocok)`;
    saveStore(fresh);
    return {
      ok: true,
      statusMessage: fresh.gopayConfig.lastPollStatus,
      processedCount,
      matchedCount
    };
  } catch (err) {
    const msg = err instanceof Error ? `Gagal polling API mutasi: ${err.message}` : "Gagal polling API mutasi.";
    const fresh = loadStore();
    fresh.gopayConfig.lastPolledAt = (/* @__PURE__ */ new Date()).toISOString();
    fresh.gopayConfig.lastPollStatus = msg;
    saveStore(fresh);
    return { ok: false, statusMessage: msg, processedCount: 0, matchedCount: 0 };
  } finally {
    pollInFlight = false;
  }
}
function startPaymentWatchdog() {
  if (watchdogTimer) return;
  watchdogTimer = setInterval(() => {
    const store = loadStore();
    expireStaleOrders(store);
    const hasPending = store.orders.some((o) => o.status === "pending");
    if (store.gopayConfig.enabled && store.gopayConfig.pollingEnabled && store.gopayConfig.mutationApiUrl.trim() && hasPending) {
      const intervalMs = Math.max(10, store.gopayConfig.pollIntervalSeconds || 20) * 1e3;
      const lastMs = store.gopayConfig.lastPolledAt ? Date.parse(store.gopayConfig.lastPolledAt) : 0;
      if (Date.now() - lastMs >= intervalMs) {
        void pollGoPayMerchantMutations();
      }
    }
  }, 15e3);
  if (typeof watchdogTimer.unref === "function") {
    watchdogTimer.unref();
  }
}

// server/telegramManager.ts
var import_telegram = require("telegram");
var import_events = require("telegram/events/index.js");
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var TelegramUserbotManager = class {
  constructor() {
    this.client = null;
    this.status = "disconnected";
    this.errorMessage = null;
    this.pending = {};
    this.cooldownMap = /* @__PURE__ */ new Map();
    this.selfId = null;
    this.listenerAttached = false;
    this.shouldStayConnected = false;
    this.watchdogTimer = null;
    this.lastHeartbeatAt = 0;
    this.reconnectingPromise = null;
  }
  getPublicAccount() {
    return buildPublicAccount(this.status, this.errorMessage);
  }
  isReady() {
    return Boolean(this.client && this.client.connected && this.status === "connected");
  }
  resolvePeerTarget(chatId) {
    const trimmed = chatId.trim();
    if (/^-?\d+$/.test(trimmed)) {
      const asNum = Number(trimmed);
      if (Number.isSafeInteger(asNum)) return asNum;
    }
    return trimmed;
  }
  async sendDirectMessage(chatId, text) {
    if (!this.client || !this.client.connected) {
      throw new Error("Koneksi Telegram sedang tidak aktif.");
    }
    await this.client.sendMessage(this.resolvePeerTarget(chatId), {
      message: text,
      parseMode: "markdown"
    });
  }
  async sendPhotoWithCaption(chatId, pngBuffer, caption, replyTo) {
    if (!this.client || !this.client.connected) {
      throw new Error("Koneksi Telegram sedang tidak aktif.");
    }
    const target = this.resolvePeerTarget(chatId);
    const namedFile = Object.assign(Buffer.from(pngBuffer), { name: "qris-gopay.png" });
    try {
      await this.client.sendFile(target, {
        file: namedFile,
        caption,
        parseMode: "markdown",
        replyTo
      });
    } catch {
      await this.client.sendMessage(target, {
        message: caption,
        parseMode: "markdown",
        replyTo
      });
    }
  }
  startWatchdog() {
    if (this.watchdogTimer) return;
    this.watchdogTimer = setInterval(() => {
      void this.ensureConnected();
    }, 45e3);
    if (typeof this.watchdogTimer.unref === "function") {
      this.watchdogTimer.unref();
    }
  }
  stopWatchdog() {
    if (this.watchdogTimer) {
      clearInterval(this.watchdogTimer);
      this.watchdogTimer = null;
    }
  }
  async ensureConnected() {
    if (!this.shouldStayConnected) return;
    if (this.status === "awaiting_code" || this.status === "awaiting_password") return;
    if (this.reconnectingPromise) {
      await this.reconnectingPromise;
      return;
    }
    const store = loadStore();
    const { apiId, apiHash, sessionString } = store.credentials;
    if (!apiId || !apiHash || !sessionString) return;
    if (this.client && this.client.connected && this.status === "connected") {
      const now = Date.now();
      if (now - this.lastHeartbeatAt >= 4 * 6e4) {
        try {
          await this.client.getMe();
          this.lastHeartbeatAt = now;
        } catch {
          await this.reconnectWithSavedSession(apiId, apiHash, sessionString);
        }
      }
      return;
    }
    await this.reconnectWithSavedSession(apiId, apiHash, sessionString);
  }
  async reconnectWithSavedSession(apiId, apiHash, sessionString) {
    if (this.reconnectingPromise) {
      await this.reconnectingPromise;
      return;
    }
    this.reconnectingPromise = (async () => {
      try {
        this.status = "connecting";
        this.errorMessage = null;
        await this.connectClientWithSession(apiId, apiHash, sessionString);
      } catch (err) {
        this.status = "error";
        this.errorMessage = err instanceof Error ? `Menyambung ulang otomatis: ${err.message}` : "Menyambung ulang koneksi 24/7 gagal sementara.";
      } finally {
        this.reconnectingPromise = null;
      }
    })();
    await this.reconnectingPromise;
  }
  async initFromSavedSession() {
    const store = loadStore();
    const { apiId, apiHash, sessionString } = store.credentials;
    if (!apiId || !apiHash || !sessionString) {
      this.shouldStayConnected = false;
      this.status = "disconnected";
      return;
    }
    this.shouldStayConnected = true;
    this.startWatchdog();
    try {
      this.status = "connecting";
      this.errorMessage = null;
      await this.connectClientWithSession(apiId, apiHash, sessionString);
    } catch (err) {
      this.status = "error";
      this.errorMessage = err instanceof Error ? `Gagal menyambungkan ulang sesi tersimpan: ${err.message}` : "Gagal menyambungkan ulang sesi tersimpan.";
    }
  }
  async tearDownClient() {
    this.pending.rejectCode?.(new Error("Sesi login dibatalkan."));
    this.pending.rejectPassword?.(new Error("Sesi login dibatalkan."));
    this.pending = {};
    this.listenerAttached = false;
    this.selfId = null;
    if (this.client) {
      try {
        await this.client.disconnect();
      } catch {
      }
      this.client = null;
    }
  }
  attachMessageListener(client) {
    if (this.listenerAttached) return;
    this.listenerAttached = true;
    client.addEventHandler(async (event) => {
      try {
        const message = event.message;
        if (!message) return;
        if (message.out) return;
        const text = typeof message.message === "string" ? message.message : "";
        if (!text.trim()) return;
        const sender = await message.getSender();
        const senderId = sender?.id ? String(sender.id) : String(message.chatId ?? "unknown");
        if (this.selfId && senderId === this.selfId) return;
        if (senderId === "777000") return;
        if (sender && "bot" in sender && sender.bot) return;
        const isGroup = Boolean(event.isGroup || event.isChannel);
        if (event.isChannel && !event.isGroup) return;
        const firstName = sender && "firstName" in sender && typeof sender.firstName === "string" ? sender.firstName : "";
        const lastName = sender && "lastName" in sender && typeof sender.lastName === "string" ? sender.lastName : "";
        const title = sender && "title" in sender && typeof sender.title === "string" ? sender.title : "";
        const senderName = [firstName, lastName].filter(Boolean).join(" ") || title || "Pengguna";
        const senderUsername = sender && "username" in sender && typeof sender.username === "string" ? sender.username : null;
        const chatId = message.chatId ? String(message.chatId) : senderId;
        const store = loadStore();
        const isBlacklisted = store.settings.blacklist.some((entry) => {
          const norm = normalizeIdentifier(entry);
          return norm === normalizeIdentifier(senderId) || senderUsername && norm === normalizeIdentifier(senderUsername);
        });
        const passesWhitelist = !store.settings.ignoreContactsInWhitelistOnly || store.settings.whitelist.some((entry) => {
          const norm = normalizeIdentifier(entry);
          return norm === normalizeIdentifier(senderId) || senderUsername && norm === normalizeIdentifier(senderUsername);
        });
        if (store.settings.botEnabled && !(isGroup && store.settings.ignoreGroupsByDefault) && !isBlacklisted && passesWhitelist && store.gopayConfig.enabled) {
          const orderedProduct = detectOrderIntent(text, store.products);
          if (orderedProduct) {
            if (store.settings.typingIndicator && message.chatId) {
              try {
                await client.invoke(
                  new import_telegram.Api.messages.SetTyping({
                    peer: message.chatId,
                    action: new import_telegram.Api.SendMessageTypingAction()
                  })
                );
              } catch {
              }
            }
            const orderRes = await createQrisOrder({
              productId: orderedProduct.id,
              buyerChatId: chatId,
              buyerSenderId: senderId,
              buyerName: senderName,
              buyerUsername: senderUsername,
              source: "telegram"
            });
            if (!orderRes.ok || !orderRes.order || !orderRes.qrPngBuffer || !orderRes.invoiceCaption) {
              const fallbackNotice = orderRes.error || `Pesanan untuk ${orderedProduct.name} belum dapat diproses.`;
              await client.sendMessage(message.chatId ?? senderId, {
                message: fallbackNotice,
                parseMode: "markdown",
                replyTo: message.id
              });
              appendLog({
                senderId,
                senderName,
                senderUsername,
                chatType: isGroup ? "group" : "private",
                incomingText: text.slice(0, 300),
                matchedRuleId: orderedProduct.id,
                matchedRuleName: `QRIS Order Gagal: ${orderedProduct.name}`,
                replyText: fallbackNotice,
                outcome: "replied",
                reason: orderRes.error || "Stok atau QRIS tidak siap."
              });
              return;
            }
            await this.sendPhotoWithCaption(
              chatId,
              orderRes.qrPngBuffer,
              orderRes.invoiceCaption,
              message.id
            );
            appendLog({
              senderId,
              senderName,
              senderUsername,
              chatType: isGroup ? "group" : "private",
              incomingText: text.slice(0, 300),
              matchedRuleId: orderedProduct.id,
              matchedRuleName: `QRIS Invoice: ${orderedProduct.name}`,
              replyText: `Invoice ${orderRes.order.orderCode} (${formatRupiah(orderRes.order.totalAmount)}) dikirim beserta QRIS GoPay.`,
              outcome: "replied",
              reason: `Menunggu pembayaran mutasi GoPay sebesar ${formatRupiah(orderRes.order.totalAmount)}.`
            });
            return;
          }
        }
        const evaluation = matchMessageToRules(
          {
            senderId,
            senderName,
            senderUsername,
            chatId,
            chatType: isGroup ? "group" : "private",
            text
          },
          store.rules,
          store.settings,
          this.cooldownMap,
          /* @__PURE__ */ new Date(),
          {},
          store.products
        );
        const matchedLabel = evaluation.matchedRule ? evaluation.matchedRule.name : evaluation.matchedProduct ? `Produk: ${evaluation.matchedProduct.name}` : evaluation.matchedDefaultReply ? "Balasan Default (Semua Pesan)" : null;
        const matchedId = evaluation.matchedRule?.id ?? evaluation.matchedProduct?.id ?? (evaluation.matchedDefaultReply ? "default_reply" : null);
        if (!evaluation.shouldReply || !evaluation.renderedReply) {
          appendLog({
            senderId,
            senderName,
            senderUsername,
            chatType: isGroup ? "group" : "private",
            incomingText: text.slice(0, 300),
            matchedRuleId: matchedId,
            matchedRuleName: matchedLabel,
            replyText: null,
            outcome: "skipped",
            reason: evaluation.reason
          });
          return;
        }
        if (evaluation.cooldownKey) {
          this.cooldownMap.set(evaluation.cooldownKey, Date.now());
        }
        if (store.settings.typingIndicator && message.chatId) {
          try {
            await client.invoke(
              new import_telegram.Api.messages.SetTyping({
                peer: message.chatId,
                action: new import_telegram.Api.SendMessageTypingAction()
              })
            );
          } catch {
          }
        }
        if (evaluation.delayMs > 0) {
          await sleep(Math.min(evaluation.delayMs, 15e3));
        }
        await client.sendMessage(message.chatId ?? senderId, {
          message: evaluation.renderedReply,
          replyTo: evaluation.quoteOriginal ? message.id : void 0
        });
        const freshStore = loadStore();
        if (evaluation.matchedRule) {
          const ruleRef = freshStore.rules.find((r) => r.id === evaluation.matchedRule?.id);
          if (ruleRef) {
            ruleRef.hitCount += 1;
            ruleRef.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            saveStore(freshStore);
          }
        } else if (evaluation.matchedProduct) {
          const prodRef = freshStore.products.find(
            (p) => p.id === evaluation.matchedProduct?.id
          );
          if (prodRef) {
            prodRef.hitCount += 1;
            prodRef.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            saveStore(freshStore);
          }
        }
        appendLog({
          senderId,
          senderName,
          senderUsername,
          chatType: isGroup ? "group" : "private",
          incomingText: text.slice(0, 300),
          matchedRuleId: matchedId,
          matchedRuleName: matchedLabel,
          replyText: evaluation.renderedReply.slice(0, 500),
          outcome: "replied",
          reason: evaluation.reason
        });
      } catch (err) {
        appendLog({
          senderId: "system",
          senderName: "Sistem Telegram",
          senderUsername: null,
          chatType: "private",
          incomingText: "-",
          matchedRuleId: null,
          matchedRuleName: null,
          replyText: null,
          outcome: "failed",
          reason: err instanceof Error ? err.message : "Gagal mengirim balasan otomatis."
        });
      }
    }, new import_events.NewMessage({ incoming: true }));
  }
  async finalizeConnectedClient(client, apiId, apiHash, phoneRaw) {
    const me = await client.getMe();
    const sessionString = client.session.save();
    const firstName = "firstName" in me && typeof me.firstName === "string" ? me.firstName : null;
    const lastName = "lastName" in me && typeof me.lastName === "string" ? me.lastName : null;
    const username = "username" in me && typeof me.username === "string" ? me.username : null;
    const telegramId = me.id ? String(me.id) : null;
    const phoneVal = phoneRaw || ("phone" in me && typeof me.phone === "string" ? `+${me.phone}` : null);
    this.selfId = telegramId;
    const store = loadStore();
    store.credentials = {
      apiId,
      apiHash,
      sessionString,
      phoneMasked: maskPhone(phoneVal),
      firstName,
      lastName,
      username,
      telegramId,
      connectedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    saveStore(store);
    this.shouldStayConnected = true;
    this.lastHeartbeatAt = Date.now();
    this.status = "connected";
    this.errorMessage = null;
    this.startWatchdog();
    this.attachMessageListener(client);
    void retryPendingDeliveries();
  }
  async startPhoneLogin(params) {
    await this.tearDownClient();
    const { apiId, apiHash, phoneNumber } = params;
    const stringSession = new import_telegram.sessions.StringSession("");
    const client = new import_telegram.TelegramClient(stringSession, apiId, apiHash, {
      connectionRetries: 50,
      retryDelay: 3e3,
      autoReconnect: true
    });
    this.client = client;
    this.status = "connecting";
    this.errorMessage = null;
    const store = loadStore();
    store.credentials.apiId = apiId;
    store.credentials.apiHash = apiHash;
    store.credentials.phoneMasked = maskPhone(phoneNumber);
    saveStore(store);
    let awaitingStepPromiseResolve = null;
    let awaitingStepPromiseReject = null;
    const firstTransition = new Promise((resolve, reject) => {
      awaitingStepPromiseResolve = resolve;
      awaitingStepPromiseReject = reject;
    });
    const loginPromise = client.start({
      phoneNumber: async () => phoneNumber,
      phoneCode: async () => {
        this.status = "awaiting_code";
        this.errorMessage = null;
        awaitingStepPromiseResolve?.();
        awaitingStepPromiseResolve = null;
        return new Promise((resolve, reject) => {
          this.pending.resolveCode = resolve;
          this.pending.rejectCode = reject;
        });
      },
      password: async () => {
        this.status = "awaiting_password";
        this.errorMessage = null;
        awaitingStepPromiseResolve?.();
        awaitingStepPromiseResolve = null;
        return new Promise((resolve, reject) => {
          this.pending.resolvePassword = resolve;
          this.pending.rejectPassword = reject;
        });
      },
      onError: (err) => {
        this.errorMessage = err.message || "Terjadi kesalahan saat otentikasi Telegram.";
        if (awaitingStepPromiseReject) {
          awaitingStepPromiseReject(err);
          awaitingStepPromiseReject = null;
        }
      }
    }).then(async () => {
      await this.finalizeConnectedClient(client, apiId, apiHash, phoneNumber);
      awaitingStepPromiseResolve?.();
      awaitingStepPromiseResolve = null;
    }).catch((err) => {
      const msg = err instanceof Error ? err.message : "Gagal masuk ke akun Telegram.";
      this.status = "error";
      this.errorMessage = msg;
      awaitingStepPromiseReject?.(err instanceof Error ? err : new Error(msg));
      awaitingStepPromiseReject = null;
    });
    this.pending.loginPromise = loginPromise;
    await Promise.race([
      firstTransition,
      sleep(15e3).then(() => {
        if (this.status === "connecting") {
          throw new Error("Koneksi ke server Telegram melewati batas waktu.");
        }
      })
    ]);
    return this.getPublicAccount();
  }
  async submitOtpCode(code) {
    if (this.status !== "awaiting_code" || !this.pending.resolveCode) {
      throw new Error("Tidak ada permintaan kode OTP yang aktif.");
    }
    const resolver = this.pending.resolveCode;
    this.pending.resolveCode = void 0;
    this.pending.rejectCode = void 0;
    this.status = "connecting";
    this.errorMessage = null;
    resolver(code.trim());
    const deadline = Date.now() + 15e3;
    while (this.status === "connecting" && Date.now() < deadline) {
      await sleep(150);
    }
    return this.getPublicAccount();
  }
  async submitTwoFactorPassword(password) {
    if (this.status !== "awaiting_password" || !this.pending.resolvePassword) {
      throw new Error("Tidak ada permintaan kata sandi 2FA yang aktif.");
    }
    const resolver = this.pending.resolvePassword;
    this.pending.resolvePassword = void 0;
    this.pending.rejectPassword = void 0;
    this.status = "connecting";
    this.errorMessage = null;
    resolver(password);
    const deadline = Date.now() + 15e3;
    while (this.status === "connecting" && Date.now() < deadline) {
      await sleep(150);
    }
    return this.getPublicAccount();
  }
  async connectClientWithSession(apiId, apiHash, sessionString) {
    await this.tearDownClient();
    const stringSession = new import_telegram.sessions.StringSession(sessionString.trim());
    const client = new import_telegram.TelegramClient(stringSession, apiId, apiHash, {
      connectionRetries: 50,
      retryDelay: 3e3,
      autoReconnect: true
    });
    this.client = client;
    this.status = "connecting";
    this.errorMessage = null;
    try {
      await client.connect();
      const authorized = await client.isUserAuthorized();
      if (!authorized) {
        await client.disconnect();
        this.client = null;
        this.shouldStayConnected = false;
        this.stopWatchdog();
        this.status = "error";
        this.errorMessage = "StringSession tidak valid atau sudah kedaluwarsa.";
        return this.getPublicAccount();
      }
      await this.finalizeConnectedClient(client, apiId, apiHash);
      return this.getPublicAccount();
    } catch (err) {
      this.status = "error";
      this.errorMessage = err instanceof Error ? err.message : "Gagal terhubung menggunakan StringSession.";
      return this.getPublicAccount();
    }
  }
  async disconnectOnly() {
    this.shouldStayConnected = false;
    this.stopWatchdog();
    await this.tearDownClient();
    this.status = "disconnected";
    this.errorMessage = null;
    return this.getPublicAccount();
  }
  async logoutAndClearSession() {
    this.shouldStayConnected = false;
    this.stopWatchdog();
    if (this.client) {
      try {
        await this.client.invoke(new import_telegram.Api.auth.LogOut());
      } catch {
      }
    }
    await this.tearDownClient();
    const store = loadStore();
    store.credentials = {
      apiId: null,
      apiHash: null,
      sessionString: null,
      phoneMasked: null,
      firstName: null,
      lastName: null,
      username: null,
      telegramId: null,
      connectedAt: null
    };
    saveStore(store);
    this.status = "disconnected";
    this.errorMessage = null;
    return this.getPublicAccount();
  }
};
var telegramManager = new TelegramUserbotManager();
registerTelegramSender({
  isReady: () => telegramManager.isReady(),
  sendDirectMessage: (chatId, text) => telegramManager.sendDirectMessage(chatId, text),
  sendPhotoWithCaption: (chatId, pngBuffer, caption) => telegramManager.sendPhotoWithCaption(chatId, pngBuffer, caption)
});

// server.ts
var isProd = process.env.NODE_ENV === "production";
var PORT = isProd && process.env.PORT ? Number(process.env.PORT) || 3e3 : 3e3;
var simCooldownMap = /* @__PURE__ */ new Map();
var VALID_MATCH_TYPES2 = /* @__PURE__ */ new Set([
  "exact",
  "contains",
  "starts_with",
  "regex",
  "all_incoming"
]);
var VALID_SCOPES2 = /* @__PURE__ */ new Set(["private", "group", "all"]);
var VALID_STOCK_STATUSES2 = /* @__PURE__ */ new Set(["tersedia", "terbatas", "habis"]);
async function startServer() {
  const app = (0, import_express.default)();
  app.use(import_express.default.json({ limit: "256kb" }));
  loadStore();
  void telegramManager.initFromSavedSession();
  startPaymentWatchdog();
  app.get(["/api/keepalive", "/api/health"], async (_req, res) => {
    try {
      await telegramManager.ensureConnected();
    } catch {
    }
    const store = loadStore();
    expireStaleOrders(store);
    if (store.gopayConfig.enabled && store.gopayConfig.pollingEnabled && store.gopayConfig.mutationApiUrl.trim() && store.orders.some((o) => o.status === "pending")) {
      void pollGoPayMerchantMutations();
    }
    const account = telegramManager.getPublicAccount();
    res.json({
      ok: true,
      mode24x7: true,
      telegramStatus: account.status,
      botEnabled: store.settings.botEnabled,
      pendingOrdersCount: store.orders.filter((o) => o.status === "pending").length,
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  app.get("/api/auth/status", (req, res) => {
    const token = extractBearerToken(req);
    const check = token ? verifySessionToken(token) : { valid: false };
    res.json(getAuthStatus(check.valid));
  });
  app.post("/api/auth/setup", (req, res) => {
    const pin = typeof req.body?.pin === "string" ? req.body.pin.trim() : "";
    const result = claimInitialPin(pin);
    if (!result.ok) {
      res.status(result.error?.includes("pernah") || result.error?.includes("environment") ? 409 : 400).json({
        error: result.error || "Gagal membuat PIN admin."
      });
      return;
    }
    const issued = issueSessionToken();
    res.status(201).json({
      token: issued.token,
      expiresAt: issued.expiresAt,
      status: getAuthStatus(true)
    });
  });
  app.post("/api/auth/login", (req, res) => {
    const rate = checkLoginRateLimit(req);
    if (rate.blocked) {
      res.status(429).json({
        error: `Terlalu banyak percobaan PIN gagal. Coba lagi dalam ${rate.retryAfterSec} detik.`
      });
      return;
    }
    const authStatus = getAuthStatus(false);
    if (authStatus.needsSetup) {
      res.status(400).json({ error: "PIN admin belum dibuat. Silakan buat PIN terlebih dahulu." });
      return;
    }
    const pin = typeof req.body?.pin === "string" ? req.body.pin.trim() : "";
    if (!verifyAdminPin(pin)) {
      recordLoginFailure(req);
      res.status(401).json({ error: "PIN salah. Periksa kembali PIN admin Anda." });
      return;
    }
    clearLoginFailures(req);
    const issued = issueSessionToken();
    res.json({
      token: issued.token,
      expiresAt: issued.expiresAt,
      status: getAuthStatus(true)
    });
  });
  app.post("/api/auth/logout", requireAdminAuth, (req, res) => {
    revokeBearerToken(req);
    res.json({ status: getAuthStatus(false) });
  });
  app.post("/api/auth/change-pin", requireAdminAuth, (req, res) => {
    const currentPin = typeof req.body?.currentPin === "string" ? req.body.currentPin.trim() : "";
    const newPin = typeof req.body?.newPin === "string" ? req.body.newPin.trim() : "";
    const result = updateAdminPin(currentPin, newPin);
    if (!result.ok) {
      res.status(400).json({ error: result.error || "Gagal mengubah PIN." });
      return;
    }
    revokeBearerToken(req);
    const issued = issueSessionToken();
    res.json({
      token: issued.token,
      expiresAt: issued.expiresAt,
      status: getAuthStatus(true)
    });
  });
  app.get("/api/state", requireAdminAuth, (_req, res) => {
    const store = loadStore();
    expireStaleOrders(store);
    res.json({
      rules: [...store.rules].sort((a, b) => a.priority - b.priority),
      products: store.products,
      settings: store.settings,
      account: telegramManager.getPublicAccount(),
      logs: store.logs,
      orders: store.orders,
      mutations: store.mutations,
      gopayConfig: buildPublicGopayConfig(store),
      stats: computeStats(store)
    });
  });
  app.post("/api/rules", requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const matchType = VALID_MATCH_TYPES2.has(body.matchType) ? body.matchType : "contains";
    const pattern = typeof body.pattern === "string" ? body.pattern.trim() : "";
    const caseSensitive = Boolean(body.caseSensitive);
    const chatScope = VALID_SCOPES2.has(body.chatScope) ? body.chatScope : "private";
    const replyText = typeof body.replyText === "string" ? body.replyText.trim() : "";
    const quoteOriginal = Boolean(body.quoteOriginal);
    const delayMs = Number(body.delayMs ?? 800);
    const cooldownSeconds = Number(body.cooldownSeconds ?? 60);
    const priority = Number(body.priority ?? 10);
    const enabled = body.enabled !== void 0 ? Boolean(body.enabled) : true;
    const validation = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority
    });
    if (!validation.valid) {
      res.status(400).json({ error: "Validasi aturan gagal.", errors: validation.errors });
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const newRule = {
      id: `rule_${import_node_crypto5.default.randomUUID().slice(0, 8)}`,
      name,
      enabled,
      matchType,
      pattern: matchType === "all_incoming" ? "" : pattern,
      caseSensitive,
      chatScope,
      replyText,
      quoteOriginal,
      delayMs,
      cooldownSeconds,
      priority,
      hitCount: 0,
      createdAt: now,
      updatedAt: now
    };
    const store = loadStore();
    store.rules.push(newRule);
    saveStore(store);
    res.status(201).json({ rule: newRule, stats: computeStats(store) });
  });
  app.put("/api/rules/:id", requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const existing = store.rules.find((r) => r.id === id);
    if (!existing) {
      res.status(404).json({ error: "Aturan tidak ditemukan." });
      return;
    }
    const body = req.body ?? {};
    const name = body.name !== void 0 ? String(body.name).trim() : existing.name;
    const matchType = body.matchType !== void 0 && VALID_MATCH_TYPES2.has(body.matchType) ? body.matchType : existing.matchType;
    const pattern = body.pattern !== void 0 ? String(body.pattern).trim() : existing.pattern;
    const caseSensitive = body.caseSensitive !== void 0 ? Boolean(body.caseSensitive) : existing.caseSensitive;
    const chatScope = body.chatScope !== void 0 && VALID_SCOPES2.has(body.chatScope) ? body.chatScope : existing.chatScope;
    const replyText = body.replyText !== void 0 ? String(body.replyText).trim() : existing.replyText;
    const quoteOriginal = body.quoteOriginal !== void 0 ? Boolean(body.quoteOriginal) : existing.quoteOriginal;
    const delayMs = body.delayMs !== void 0 ? Number(body.delayMs) : existing.delayMs;
    const cooldownSeconds = body.cooldownSeconds !== void 0 ? Number(body.cooldownSeconds) : existing.cooldownSeconds;
    const priority = body.priority !== void 0 ? Number(body.priority) : existing.priority;
    const enabled = body.enabled !== void 0 ? Boolean(body.enabled) : existing.enabled;
    const validation = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority
    });
    if (!validation.valid) {
      res.status(400).json({ error: "Validasi aturan gagal.", errors: validation.errors });
      return;
    }
    existing.name = name;
    existing.matchType = matchType;
    existing.pattern = matchType === "all_incoming" ? "" : pattern;
    existing.caseSensitive = caseSensitive;
    existing.chatScope = chatScope;
    existing.replyText = replyText;
    existing.quoteOriginal = quoteOriginal;
    existing.delayMs = delayMs;
    existing.cooldownSeconds = cooldownSeconds;
    existing.priority = priority;
    existing.enabled = enabled;
    existing.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    saveStore(store);
    res.json({ rule: existing, stats: computeStats(store) });
  });
  app.delete("/api/rules/:id", requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const prevLen = store.rules.length;
    store.rules = store.rules.filter((r) => r.id !== id);
    if (store.rules.length === prevLen) {
      res.status(404).json({ error: "Aturan tidak ditemukan." });
      return;
    }
    saveStore(store);
    res.json({ deletedId: id, stats: computeStats(store) });
  });
  function sanitizeAccountsPayload(raw) {
    if (!Array.isArray(raw)) return null;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const result = [];
    for (const item of raw.slice(0, 500)) {
      if (!item || typeof item !== "object") continue;
      const rec = item;
      const email = typeof rec.email === "string" ? rec.email.trim().slice(0, 160) : "";
      const password = typeof rec.password === "string" ? rec.password.trim().slice(0, 160) : "";
      const extraData = typeof rec.extraData === "string" ? rec.extraData.trim().slice(0, 1e3) : "";
      const check = validateProductAccountInput({ email, password, extraData });
      if (!check.valid) continue;
      const status = rec.status === "reserved" || rec.status === "sold" ? rec.status : "available";
      result.push({
        id: typeof rec.id === "string" && rec.id.trim() ? rec.id.trim().slice(0, 64) : `acc_${import_node_crypto5.default.randomUUID().slice(0, 8)}`,
        email,
        password,
        extraData,
        status,
        soldToOrderId: typeof rec.soldToOrderId === "string" ? rec.soldToOrderId : null,
        soldAt: typeof rec.soldAt === "string" ? rec.soldAt : null,
        createdAt: typeof rec.createdAt === "string" ? rec.createdAt : now
      });
    }
    return result;
  }
  app.post("/api/products", requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const category = typeof body.category === "string" ? body.category.trim() : "";
    const price = Number(body.price ?? 0);
    const duration = typeof body.duration === "string" ? body.duration.trim() : "";
    const stockStatus = VALID_STOCK_STATUSES2.has(body.stockStatus) ? body.stockStatus : "tersedia";
    const keywords = typeof body.keywords === "string" ? body.keywords.trim() : "";
    const description = typeof body.description === "string" ? body.description.trim() : "";
    const replyTemplate = typeof body.replyTemplate === "string" ? body.replyTemplate.trim() : "";
    const autoReplyEnabled = body.autoReplyEnabled !== void 0 ? Boolean(body.autoReplyEnabled) : true;
    const accounts = sanitizeAccountsPayload(body.accounts) ?? [];
    const validation = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate
    });
    if (!validation.valid) {
      res.status(400).json({ error: "Validasi produk gagal.", errors: validation.errors });
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const newProduct = {
      id: `prod_${import_node_crypto5.default.randomUUID().slice(0, 8)}`,
      name,
      category,
      price: Math.round(price),
      duration,
      stockStatus,
      keywords,
      description,
      replyTemplate,
      autoReplyEnabled,
      accounts,
      hitCount: 0,
      createdAt: now,
      updatedAt: now
    };
    const store = loadStore();
    store.products.push(newProduct);
    saveStore(store);
    res.status(201).json({ product: newProduct, stats: computeStats(store) });
  });
  app.put("/api/products/:id", requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const existing = store.products.find((p) => p.id === id);
    if (!existing) {
      res.status(404).json({ error: "Produk tidak ditemukan." });
      return;
    }
    const body = req.body ?? {};
    const name = body.name !== void 0 ? String(body.name).trim() : existing.name;
    const category = body.category !== void 0 ? String(body.category).trim() : existing.category;
    const price = body.price !== void 0 ? Number(body.price) : existing.price;
    const duration = body.duration !== void 0 ? String(body.duration).trim() : existing.duration;
    const stockStatus = body.stockStatus !== void 0 && VALID_STOCK_STATUSES2.has(body.stockStatus) ? body.stockStatus : existing.stockStatus;
    const keywords = body.keywords !== void 0 ? String(body.keywords).trim() : existing.keywords;
    const description = body.description !== void 0 ? String(body.description).trim() : existing.description;
    const replyTemplate = body.replyTemplate !== void 0 ? String(body.replyTemplate).trim() : existing.replyTemplate;
    const autoReplyEnabled = body.autoReplyEnabled !== void 0 ? Boolean(body.autoReplyEnabled) : existing.autoReplyEnabled;
    const parsedAccounts = sanitizeAccountsPayload(body.accounts);
    const validation = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate
    });
    if (!validation.valid) {
      res.status(400).json({ error: "Validasi produk gagal.", errors: validation.errors });
      return;
    }
    existing.name = name;
    existing.category = category;
    existing.price = Math.round(price);
    existing.duration = duration;
    existing.stockStatus = stockStatus;
    existing.keywords = keywords;
    existing.description = description;
    existing.replyTemplate = replyTemplate;
    existing.autoReplyEnabled = autoReplyEnabled;
    if (parsedAccounts !== null) {
      existing.accounts = parsedAccounts;
    }
    existing.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    saveStore(store);
    res.json({ product: existing, stats: computeStats(store) });
  });
  app.delete("/api/products/:id", requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const prevLen = store.products.length;
    store.products = store.products.filter((p) => p.id !== id);
    if (store.products.length === prevLen) {
      res.status(404).json({ error: "Produk tidak ditemukan." });
      return;
    }
    saveStore(store);
    res.json({ deletedId: id, stats: computeStats(store) });
  });
  app.post("/api/products/:id/accounts", requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const product = store.products.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Produk tidak ditemukan." });
      return;
    }
    const items = Array.isArray(req.body?.accounts) ? req.body.accounts : [req.body];
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const added = [];
    for (const raw of items.slice(0, 200)) {
      if (!raw || typeof raw !== "object") continue;
      const rec = raw;
      const email = typeof rec.email === "string" ? rec.email.trim() : "";
      const password = typeof rec.password === "string" ? rec.password.trim() : "";
      const extraData = typeof rec.extraData === "string" ? rec.extraData.trim() : "";
      const check = validateProductAccountInput({ email, password, extraData });
      if (!check.valid) {
        res.status(400).json({ error: Object.values(check.errors)[0] || "Data akun tidak valid." });
        return;
      }
      added.push({
        id: `acc_${import_node_crypto5.default.randomUUID().slice(0, 8)}`,
        email: email.slice(0, 160),
        password: password.slice(0, 160),
        extraData: extraData.slice(0, 1e3),
        status: "available",
        soldToOrderId: null,
        soldAt: null,
        createdAt: now
      });
    }
    if (added.length === 0) {
      res.status(400).json({ error: "Minimal satu data akun wajib diisi." });
      return;
    }
    product.accounts = [...product.accounts ?? [], ...added].slice(0, 500);
    if (product.stockStatus === "habis") {
      product.stockStatus = "tersedia";
    }
    product.updatedAt = now;
    saveStore(store);
    res.status(201).json({ product, addedCount: added.length, stats: computeStats(store) });
  });
  app.delete("/api/products/:id/accounts/:accountId", requireAdminAuth, (req, res) => {
    const { id, accountId } = req.params;
    const store = loadStore();
    const product = store.products.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Produk tidak ditemukan." });
      return;
    }
    const prevLen = (product.accounts ?? []).length;
    product.accounts = (product.accounts ?? []).filter((a) => a.id !== accountId);
    if (product.accounts.length === prevLen) {
      res.status(404).json({ error: "Data akun tidak ditemukan." });
      return;
    }
    product.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    saveStore(store);
    res.json({ product, stats: computeStats(store) });
  });
  app.put("/api/payment/gopay/config", requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const store = loadStore();
    const cur = store.gopayConfig;
    const nextStaticQris = typeof body.staticQris === "string" ? body.staticQris.trim() : cur.staticQris;
    const qrisCheck = validateStaticQris(nextStaticQris);
    if (!qrisCheck.valid) {
      res.status(400).json({ error: qrisCheck.error || "Format QRIS Statis tidak valid." });
      return;
    }
    const nextUrl = typeof body.mutationApiUrl === "string" ? body.mutationApiUrl.trim() : cur.mutationApiUrl;
    const urlCheck = validateMutationApiUrl(nextUrl);
    if (!urlCheck.valid) {
      res.status(400).json({ error: urlCheck.error || "URL API Mutasi tidak valid." });
      return;
    }
    const nextMerchantName = typeof body.merchantName === "string" && body.merchantName.trim() ? body.merchantName.trim().slice(0, 60) : extractMerchantNameFromQris(nextStaticQris) || cur.merchantName;
    let nextApiToken = cur.apiToken;
    if (body.clearApiToken === true) {
      nextApiToken = "";
    } else if (typeof body.apiToken === "string" && body.apiToken.trim()) {
      nextApiToken = body.apiToken.trim().slice(0, 500);
    }
    let nextWebhookSecret = cur.webhookSecret;
    if (typeof body.webhookSecret === "string" && body.webhookSecret.trim()) {
      if (body.webhookSecret.trim().length < 12) {
        res.status(400).json({ error: "Webhook secret minimal 12 karakter." });
        return;
      }
      nextWebhookSecret = body.webhookSecret.trim().slice(0, 200);
    }
    store.gopayConfig = {
      ...cur,
      enabled: body.enabled !== void 0 ? Boolean(body.enabled) : cur.enabled,
      merchantName: nextMerchantName,
      staticQris: nextStaticQris,
      mutationApiUrl: nextUrl,
      apiToken: nextApiToken,
      webhookSecret: nextWebhookSecret,
      pollingEnabled: body.pollingEnabled !== void 0 ? Boolean(body.pollingEnabled) : cur.pollingEnabled,
      pollIntervalSeconds: Math.max(
        10,
        Math.min(300, Number(body.pollIntervalSeconds ?? cur.pollIntervalSeconds) || 20)
      ),
      orderExpiryMinutes: Math.max(
        3,
        Math.min(180, Number(body.orderExpiryMinutes ?? cur.orderExpiryMinutes) || 15)
      )
    };
    saveStore(store);
    res.json({
      gopayConfig: buildPublicGopayConfig(store),
      stats: computeStats(store)
    });
  });
  app.post("/api/payment/gopay/rotate-secret", requireAdminAuth, (_req, res) => {
    const store = loadStore();
    const newSecret = import_node_crypto5.default.randomBytes(24).toString("hex");
    store.gopayConfig.webhookSecret = newSecret;
    saveStore(store);
    res.json({
      gopayConfig: buildPublicGopayConfig(store),
      plainWebhookSecret: newSecret
    });
  });
  app.post("/api/payment/gopay/poll-now", requireAdminAuth, async (_req, res) => {
    const result = await pollGoPayMerchantMutations();
    const store = loadStore();
    res.json({
      result,
      gopayConfig: buildPublicGopayConfig(store),
      orders: store.orders,
      mutations: store.mutations,
      products: store.products,
      stats: computeStats(store)
    });
  });
  app.post("/api/payment/gopay/test-order", requireAdminAuth, async (req, res) => {
    const productId = typeof req.body?.productId === "string" ? req.body.productId.trim() : "";
    const buyerName = typeof req.body?.buyerName === "string" && req.body.buyerName.trim() ? req.body.buyerName.trim().slice(0, 60) : "Pembeli Simulasi";
    if (!productId) {
      res.status(400).json({ error: "Pilih produk terlebih dahulu." });
      return;
    }
    const result = await createQrisOrder({
      productId,
      buyerChatId: "sim_checkout",
      buyerSenderId: "sim_checkout",
      buyerName,
      buyerUsername: "pembeli_uji",
      source: "simulator"
    });
    if (!result.ok || !result.order) {
      res.status(400).json({ error: result.error || "Gagal membuat invoice QRIS." });
      return;
    }
    const store = loadStore();
    res.status(201).json({
      order: result.order,
      qrDataUrl: result.qrDataUrl,
      invoiceCaption: result.invoiceCaption,
      orders: store.orders,
      products: store.products,
      stats: computeStats(store)
    });
  });
  app.post("/api/payment/gopay/simulate-mutation", requireAdminAuth, async (req, res) => {
    const rawAmount = req.body?.amount;
    const rawText = typeof req.body?.notificationText === "string" ? req.body.notificationText : "";
    const amount = typeof rawAmount === "number" && Number.isFinite(rawAmount) && rawAmount > 0 ? Math.round(rawAmount) : parseGoPayNotificationAmount(rawText);
    if (!amount || amount <= 0) {
      res.status(400).json({ error: "Nominal mutasi harus lebih dari Rp 0." });
      return;
    }
    const senderName = typeof req.body?.senderName === "string" && req.body.senderName.trim() ? req.body.senderName.trim().slice(0, 60) : "GoPay Customer";
    const outcome = await processIncomingMutation({
      amount,
      source: "simulation",
      senderName,
      rawSummary: rawText.trim() || `Simulasi mutasi GoPay Merchant masuk Rp ${amount.toLocaleString("id-ID")}`
    });
    const store = loadStore();
    res.json({
      outcome,
      orders: store.orders,
      mutations: store.mutations,
      products: store.products,
      logs: store.logs,
      stats: computeStats(store)
    });
  });
  app.post("/api/payment/orders/:id/cancel", requireAdminAuth, (req, res) => {
    const result = cancelOrder(req.params.id);
    if (!result.ok) {
      res.status(400).json({ error: result.error || "Gagal membatalkan order." });
      return;
    }
    const store = loadStore();
    res.json({
      order: result.order,
      orders: store.orders,
      products: store.products,
      stats: computeStats(store)
    });
  });
  app.post("/api/payment/orders/:id/resend", requireAdminAuth, async (req, res) => {
    const result = await retryOrderDelivery(req.params.id);
    if (!result.ok) {
      res.status(400).json({ error: result.error || "Gagal mengirim ulang detail akun." });
      return;
    }
    const store = loadStore();
    res.json({
      order: result.order,
      orders: store.orders,
      logs: store.logs,
      stats: computeStats(store)
    });
  });
  app.post("/api/payment/gopay/webhook", async (req, res) => {
    const store = loadStore();
    const expectedSecret = store.gopayConfig.webhookSecret?.trim() ?? "";
    if (!expectedSecret) {
      res.status(403).json({ error: "Webhook secret belum dikonfigurasi pada server." });
      return;
    }
    const authHeader = req.header("authorization");
    const bearerSecret = authHeader && authHeader.toLowerCase().startsWith("bearer ") ? authHeader.slice(7).trim() : "";
    const headerSecret = (req.header("x-webhook-secret") || "").trim();
    const suppliedSecret = bearerSecret || headerSecret;
    const expectedDigest = import_node_crypto5.default.createHash("sha256").update(expectedSecret).digest();
    const suppliedDigest = import_node_crypto5.default.createHash("sha256").update(suppliedSecret).digest();
    if (!suppliedSecret || !import_node_crypto5.default.timingSafeEqual(expectedDigest, suppliedDigest)) {
      res.status(401).json({ error: "Webhook secret tidak valid." });
      return;
    }
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const txType = String(body.type ?? body.mutation_type ?? body.direction ?? "").toLowerCase();
    if (txType === "db" || txType === "debit" || txType === "out") {
      res.json({ ok: true, ignored: true, reason: "Mutasi keluar/debit diabaikan." });
      return;
    }
    let amount = null;
    for (const candidate of [body.amount, body.nominal, body.gross_amount, body.credit]) {
      if (typeof candidate === "number" && Number.isFinite(candidate) && candidate > 0) {
        amount = Math.round(candidate);
        break;
      }
      if (typeof candidate === "string" && candidate.trim()) {
        const parsed = parseGoPayNotificationAmount(`Rp ${candidate.trim()}`);
        if (parsed) {
          amount = parsed;
          break;
        }
      }
    }
    const notifText = typeof body.text === "string" ? body.text : typeof body.message === "string" ? body.message : typeof body.notification === "string" ? body.notification : typeof body.title === "string" ? body.title : "";
    if (!amount && notifText) {
      amount = parseGoPayNotificationAmount(notifText);
    }
    if (!amount || amount <= 0) {
      res.status(400).json({ error: "Nominal mutasi GoPay tidak terbaca dari payload webhook." });
      return;
    }
    const refRaw = body.mutation_id ?? body.transaction_id ?? body.reference_id ?? body.id;
    const senderName = typeof body.sender_name === "string" ? body.sender_name : typeof body.customer_name === "string" ? body.customer_name : null;
    const outcome = await processIncomingMutation({
      amount,
      mutationRef: refRaw ? String(refRaw) : void 0,
      source: "webhook",
      senderName,
      rawSummary: notifText || `Webhook GoPay masuk Rp ${amount.toLocaleString("id-ID")}`
    });
    res.json({
      ok: true,
      matched: outcome.matched,
      duplicate: outcome.duplicate,
      orderCode: outcome.order?.orderCode ?? null
    });
  });
  app.put("/api/settings", requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const store = loadStore();
    const cur = store.settings;
    const nextSettings = {
      botEnabled: body.botEnabled !== void 0 ? Boolean(body.botEnabled) : cur.botEnabled,
      defaultReplyEnabled: body.defaultReplyEnabled !== void 0 ? Boolean(body.defaultReplyEnabled) : cur.defaultReplyEnabled,
      defaultReplyText: typeof body.defaultReplyText === "string" ? body.defaultReplyText.trim().slice(0, 4e3) : cur.defaultReplyText,
      ignoreGroupsByDefault: body.ignoreGroupsByDefault !== void 0 ? Boolean(body.ignoreGroupsByDefault) : cur.ignoreGroupsByDefault,
      ignoreContactsInWhitelistOnly: body.ignoreContactsInWhitelistOnly !== void 0 ? Boolean(body.ignoreContactsInWhitelistOnly) : cur.ignoreContactsInWhitelistOnly,
      whitelist: Array.isArray(body.whitelist) ? body.whitelist.map((s) => String(s).trim()).filter(Boolean).slice(0, 200) : cur.whitelist,
      blacklist: Array.isArray(body.blacklist) ? body.blacklist.map((s) => String(s).trim()).filter(Boolean).slice(0, 200) : cur.blacklist,
      defaultCooldownSeconds: body.defaultCooldownSeconds !== void 0 ? Math.max(0, Math.min(86400, Number(body.defaultCooldownSeconds) || 0)) : cur.defaultCooldownSeconds,
      typingIndicator: body.typingIndicator !== void 0 ? Boolean(body.typingIndicator) : cur.typingIndicator,
      schedule: {
        enabled: body.schedule?.enabled !== void 0 ? Boolean(body.schedule.enabled) : cur.schedule.enabled,
        startTime: typeof body.schedule?.startTime === "string" && /^([01]\d|2[0-3]):([0-5]\d)$/.test(body.schedule.startTime) ? body.schedule.startTime : cur.schedule.startTime,
        endTime: typeof body.schedule?.endTime === "string" && /^([01]\d|2[0-3]):([0-5]\d)$/.test(body.schedule.endTime) ? body.schedule.endTime : cur.schedule.endTime,
        timezoneOffsetMinutes: body.schedule?.timezoneOffsetMinutes !== void 0 && Number.isFinite(Number(body.schedule.timezoneOffsetMinutes)) ? Number(body.schedule.timezoneOffsetMinutes) : cur.schedule.timezoneOffsetMinutes
      }
    };
    store.settings = nextSettings;
    saveStore(store);
    res.json({ settings: nextSettings, stats: computeStats(store) });
  });
  app.post("/api/simulate", requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const senderName = typeof body.senderName === "string" && body.senderName.trim() ? body.senderName.trim().slice(0, 80) : "Pengguna Uji";
    const senderUsername = typeof body.senderUsername === "string" && body.senderUsername.trim() ? body.senderUsername.trim().slice(0, 60) : null;
    const chatType = body.chatType === "group" ? "group" : "private";
    const text = typeof body.text === "string" ? body.text.trim() : "";
    const ignoreConstraints = Boolean(body.ignoreConstraints);
    if (!text) {
      res.status(400).json({ error: "Isi pesan uji wajib diisi." });
      return;
    }
    const store = loadStore();
    const senderId = `sim_${senderUsername || senderName.toLowerCase().replace(/\s+/g, "_")}`;
    const evaluation = matchMessageToRules(
      {
        senderId,
        senderName,
        senderUsername,
        chatId: senderId,
        chatType,
        text
      },
      store.rules,
      store.settings,
      simCooldownMap,
      /* @__PURE__ */ new Date(),
      { ignoreScheduleAndCooldown: ignoreConstraints },
      store.products
    );
    if (evaluation.shouldReply && evaluation.cooldownKey && !ignoreConstraints) {
      simCooldownMap.set(evaluation.cooldownKey, Date.now());
    }
    const matchedLabel = evaluation.matchedRule ? evaluation.matchedRule.name : evaluation.matchedProduct ? `Produk: ${evaluation.matchedProduct.name}` : evaluation.matchedDefaultReply ? "Balasan Default (Semua Pesan)" : null;
    const logEntry = appendLog({
      senderId,
      senderName,
      senderUsername,
      chatType,
      incomingText: text.slice(0, 300),
      matchedRuleId: evaluation.matchedRule?.id ?? evaluation.matchedProduct?.id ?? (evaluation.matchedDefaultReply ? "default_reply" : null),
      matchedRuleName: matchedLabel,
      replyText: evaluation.renderedReply,
      outcome: evaluation.shouldReply ? "simulated" : "skipped",
      reason: evaluation.reason
    });
    res.json({
      evaluation,
      logEntry,
      stats: computeStats(loadStore())
    });
  });
  app.post("/api/logs/clear", requireAdminAuth, (_req, res) => {
    const store = loadStore();
    store.logs = [];
    saveStore(store);
    res.json({ logs: [], stats: computeStats(store) });
  });
  app.post("/api/telegram/login/start", requireAdminAuth, async (req, res) => {
    const body = req.body ?? {};
    const apiId = Number(body.apiId);
    const apiHash = typeof body.apiHash === "string" ? body.apiHash.trim() : "";
    const phoneNumber = typeof body.phoneNumber === "string" ? body.phoneNumber.trim() : "";
    if (!Number.isInteger(apiId) || apiId <= 0) {
      res.status(400).json({ error: "API ID harus berupa angka positif dari my.telegram.org." });
      return;
    }
    if (!/^[a-fA-F0-9]{16,64}$/.test(apiHash)) {
      res.status(400).json({ error: "Format API Hash tidak valid." });
      return;
    }
    if (!/^\+?\d{8,16}$/.test(phoneNumber.replace(/[\s-]/g, ""))) {
      res.status(400).json({ error: "Nomor telepon harus diawali kode negara, misal +628123456789." });
      return;
    }
    try {
      const account = await telegramManager.startPhoneLogin({
        apiId,
        apiHash,
        phoneNumber: phoneNumber.replace(/[\s-]/g, "")
      });
      res.json({ account });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : "Gagal memulai login Telegram.",
        account: telegramManager.getPublicAccount()
      });
    }
  });
  app.post("/api/telegram/login/verify-code", requireAdminAuth, async (req, res) => {
    const code = typeof req.body?.code === "string" ? req.body.code.trim() : "";
    if (!/^\d{4,8}$/.test(code)) {
      res.status(400).json({ error: "Kode verifikasi OTP Telegram harus berupa angka 4\u20138 digit." });
      return;
    }
    try {
      const account = await telegramManager.submitOtpCode(code);
      res.json({ account });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : "Verifikasi OTP gagal.",
        account: telegramManager.getPublicAccount()
      });
    }
  });
  app.post("/api/telegram/login/verify-password", requireAdminAuth, async (req, res) => {
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!password) {
      res.status(400).json({ error: "Kata sandi 2FA wajib diisi." });
      return;
    }
    try {
      const account = await telegramManager.submitTwoFactorPassword(password);
      res.json({ account });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : "Verifikasi kata sandi 2FA gagal.",
        account: telegramManager.getPublicAccount()
      });
    }
  });
  app.post("/api/telegram/login/session", requireAdminAuth, async (req, res) => {
    const body = req.body ?? {};
    const apiId = Number(body.apiId);
    const apiHash = typeof body.apiHash === "string" ? body.apiHash.trim() : "";
    const sessionString = typeof body.sessionString === "string" ? body.sessionString.trim() : "";
    if (!Number.isInteger(apiId) || apiId <= 0) {
      res.status(400).json({ error: "API ID harus berupa angka positif." });
      return;
    }
    if (!/^[a-fA-F0-9]{16,64}$/.test(apiHash)) {
      res.status(400).json({ error: "Format API Hash tidak valid." });
      return;
    }
    if (sessionString.length < 32) {
      res.status(400).json({ error: "StringSession terlalu pendek atau tidak valid." });
      return;
    }
    const account = await telegramManager.connectClientWithSession(apiId, apiHash, sessionString);
    if (account.status === "error") {
      res.status(400).json({ error: account.errorMessage || "Gagal terhubung.", account });
      return;
    }
    res.json({ account });
  });
  app.post("/api/telegram/disconnect", requireAdminAuth, async (_req, res) => {
    const account = await telegramManager.disconnectOnly();
    res.json({ account });
  });
  app.post("/api/telegram/logout", requireAdminAuth, async (_req, res) => {
    const account = await telegramManager.logoutAndClearSession();
    res.json({ account });
  });
  app.get("/api/export/database.json", requireAdminAuth, (req, res) => {
    const includeLogs = req.query.includeLogs !== "false";
    const store = loadStore();
    const sanitized = buildSanitizedDatabaseExport(store, includeLogs);
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="telebalas-database.json"');
    res.send(JSON.stringify(sanitized, null, 2));
  });
  app.get("/api/export/database.sql", requireAdminAuth, (_req, res) => {
    const store = loadStore();
    const sql = generateSqlDump(store);
    res.setHeader("Content-Type", "application/sql; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="telebalas-database.sql"');
    res.send(sql);
  });
  app.get("/api/export/install.php", requireAdminAuth, (_req, res) => {
    const phpInstaller = buildPhpWebInstaller();
    res.setHeader("Content-Type", "application/x-httpd-php; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="install.php"');
    res.send(phpInstaller);
  });
  app.get("/api/export/bundle", requireAdminAuth, async (req, res) => {
    try {
      const includeLogs = req.query.includeLogs !== "false";
      const store = loadStore();
      const zipBuffer = await buildCpanelBundleZip(store, includeLogs);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="telebalas-cpanel-siap-pakai.zip"'
      );
      res.setHeader("Content-Length", String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : "Gagal membuat paket cPanel ZIP."
      });
    }
  });
  app.post("/api/export/restore-database", requireAdminAuth, (req, res) => {
    const check = validateRestorePayload(req.body);
    if (!check.ok || !check.data) {
      res.status(400).json({ error: check.error || "Data database tidak valid." });
      return;
    }
    const store = loadStore();
    store.rules = check.data.rules;
    store.products = check.data.products;
    store.settings = check.data.settings;
    if (check.data.logs) {
      store.logs = check.data.logs;
    }
    saveStore(store);
    res.json({
      stats: computeStats(store),
      restoredRulesCount: store.rules.length,
      restoredProductsCount: store.products.length
    });
  });
  const distPath = import_node_path3.default.resolve(process.cwd(), "dist");
  if (!isProd || !import_node_fs3.default.existsSync(distPath)) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_node_path3.default.join(distPath, "index.html"));
    });
  }
  const inPassenger = Boolean(
    process.env.PASSENGER_APP_ENV || process.env.IN_PASSENGER || process.env.PASSENGER_BASE_URI
  );
  if (inPassenger) {
    app.listen(PORT, () => {
      console.log(`TeleBalas server running under Phusion Passenger on port ${PORT}`);
    });
  } else {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`TeleBalas server running on http://0.0.0.0:${PORT}`);
    });
  }
}
startServer().catch((err) => {
  console.error("Fatal server startup error:", err);
  process.exit(1);
});
