import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';
import {
  DEFAULT_FALLBACK_REPLY_TEXT,
  validateProductAccountInput,
  validateProductInput,
  validateRuleInput,
} from '../src/shared/autoReplyEngine';
import type {
  AutoReplyRule,
  BotSettings,
  ChatScope,
  MatchType,
  MessageLogEntry,
  ProductAccountItem,
  ProductItem,
  ProductStockStatus,
} from '../src/shared/types';
import type { PersistedStore } from './store';

const VALID_MATCH_TYPES = new Set<MatchType>([
  'exact',
  'contains',
  'starts_with',
  'regex',
  'all_incoming',
]);
const VALID_SCOPES = new Set<ChatScope>(['private', 'group', 'all']);
const VALID_STOCK_STATUSES = new Set<ProductStockStatus>(['tersedia', 'terbatas', 'habis']);

export function buildSanitizedDatabaseExport(
  store: PersistedStore,
  includeLogs = true
): PersistedStore {
  return {
    rules: structuredClone(store.rules),
    products: structuredClone(store.products),
    settings: structuredClone(store.settings),
    credentials: {
      apiId: null,
      apiHash: null,
      sessionString: null,
      phoneMasked: null,
      firstName: null,
      lastName: null,
      username: null,
      telegramId: null,
      connectedAt: null,
    },
    logs: includeLogs ? structuredClone(store.logs) : [],
    adminAuth: {
      pinHash: null,
      updatedAt: null,
    },
    orders: [],
    mutations: [],
    gopayConfig: {
      ...structuredClone(store.gopayConfig),
      apiToken: '',
      webhookSecret: '',
      lastPolledAt: null,
      lastPollStatus: null,
    },
  };
}

export function escapeSqlString(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/\0/g, '\\0')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\x1a/g, '\\Z')
    .replace(/'/g, "\\'");
}

function sqlVal(value: string | null | undefined): string {
  if (value === null || value === undefined) return 'NULL';
  return `'${escapeSqlString(String(value))}'`;
}

export function generateSqlDump(store: PersistedStore): string {
  const sanitized = buildSanitizedDatabaseExport(store, true);
  const lines: string[] = [
    '-- ============================================================',
    '-- TeleBalas Database SQL Export (MySQL / MariaDB / phpMyAdmin)',
    `-- Generated at: ${new Date().toISOString()}`,
    '-- Catatan: Sesi Telegram & PIN Admin tidak disertakan demi keamanan.',
    '-- ============================================================',
    '',
    'SET NAMES utf8mb4;',
    '',
    'CREATE TABLE IF NOT EXISTS `telebalas_products` (',
    '  `id` VARCHAR(64) NOT NULL PRIMARY KEY,',
    '  `name` VARCHAR(120) NOT NULL,',
    '  `category` VARCHAR(80) NOT NULL,',
    '  `price` INT NOT NULL DEFAULT 0,',
    '  `duration` VARCHAR(64) NOT NULL,',
    '  `stock_status` VARCHAR(20) NOT NULL DEFAULT \'tersedia\',',
    '  `keywords` TEXT NOT NULL,',
    '  `description` TEXT NOT NULL,',
    '  `reply_template` TEXT NOT NULL,',
    '  `auto_reply_enabled` TINYINT(1) NOT NULL DEFAULT 1,',
    '  `hit_count` INT NOT NULL DEFAULT 0,',
    '  `created_at` VARCHAR(40) NOT NULL,',
    '  `updated_at` VARCHAR(40) NOT NULL',
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;',
    '',
    'CREATE TABLE IF NOT EXISTS `telebalas_rules` (',
    '  `id` VARCHAR(64) NOT NULL PRIMARY KEY,',
    '  `name` VARCHAR(120) NOT NULL,',
    '  `enabled` TINYINT(1) NOT NULL DEFAULT 1,',
    '  `match_type` VARCHAR(32) NOT NULL,',
    '  `pattern` TEXT NOT NULL,',
    '  `case_sensitive` TINYINT(1) NOT NULL DEFAULT 0,',
    '  `chat_scope` VARCHAR(16) NOT NULL DEFAULT \'private\',',
    '  `reply_text` TEXT NOT NULL,',
    '  `quote_original` TINYINT(1) NOT NULL DEFAULT 0,',
    '  `delay_ms` INT NOT NULL DEFAULT 800,',
    '  `cooldown_seconds` INT NOT NULL DEFAULT 60,',
    '  `priority` INT NOT NULL DEFAULT 10,',
    '  `hit_count` INT NOT NULL DEFAULT 0,',
    '  `created_at` VARCHAR(40) NOT NULL,',
    '  `updated_at` VARCHAR(40) NOT NULL',
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;',
    '',
    'CREATE TABLE IF NOT EXISTS `telebalas_settings` (',
    '  `setting_key` VARCHAR(64) NOT NULL PRIMARY KEY,',
    '  `setting_json` LONGTEXT NOT NULL,',
    '  `updated_at` VARCHAR(40) NOT NULL',
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;',
    '',
  ];

  if (sanitized.products.length > 0) {
    lines.push('DELETE FROM `telebalas_products`;');
    for (const p of sanitized.products) {
      lines.push(
        `INSERT INTO \`telebalas_products\` (\`id\`, \`name\`, \`category\`, \`price\`, \`duration\`, \`stock_status\`, \`keywords\`, \`description\`, \`reply_template\`, \`auto_reply_enabled\`, \`hit_count\`, \`created_at\`, \`updated_at\`) VALUES (${sqlVal(p.id)}, ${sqlVal(p.name)}, ${sqlVal(p.category)}, ${Math.round(Number(p.price) || 0)}, ${sqlVal(p.duration)}, ${sqlVal(p.stockStatus)}, ${sqlVal(p.keywords)}, ${sqlVal(p.description)}, ${sqlVal(p.replyTemplate)}, ${p.autoReplyEnabled ? 1 : 0}, ${Math.max(0, Math.round(Number(p.hitCount) || 0))}, ${sqlVal(p.createdAt)}, ${sqlVal(p.updatedAt)});`
      );
    }
    lines.push('');
  }

  if (sanitized.rules.length > 0) {
    lines.push('DELETE FROM `telebalas_rules`;');
    for (const r of sanitized.rules) {
      lines.push(
        `INSERT INTO \`telebalas_rules\` (\`id\`, \`name\`, \`enabled\`, \`match_type\`, \`pattern\`, \`case_sensitive\`, \`chat_scope\`, \`reply_text\`, \`quote_original\`, \`delay_ms\`, \`cooldown_seconds\`, \`priority\`, \`hit_count\`, \`created_at\`, \`updated_at\`) VALUES (${sqlVal(r.id)}, ${sqlVal(r.name)}, ${r.enabled ? 1 : 0}, ${sqlVal(r.matchType)}, ${sqlVal(r.pattern)}, ${r.caseSensitive ? 1 : 0}, ${sqlVal(r.chatScope)}, ${sqlVal(r.replyText)}, ${r.quoteOriginal ? 1 : 0}, ${Math.max(0, Math.round(Number(r.delayMs) || 0))}, ${Math.max(0, Math.round(Number(r.cooldownSeconds) || 0))}, ${Math.max(1, Math.round(Number(r.priority) || 10))}, ${Math.max(0, Math.round(Number(r.hitCount) || 0))}, ${sqlVal(r.createdAt)}, ${sqlVal(r.updatedAt)});`
      );
    }
    lines.push('');
  }

  lines.push(
    `REPLACE INTO \`telebalas_settings\` (\`setting_key\`, \`setting_json\`, \`updated_at\`) VALUES ('bot_settings', ${sqlVal(JSON.stringify(sanitized.settings))}, ${sqlVal(new Date().toISOString())});`
  );
  lines.push('');

  return lines.join('\n');
}

export function validateRestorePayload(raw: unknown): {
  ok: boolean;
  error?: string;
  data?: {
    rules: AutoReplyRule[];
    products: ProductItem[];
    settings: BotSettings;
    logs?: MessageLogEntry[];
  };
} {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ok: false, error: 'Format file database JSON tidak valid.' };
  }

  const obj = raw as Record<string, unknown>;
  if (!Array.isArray(obj.rules) || !Array.isArray(obj.products)) {
    return { ok: false, error: 'File JSON harus berisi array "rules" dan "products".' };
  }
  if (obj.rules.length > 500 || obj.products.length > 500) {
    return { ok: false, error: 'Jumlah aturan atau produk melebihi batas maksimum (500).' };
  }

  const now = new Date().toISOString();
  const validatedRules: AutoReplyRule[] = [];
  for (let i = 0; i < obj.rules.length; i++) {
    const item = obj.rules[i] as Record<string, unknown>;
    if (!item || typeof item !== 'object') {
      return { ok: false, error: `Aturan ke-${i + 1} tidak valid.` };
    }
    const name = typeof item.name === 'string' ? item.name.trim() : '';
    const matchType: MatchType = VALID_MATCH_TYPES.has(item.matchType as MatchType)
      ? (item.matchType as MatchType)
      : 'contains';
    const pattern = typeof item.pattern === 'string' ? item.pattern.trim() : '';
    const replyText = typeof item.replyText === 'string' ? item.replyText.trim() : '';
    const delayMs = Number(item.delayMs ?? 800);
    const cooldownSeconds = Number(item.cooldownSeconds ?? 60);
    const priority = Number(item.priority ?? 10);

    const check = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority,
    });
    if (!check.valid) {
      const firstErr = Object.values(check.errors)[0] ?? 'Aturan tidak valid.';
      return { ok: false, error: `Aturan #${i + 1} (${name || 'tanpa nama'}): ${firstErr}` };
    }

    validatedRules.push({
      id:
        typeof item.id === 'string' && item.id.trim()
          ? item.id.trim().slice(0, 64)
          : `rule_${crypto.randomUUID().slice(0, 8)}`,
      name,
      enabled: item.enabled !== undefined ? Boolean(item.enabled) : true,
      matchType,
      pattern: matchType === 'all_incoming' ? '' : pattern,
      caseSensitive: Boolean(item.caseSensitive),
      chatScope: VALID_SCOPES.has(item.chatScope as ChatScope)
        ? (item.chatScope as ChatScope)
        : 'private',
      replyText,
      quoteOriginal: Boolean(item.quoteOriginal),
      delayMs,
      cooldownSeconds,
      priority,
      hitCount: Math.max(0, Math.round(Number(item.hitCount) || 0)),
      createdAt: typeof item.createdAt === 'string' ? item.createdAt : now,
      updatedAt: now,
    });
  }

  const validatedProducts: ProductItem[] = [];
  for (let i = 0; i < obj.products.length; i++) {
    const item = obj.products[i] as Record<string, unknown>;
    if (!item || typeof item !== 'object') {
      return { ok: false, error: `Produk ke-${i + 1} tidak valid.` };
    }
    const name = typeof item.name === 'string' ? item.name.trim() : '';
    const category = typeof item.category === 'string' ? item.category.trim() : '';
    const price = Number(item.price ?? 0);
    const duration = typeof item.duration === 'string' ? item.duration.trim() : '';
    const keywords = typeof item.keywords === 'string' ? item.keywords.trim() : '';
    const replyTemplate = typeof item.replyTemplate === 'string' ? item.replyTemplate.trim() : '';

    const check = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate,
    });
    if (!check.valid) {
      const firstErr = Object.values(check.errors)[0] ?? 'Produk tidak valid.';
      return { ok: false, error: `Produk #${i + 1} (${name || 'tanpa nama'}): ${firstErr}` };
    }

    const rawAccounts = Array.isArray(item.accounts) ? item.accounts : [];
    const accounts: ProductAccountItem[] = [];
    for (const accRaw of rawAccounts.slice(0, 500)) {
      if (!accRaw || typeof accRaw !== 'object') continue;
      const rec = accRaw as Record<string, unknown>;
      const email = typeof rec.email === 'string' ? rec.email.trim().slice(0, 160) : '';
      const password = typeof rec.password === 'string' ? rec.password.trim().slice(0, 160) : '';
      const extraData = typeof rec.extraData === 'string' ? rec.extraData.trim().slice(0, 1000) : '';
      const accCheck = validateProductAccountInput({ email, password, extraData });
      if (!accCheck.valid) continue;
      const status =
        rec.status === 'reserved' || rec.status === 'sold' ? rec.status : 'available';
      accounts.push({
        id:
          typeof rec.id === 'string' && rec.id.trim()
            ? rec.id.trim().slice(0, 64)
            : `acc_${crypto.randomUUID().slice(0, 8)}`,
        email,
        password,
        extraData,
        status,
        soldToOrderId: typeof rec.soldToOrderId === 'string' ? rec.soldToOrderId : null,
        soldAt: typeof rec.soldAt === 'string' ? rec.soldAt : null,
        createdAt: typeof rec.createdAt === 'string' ? rec.createdAt : now,
      });
    }

    validatedProducts.push({
      id:
        typeof item.id === 'string' && item.id.trim()
          ? item.id.trim().slice(0, 64)
          : `prod_${crypto.randomUUID().slice(0, 8)}`,
      name,
      category,
      price: Math.round(price),
      duration,
      stockStatus: VALID_STOCK_STATUSES.has(item.stockStatus as ProductStockStatus)
        ? (item.stockStatus as ProductStockStatus)
        : 'tersedia',
      keywords,
      description: typeof item.description === 'string' ? item.description.trim() : '',
      replyTemplate,
      autoReplyEnabled: item.autoReplyEnabled !== undefined ? Boolean(item.autoReplyEnabled) : true,
      accounts,
      hitCount: Math.max(0, Math.round(Number(item.hitCount) || 0)),
      createdAt: typeof item.createdAt === 'string' ? item.createdAt : now,
      updatedAt: now,
    });
  }

  const rawSettings = (obj.settings && typeof obj.settings === 'object'
    ? obj.settings
    : {}) as Record<string, unknown>;
  const rawSched = (rawSettings.schedule && typeof rawSettings.schedule === 'object'
    ? rawSettings.schedule
    : {}) as Record<string, unknown>;

  const settings: BotSettings = {
    botEnabled: rawSettings.botEnabled !== undefined ? Boolean(rawSettings.botEnabled) : true,
    defaultReplyEnabled:
      rawSettings.defaultReplyEnabled !== undefined
        ? Boolean(rawSettings.defaultReplyEnabled)
        : true,
    defaultReplyText:
      typeof rawSettings.defaultReplyText === 'string' && rawSettings.defaultReplyText.trim()
        ? rawSettings.defaultReplyText.trim().slice(0, 4000)
        : DEFAULT_FALLBACK_REPLY_TEXT,
    ignoreGroupsByDefault:
      rawSettings.ignoreGroupsByDefault !== undefined
        ? Boolean(rawSettings.ignoreGroupsByDefault)
        : true,
    ignoreContactsInWhitelistOnly: Boolean(rawSettings.ignoreContactsInWhitelistOnly),
    whitelist: Array.isArray(rawSettings.whitelist)
      ? rawSettings.whitelist.map((s) => String(s).trim()).filter(Boolean).slice(0, 200)
      : [],
    blacklist: Array.isArray(rawSettings.blacklist)
      ? rawSettings.blacklist.map((s) => String(s).trim()).filter(Boolean).slice(0, 200)
      : [],
    defaultCooldownSeconds: Math.max(
      0,
      Math.min(86400, Number(rawSettings.defaultCooldownSeconds ?? 60) || 0)
    ),
    typingIndicator:
      rawSettings.typingIndicator !== undefined ? Boolean(rawSettings.typingIndicator) : true,
    schedule: {
      enabled: Boolean(rawSched.enabled),
      startTime:
        typeof rawSched.startTime === 'string' &&
        /^([01]\d|2[0-3]):([0-5]\d)$/.test(rawSched.startTime)
          ? rawSched.startTime
          : '08:00',
      endTime:
        typeof rawSched.endTime === 'string' &&
        /^([01]\d|2[0-3]):([0-5]\d)$/.test(rawSched.endTime)
          ? rawSched.endTime
          : '21:00',
      timezoneOffsetMinutes: Number.isFinite(Number(rawSched.timezoneOffsetMinutes))
        ? Number(rawSched.timezoneOffsetMinutes)
        : 420,
    },
  };

  let logs: MessageLogEntry[] | undefined;
  if (Array.isArray(obj.logs)) {
    logs = obj.logs
      .filter((l): l is MessageLogEntry => Boolean(l && typeof l === 'object'))
      .slice(0, 200);
  }

  return {
    ok: true,
    data: {
      rules: validatedRules,
      products: validatedProducts,
      settings,
      logs,
    },
  };
}

export function buildInstallScript(): string {
  return `#!/usr/bin/env bash
set -euo pipefail

echo "=================================================="
echo "  Installer TeleBalas - Bot Auto-Reply Telegram   "
echo "=================================================="
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "[ERROR] Node.js tidak ditemukan. Silakan aktifkan Node.js 18+ di cPanel (Setup Node.js App)."
  exit 1
fi

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "[ERROR] Versi Node.js minimal 18. Versi terdeteksi: $(node -v)"
  exit 1
fi

echo "[1/4] Memeriksa & memasang dependensi Node.js..."
if [ -f "dist/index.html" ] && [ -f "app.cjs" ]; then
  npm install --omit=dev
else
  npm install
  npm run build
  npx esbuild server.ts --bundle --platform=node --format=cjs --outfile=app.cjs --external:express --external:dotenv --external:telegram --external:vite --external:jszip --external:esbuild --external:qrcode
fi

echo "[2/4] Menyiapkan direktori database (data/store.json)..."
mkdir -p data
chmod 700 data
if [ ! -f "data/store.json" ] && [ -f "database/telebalas-database.json" ]; then
  cp database/telebalas-database.json data/store.json
fi
if [ -f "data/store.json" ]; then
  chmod 600 data/store.json
fi

echo "[3/4] Menyiapkan file konfigurasi .env..."
if [ ! -f ".env" ]; then
  SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  ADMIN_PIN_VALUE=""
  if [ -t 0 ]; then
    read -r -p "Masukkan PIN Admin (4-8 digit, kosongkan untuk atur lewat web): " ADMIN_PIN_VALUE || true
  fi
  cat > .env <<EOF
NODE_ENV=production
PORT=3000
ADMIN_SESSION_SECRET=$SECRET
ADMIN_PIN=$ADMIN_PIN_VALUE
EOF
  chmod 600 .env
  echo "File .env berhasil dibuat."
else
  echo "File .env sudah ada, tidak ditimpa."
fi

echo "[4/4] Instalasi selesai!"
echo ""
echo "Cara menjalankan di cPanel (Setup Node.js App):"
echo "  - Application root         : $(pwd)"
echo "  - Application startup file : app.cjs"
echo "  - Application mode         : Production"
echo "  Lalu klik tombol RESTART di cPanel Node.js App."
echo ""
echo "Atau jalankan langsung via terminal / PM2:"
echo "  NODE_ENV=production node app.cjs"
echo "=================================================="
`;
}

export function buildPhpWebInstaller(): string {
  return `<?php
/**
 * TeleBalas - Web Installer cPanel Shared Hosting (Tanpa SSH / Terminal)
 * ----------------------------------------------------------------------
 * Unggah file install.php ini bersama telebalas-cpanel-siap-pakai.zip
 * ke folder aplikasi cPanel Anda, lalu buka: https://domain-anda.com/install.php
 */
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

$baseDir = __DIR__;
$lockFile = $baseDir . '/.install.lock';
$defaultZip = 'telebalas-cpanel-siap-pakai.zip';

function h(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function detectSiteUrl(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'domain-anda.com';
    $host = preg_replace('/[^a-zA-Z0-9.:\\-]/', '', (string)$host);
    return $scheme . '://' . ($host ?: 'domain-anda.com');
}

function isSafeZipEntry(string $name): bool {
    if ($name === '' || strpos($name, "\\0") !== false) return false;
    if ($name[0] === '/' || $name[0] === '\\\\') return false;
    if (preg_match('/^[a-zA-Z]:/', $name)) return false;
    $normalized = str_replace('\\\\', '/', $name);
    $parts = explode('/', $normalized);
    foreach ($parts as $part) {
        if ($part === '..') return false;
    }
    return true;
}

function readLockData(string $lockFile): ?array {
    if (!is_file($lockFile)) return null;
    $raw = @file_get_contents($lockFile);
    if ($raw === false) return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

$lockData = readLockData($lockFile);

// Handle 1-click self-delete after install
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_installer') {
    $submittedToken = (string)($_POST['delete_token'] ?? '');
    $expectedToken = is_array($lockData) ? (string)($lockData['deleteToken'] ?? '') : '';
    if ($expectedToken !== '' && hash_equals($expectedToken, $submittedToken)) {
        $deleted = @unlink(__FILE__);
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installer Dihapus - TeleBalas</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#070b14;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px}.card{max-width:520px;background:#0f172a;border:1px solid #1e293b;border-radius:16px;padding:28px}h1{margin:0 0 10px;font-size:20px;color:#34d399}p{margin:0 0 14px;font-size:14px;line-height:1.6;color:#cbd5e1}a{display:inline-block;background:#0284c7;color:#fff;text-decoration:none;padding:10px 18px;border-radius:10px;font-weight:600;font-size:14px}</style></head><body><div class="card">';
        if ($deleted) {
            echo '<h1>File install.php Berhasil Dihapus</h1><p>Demi keamanan, file installer telah dihapus dari hosting Anda. Silakan lanjutkan langkah Setup Node.js App &amp; Cron Jobs di cPanel lalu buka website Anda.</p>';
        } else {
            echo '<h1>Gagal Menghapus Otomatis</h1><p>Silakan hapus file <code>install.php</code> secara manual melalui File Manager cPanel demi keamanan.</p>';
        }
        echo '<a href="/">Buka TeleBalas</a></div></body></html>';
        exit;
    }
}

$zipFiles = [];
foreach (glob($baseDir . '/*.zip') ?: [] as $zf) {
    $zipFiles[] = basename($zf);
}
usort($zipFiles, function ($a, $b) use ($defaultZip) {
    if ($a === $defaultZip) return -1;
    if ($b === $defaultZip) return 1;
    return strcmp($a, $b);
});

$phpOk = version_compare(PHP_VERSION, '7.4.0', '>=');
$zipExtOk = class_exists('ZipArchive');
$dirWritable = is_writable($baseDir);
$alreadyExtracted = is_file($baseDir . '/app.cjs') && is_file($baseDir . '/dist/index.html');
$siteUrl = detectSiteUrl();

$errors = [];
$installSuccess = false;
$summary = [];
$deleteToken = is_array($lockData) ? (string)($lockData['deleteToken'] ?? '') : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'install') {
    if ($lockData !== null) {
        $errors[] = 'Installer terkunci karena file .install.lock sudah ada. Hapus file .install.lock lewat File Manager cPanel hanya jika Anda benar-benar ingin mengulang instalasi.';
    } else {
        $selectedZip = basename((string)($_POST['zip_file'] ?? ''));
        $adminPin = trim((string)($_POST['admin_pin'] ?? ''));
        $overwriteStore = isset($_POST['overwrite_store']) && $_POST['overwrite_store'] === '1';

        if ($adminPin !== '' && !preg_match('/^\\d{4,8}$/', $adminPin)) {
            $errors[] = 'PIN Admin harus berupa 4 sampai 8 digit angka, atau kosongkan untuk diatur lewat web.';
        }

        if (!$dirWritable) {
            $errors[] = 'Direktori saat ini tidak memiliki izin tulis (writable). Periksa permission folder di File Manager cPanel (755).';
        }

        if (empty($errors)) {
            // 1. Extract ZIP if available and selected
            if ($selectedZip !== '' && in_array($selectedZip, $zipFiles, true)) {
                if (!$zipExtOk) {
                    $errors[] = 'Ekstensi PHP ZipArchive tidak aktif di hosting Anda. Ekstrak file ZIP secara manual lewat File Manager cPanel (klik kanan -> Extract), lalu jalankan ulang installer ini tanpa memilih ZIP.';
                } else {
                    $zip = new ZipArchive();
                    $zipPath = $baseDir . '/' . $selectedZip;
                    if ($zip->open($zipPath) !== true) {
                        $errors[] = 'Gagal membuka file ZIP: ' . $selectedZip;
                    } else {
                        $extractedCount = 0;
                        for ($i = 0; $i < $zip->numFiles; $i++) {
                            $entryName = (string)$zip->getNameIndex($i);
                            if (!isSafeZipEntry($entryName)) {
                                continue;
                            }
                            $cleanName = ltrim(str_replace('\\\\', '/', $entryName), '/');
                            if ($cleanName === '' || $cleanName === '.env' || $cleanName === 'install.php') {
                                continue;
                            }
                            if (!$overwriteStore && $cleanName === 'data/store.json' && is_file($baseDir . '/data/store.json')) {
                                continue;
                            }
                            $targetPath = $baseDir . '/' . $cleanName;
                            if (substr($cleanName, -1) === '/') {
                                if (!is_dir($targetPath)) {
                                    @mkdir($targetPath, 0755, true);
                                }
                                continue;
                            }
                            $parentDir = dirname($targetPath);
                            if (!is_dir($parentDir)) {
                                @mkdir($parentDir, 0755, true);
                            }
                            $content = $zip->getFromIndex($i);
                            if ($content !== false) {
                                @file_put_contents($targetPath, $content);
                                $extractedCount++;
                            }
                        }
                        $zip->close();
                        $summary[] = 'Berhasil mengekstrak ' . $extractedCount . ' file dari ' . $selectedZip . '.';
                    }
                }
            } elseif (!$alreadyExtracted) {
                $errors[] = 'File ZIP belum dipilih dan file aplikasi (app.cjs & dist/) belum ditemukan. Upload telebalas-cpanel-siap-pakai.zip terlebih dahulu.';
            } else {
                $summary[] = 'Menggunakan file aplikasi TeleBalas yang sudah terekstrak.';
            }
        }

        if (empty($errors)) {
            // 2. Prepare data/store.json
            $dataDir = $baseDir . '/data';
            if (!is_dir($dataDir)) {
                @mkdir($dataDir, 0700, true);
            } else {
                @chmod($dataDir, 0700);
            }
            $storePath = $dataDir . '/store.json';
            $backupJson = $baseDir . '/database/telebalas-database.json';
            if ((!is_file($storePath) || $overwriteStore) && is_file($backupJson)) {
                @copy($backupJson, $storePath);
                $summary[] = 'Database awal data/store.json berhasil disiapkan.';
            }
            if (is_file($storePath)) {
                @chmod($storePath, 0600);
            }

            // 3. Create .env safely if not present
            $envPath = $baseDir . '/.env';
            if (!is_file($envPath)) {
                $secret = bin2hex(random_bytes(32));
                $envLines = [
                    'NODE_ENV=production',
                    'PORT=3000',
                    'ADMIN_SESSION_SECRET=' . $secret,
                    'ADMIN_PIN=' . $adminPin,
                ];
                $written = @file_put_contents($envPath, implode(PHP_EOL, $envLines) . PHP_EOL);
                if ($written === false) {
                    $errors[] = 'Gagal menulis file .env. Periksa izin folder cPanel Anda.';
                } else {
                    @chmod($envPath, 0600);
                    $summary[] = $adminPin !== ''
                        ? 'File .env berhasil dibuat dengan ADMIN_PIN pilihan Anda.'
                        : 'File .env berhasil dibuat (PIN admin akan diatur saat pertama kali membuka website).';
                }
            } else {
                $summary[] = 'File .env sudah ada dan tetap dipertahankan.';
            }
        }

        if (empty($errors)) {
            $deleteToken = bin2hex(random_bytes(24));
            @file_put_contents(
                $lockFile,
                json_encode([
                    'installedAt' => gmdate('c'),
                    'deleteToken' => $deleteToken,
                ], JSON_PRETTY_PRINT)
            );
            @chmod($lockFile, 0600);
            $lockData = ['installedAt' => gmdate('c'), 'deleteToken' => $deleteToken];
            $installSuccess = true;
        }
    }
}

$cronCommand = 'curl -fsS ' . $siteUrl . '/api/keepalive >/dev/null 2>&1';
$appRootHint = basename($baseDir);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Installer cPanel Shared Hosting - TeleBalas</title>
  <style>
    :root{color-scheme:dark light}
    *{box-sizing:border-box}
    body{margin:0;padding:28px 16px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#060a13;color:#e2e8f0;line-height:1.55}
    .wrap{max-width:780px;margin:0 auto}
    .hero{background:linear-gradient(135deg,#0b1120,#111d38,#0e294d);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:24px 28px;margin-bottom:20px}
    .hero h1{margin:0 0 6px;font-size:22px;color:#fff}
    .hero p{margin:0;font-size:13.5px;color:#cbd5e1}
    .card{background:#0f1624;border:1px solid #1e293b;border-radius:16px;padding:22px 24px;margin-bottom:18px}
    .card h2{margin:0 0 12px;font-size:15.5px;color:#f8fafc}
    .checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
    .check{background:#0b1120;border:1px solid #1e293b;border-radius:12px;padding:12px 14px;font-size:13px}
    .ok{color:#34d399;font-weight:600}.bad{color:#fb7185;font-weight:600}.warn{color:#fbbf24;font-weight:600}
    label{display:block;font-size:12.5px;font-weight:600;color:#cbd5e1;margin-bottom:6px}
    input[type=text],input[type=password],select{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #334155;background:#090f1d;color:#f8fafc;font-size:14px;margin-bottom:14px}
    .checkline{display:flex;align-items:center;gap:8px;font-size:13px;color:#cbd5e1;margin-bottom:16px;cursor:pointer}
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:11px;padding:11px 20px;font-size:14px;font-weight:600;cursor:pointer;color:#fff;background:linear-gradient(90deg,#0284c7,#4f46e5)}
    .btn:hover{opacity:.95}
    .btn-danger{background:linear-gradient(90deg,#e11d48,#be123c)}
    .alert{border-radius:12px;padding:13px 16px;font-size:13.5px;margin-bottom:16px}
    .alert-err{background:rgba(225,29,72,.14);border:1px solid rgba(244,63,94,.35);color:#fecdd3}
    .alert-ok{background:rgba(16,185,129,.12);border:1px solid rgba(52,211,153,.35);color:#a7f3d0}
    .alert-warn{background:rgba(245,158,11,.12);border:1px solid rgba(251,191,36,.35);color:#fde68a}
    code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#070b14;border:1px solid #1e293b;border-radius:8px;color:#7dd3fc}
    code{padding:2px 6px;font-size:12.5px}
    pre{padding:12px 14px;overflow-x:auto;font-size:12.5px;margin:8px 0}
    ol{margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#cbd5e1}
    li{margin-bottom:9px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>TeleBalas — Installer Web cPanel Shared Hosting</h1>
      <p>Pasang website &amp; bot auto-reply Telegram 24/7 langsung dari browser tanpa SSH atau Terminal.</p>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-err">
        <strong>Instalasi belum dapat dilanjutkan:</strong>
        <ul style="margin:6px 0 0;padding-left:18px">
          <?php foreach ($errors as $err): ?>
            <li><?php echo h($err); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($installSuccess): ?>
      <div class="alert alert-ok">
        <strong>Instalasi File &amp; Database Selesai!</strong>
        <ul style="margin:6px 0 0;padding-left:18px">
          <?php foreach ($summary as $item): ?>
            <li><?php echo h($item); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="card">
        <h2>Langkah Berikutnya di cPanel (Tanpa SSH / Terminal)</h2>
        <ol>
          <li>Buka menu <strong>Setup Node.js App</strong> di cPanel Anda, lalu klik <strong>Create Application</strong>:
            <br>Node.js version: <code>18 / 20 / 22</code> · Mode: <code>Production</code> · Application root: <code><?php echo h($appRootHint); ?></code> · Application startup file: <code>app.cjs</code>
          </li>
          <li>Klik <strong>Create</strong>, lalu klik tombol <strong>Run NPM Install</strong> pada bagian Detected configuration files.</li>
          <li>Klik tombol <strong>Restart</strong> di bagian atas Setup Node.js App.</li>
          <li><strong>Agar Bot Aktif 24 Jam / 7 Hari Non-Stop:</strong> Buka menu <strong>Cron Jobs</strong> di cPanel, pilih jadwal <em>Once Per Five Minutes</em> (<code>*/5 * * * *</code>), lalu masukkan perintah ini:
            <pre><?php echo h($cronCommand); ?></pre>
            Cron Job GUI ini mencegah Shared Hosting menidurkan aplikasi Node.js dan menjaga koneksi MTProto Telegram tetap hidup 24/7.
          </li>
        </ol>
      </div>

      <?php if ($deleteToken !== ''): ?>
        <div class="card">
          <h2>Langkah Keamanan Wajib</h2>
          <p style="font-size:13.5px;color:#cbd5e1;margin-top:0">Hapus file <code>install.php</code> sekarang agar tidak bisa diakses pihak lain.</p>
          <form method="post">
            <input type="hidden" name="action" value="delete_installer">
            <input type="hidden" name="delete_token" value="<?php echo h($deleteToken); ?>">
            <button type="submit" class="btn btn-danger">Hapus install.php Sekarang</button>
          </form>
        </div>
      <?php endif; ?>

    <?php elseif ($lockData !== null): ?>
      <div class="alert alert-warn">
        <strong>Installer Sudah Terkunci (.install.lock ditemukan)</strong><br>
        TeleBalas sudah pernah diinstal pada folder ini pada <code><?php echo h((string)($lockData['installedAt'] ?? '-')); ?></code>. Jika Anda perlu menginstal ulang, hapus file <code>.install.lock</code> melalui File Manager cPanel.
      </div>
      <?php if ($deleteToken !== ''): ?>
        <div class="card">
          <form method="post">
            <input type="hidden" name="action" value="delete_installer">
            <input type="hidden" name="delete_token" value="<?php echo h($deleteToken); ?>">
            <button type="submit" class="btn btn-danger">Hapus install.php Sekarang</button>
          </form>
        </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="card">
        <h2>1. Pemeriksaan Hosting cPanel</h2>
        <div class="checks">
          <div class="check">Versi PHP: <span class="<?php echo $phpOk ? 'ok' : 'bad'; ?>"><?php echo h(PHP_VERSION); ?></span></div>
          <div class="check">Ekstensi ZipArchive: <span class="<?php echo $zipExtOk ? 'ok' : 'warn'; ?>"><?php echo $zipExtOk ? 'Tersedia' : 'Tidak Aktif (Ekstrak manual)'; ?></span></div>
          <div class="check">Izin Folder: <span class="<?php echo $dirWritable ? 'ok' : 'bad'; ?>"><?php echo $dirWritable ? 'Bisa Ditulis' : 'Read-Only'; ?></span></div>
          <div class="check">Status Aplikasi: <span class="ok"><?php echo $alreadyExtracted ? 'Sudah Terekstrak' : (count($zipFiles) > 0 ? 'ZIP Siap Ekstrak' : 'Menunggu ZIP'); ?></span></div>
        </div>
      </div>

      <form method="post" class="card">
        <input type="hidden" name="action" value="install">
        <h2>2. Konfigurasi &amp; Ekstrak Otomatis</h2>

        <label for="zip_file">Pilih Paket ZIP TeleBalas</label>
        <select id="zip_file" name="zip_file">
          <?php if ($alreadyExtracted): ?>
            <option value="">(Lewati ekstrak — file aplikasi sudah tersedia di folder ini)</option>
          <?php endif; ?>
          <?php foreach ($zipFiles as $zf): ?>
            <option value="<?php echo h($zf); ?>" <?php echo $zf === $defaultZip ? 'selected' : ''; ?>><?php echo h($zf); ?></option>
          <?php endforeach; ?>
          <?php if (empty($zipFiles) && !$alreadyExtracted): ?>
            <option value="">Belum ada file .zip di folder ini</option>
          <?php endif; ?>
        </select>

        <label for="admin_pin">PIN Admin Panel (4–8 digit angka, opsional)</label>
        <input id="admin_pin" name="admin_pin" type="password" inputmode="numeric" pattern="[0-9]{4,8}" maxlength="8" placeholder="Kosongkan untuk membuat PIN saat membuka website pertama kali">

        <label class="checkline">
          <input type="checkbox" name="overwrite_store" value="1">
          <span>Timpa <code>data/store.json</code> dengan database bawaan ZIP (centang hanya untuk instalasi baru)</span>
        </label>

        <button type="submit" class="btn">Ekstrak &amp; Pasang TeleBalas Sekarang</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
`;
}

export function buildCpanelGuide(): string {
  return `PANDUAN INSTALASI TELEBALAS DI CPANEL SHARED HOSTING (TANPA SSH / TERMINAL)
===============================================================================

Paket ZIP ini sudah berisi:
1. install.php                    -> Installer Web GUI untuk cPanel Shared Hosting (TANPA SSH)
2. app.cjs                        -> File startup Node.js siap jalan untuk cPanel (Phusion Passenger)
3. dist/                          -> Frontend React yang sudah selesai di-build (siap pakai)
4. data/store.json                -> Database awal berisi aturan, produk jualan, dan pengaturan Anda
5. database/telebalas-database.json & .sql -> Cadangan database JSON & SQL (MySQL/phpMyAdmin)
6. install.sh                     -> Script installer otomatis (opsional jika punya SSH / VPS)

-------------------------------------------------------------------------------
CARA 1 (DIREKOMENDASIKAN): SHARED HOSTING CPANEL TANPA SSH / TERMINAL
-------------------------------------------------------------------------------
A. Pasang via Browser Installer (install.php):
1. Login ke cPanel hosting Anda, buka **File Manager**.
2. Masuk ke folder domain Anda (misal public_html atau folder khusus /home/user/telebalas).
3. Upload file \`telebalas-cpanel-siap-pakai.zip\` dan file \`install.php\` ke folder yang sama.
   (Atau upload ZIP, klik kanan -> Extract di File Manager jika lebih suka).
4. Buka browser dan kunjungi: https://domain-anda.com/install.php
5. Klik **"Ekstrak & Pasang TeleBalas Sekarang"**. Installer akan menyiapkan folder data,
   database store.json, dan file konfigurasi .env secara otomatis.
6. Klik tombol **"Hapus install.php Sekarang"** setelah instalasi selesai.

B. Aktifkan Aplikasi di cPanel (Setup Node.js App):
1. Di halaman utama cPanel, buka menu **Setup Node.js App**.
2. Klik **Create Application**:
   - Node.js version         : Pilih 18.x / 20.x / 22.x
   - Application mode        : Production
   - Application root        : folder tempat Anda mengekstrak file (misal: telebalas)
   - Application URL         : Pilih domain atau subdomain Anda
   - Application startup file: app.cjs
3. Klik **Create**, lalu klik tombol **Run NPM Install** (tidak perlu buka Terminal/SSH).
4. Klik tombol **Restart** di bagian atas halaman Setup Node.js App.

C. Wajib Agar Bot Aktif 24 Jam / 7 Hari Non-Stop (Menu Cron Jobs):
Shared hosting cPanel akan menidurkan aplikasi Node.js jika tidak ada akses HTTP selama
beberapa menit. Agar bot Telegram Anda tetap online & membalas otomatis 24/7 tanpa terputus:
1. Buka menu **Cron Jobs** di halaman utama cPanel (tersedia tanpa SSH).
2. Pada bagian *Common Settings*, pilih **Once Per Five Minutes (*/5 * * * *)**.
3. Pada kolom *Command*, masukkan:
   curl -fsS https://domain-anda.com/api/keepalive >/dev/null 2>&1
4. Klik **Add New Cron Job**.
Endpoint /api/keepalive menjaga Phusion Passenger tetap bangun sekaligus memicu
watchdog Telegram agar koneksi MTProto akun pribadi Anda otomatis menyambung kembali
jika sempat terputus jaringan.

-------------------------------------------------------------------------------
CARA 2 (OPSIONAL): INSTALL OTOMATIS VIA CPANEL TERMINAL / SSH / VPS
-------------------------------------------------------------------------------
1. Upload dan Extract file ZIP ini di folder tujuan (misal ~/telebalas).
2. Jalankan perintah berikut:
   cd ~/telebalas && chmod +x install.sh && bash install.sh
3. Jalankan dengan PM2 di VPS:
   pm2 start app.cjs --name telebalas && pm2 save
`;
}

function addDirectoryToZip(
  zip: JSZip,
  rootDir: string,
  relDir: string,
  options: { excludeTestFiles?: boolean } = {}
): void {
  const fullDir = path.resolve(rootDir, relDir);
  if (!fullDir.startsWith(rootDir + path.sep) || !fs.existsSync(fullDir)) {
    return;
  }

  const entries = fs.readdirSync(fullDir, { withFileTypes: true });
  for (const entry of entries) {
    const relPath = path.posix.join(relDir.split(path.sep).join('/'), entry.name);
    const fullPath = path.resolve(rootDir, relPath);
    if (!fullPath.startsWith(rootDir + path.sep)) continue;

    if (entry.isDirectory()) {
      addDirectoryToZip(zip, rootDir, relPath, options);
    } else if (entry.isFile()) {
      if (options.excludeTestFiles && entry.name.endsWith('.test.ts')) continue;
      zip.file(relPath, fs.readFileSync(fullPath));
    }
  }
}

export async function buildCpanelBundleZip(
  store: PersistedStore,
  includeLogs = true
): Promise<Buffer> {
  const rootDir = process.cwd();
  const zip = new JSZip();

  // 1. Ensure production frontend dist/ exists
  const distIndex = path.resolve(rootDir, 'dist', 'index.html');
  if (!fs.existsSync(distIndex)) {
    const { build } = await import('vite');
    await build({ root: rootDir, logLevel: 'silent' });
  }

  // 2. Compile production CommonJS startup file app.cjs for cPanel Passenger
  let appCjsBuffer: Buffer | null = null;
  const serverEntry = path.resolve(rootDir, 'server.ts');
  if (fs.existsSync(serverEntry)) {
    try {
      const esbuild = await import('esbuild');
      const result = await esbuild.build({
        entryPoints: [serverEntry],
        bundle: true,
        platform: 'node',
        format: 'cjs',
        write: false,
        external: ['express', 'dotenv', 'telegram', 'vite', 'jszip', 'esbuild', 'qrcode'],
      });
      if (result.outputFiles && result.outputFiles[0]) {
        appCjsBuffer = Buffer.from(result.outputFiles[0].contents);
      }
    } catch {
      const prebuiltAppCjs = path.resolve(rootDir, 'app.cjs');
      if (fs.existsSync(prebuiltAppCjs)) {
        appCjsBuffer = fs.readFileSync(prebuiltAppCjs);
      }
    }
  } else {
    const prebuiltAppCjs = path.resolve(rootDir, 'app.cjs');
    if (fs.existsSync(prebuiltAppCjs)) {
      appCjsBuffer = fs.readFileSync(prebuiltAppCjs);
    }
  }

  if (appCjsBuffer) {
    zip.file('app.cjs', appCjsBuffer);
  }

  // 3. Include explicit allowlist of root configuration & source files (never .env, .git, node_modules, or raw data/)
  const rootFiles = [
    'package.json',
    '.env.example',
    '.gitignore',
    'index.html',
    'metadata.json',
    'tsconfig.json',
    'vite.config.ts',
    'server.ts',
  ];
  for (const filename of rootFiles) {
    const full = path.resolve(rootDir, filename);
    if (full.startsWith(rootDir + path.sep) && fs.existsSync(full)) {
      zip.file(filename, fs.readFileSync(full));
    }
  }

  addDirectoryToZip(zip, rootDir, 'src', { excludeTestFiles: true });
  addDirectoryToZip(zip, rootDir, 'server', { excludeTestFiles: true });
  addDirectoryToZip(zip, rootDir, 'dist');

  // 4. Include sanitized ready-to-use database & SQL backup
  const sanitizedStore = buildSanitizedDatabaseExport(store, includeLogs);
  const storeJsonText = JSON.stringify(sanitizedStore, null, 2);
  zip.file('data/store.json', storeJsonText);
  zip.file('database/telebalas-database.json', storeJsonText);
  zip.file('database/telebalas-database.sql', generateSqlDump(store));

  // 5. Include PHP GUI Web Installer (No-SSH), Bash Installer & Indonesian cPanel guide
  zip.file('install.php', buildPhpWebInstaller());
  zip.file('install.sh', buildInstallScript(), { unixPermissions: '755' });
  zip.file('PANDUAN-CPANEL.txt', buildCpanelGuide());

  return zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
    platform: 'UNIX',
  });
}
