import { Api, TelegramClient, sessions } from 'telegram';
import { NewMessage, type NewMessageEvent } from 'telegram/events/index.js';
import {
  detectOrderIntent,
  formatRupiah,
  matchMessageToRules,
  normalizeIdentifier,
} from '../src/shared/autoReplyEngine';
import type { TelegramAccountPublic, TelegramConnectionStatus } from '../src/shared/types';
import {
  createQrisOrder,
  registerTelegramSender,
  retryPendingDeliveries,
} from './gopayMerchant';
import {
  appendLog,
  buildPublicAccount,
  loadStore,
  maskPhone,
  saveStore,
} from './store';

interface PendingAuthResolvers {
  resolveCode?: (code: string) => void;
  rejectCode?: (err: Error) => void;
  resolvePassword?: (password: string) => void;
  rejectPassword?: (err: Error) => void;
  loginPromise?: Promise<void>;
}

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

class TelegramUserbotManager {
  private client: TelegramClient | null = null;
  private status: TelegramConnectionStatus = 'disconnected';
  private errorMessage: string | null = null;
  private pending: PendingAuthResolvers = {};
  private cooldownMap = new Map<string, number>();
  private selfId: string | null = null;
  private listenerAttached = false;
  private shouldStayConnected = false;
  private watchdogTimer: ReturnType<typeof setInterval> | null = null;
  private lastHeartbeatAt = 0;
  private reconnectingPromise: Promise<void> | null = null;

  getPublicAccount(): TelegramAccountPublic {
    return buildPublicAccount(this.status, this.errorMessage);
  }

  isReady(): boolean {
    return Boolean(this.client && this.client.connected && this.status === 'connected');
  }

  private resolvePeerTarget(chatId: string): string | number {
    const trimmed = chatId.trim();
    if (/^-?\d+$/.test(trimmed)) {
      const asNum = Number(trimmed);
      if (Number.isSafeInteger(asNum)) return asNum;
    }
    return trimmed;
  }

  async sendDirectMessage(chatId: string, text: string): Promise<void> {
    if (!this.client || !this.client.connected) {
      throw new Error('Koneksi Telegram sedang tidak aktif.');
    }
    await this.client.sendMessage(this.resolvePeerTarget(chatId), {
      message: text,
      parseMode: 'markdown',
    });
  }

  async sendPhotoWithCaption(
    chatId: string,
    pngBuffer: Buffer,
    caption: string,
    replyTo?: number
  ): Promise<void> {
    if (!this.client || !this.client.connected) {
      throw new Error('Koneksi Telegram sedang tidak aktif.');
    }
    const target = this.resolvePeerTarget(chatId);
    const namedFile = Object.assign(Buffer.from(pngBuffer), { name: 'qris-gopay.png' });
    try {
      await this.client.sendFile(target, {
        file: namedFile,
        caption,
        parseMode: 'markdown',
        replyTo,
      });
    } catch {
      await this.client.sendMessage(target, {
        message: caption,
        parseMode: 'markdown',
        replyTo,
      });
    }
  }

  private startWatchdog(): void {
    if (this.watchdogTimer) return;
    this.watchdogTimer = setInterval(() => {
      void this.ensureConnected();
    }, 45_000);
    if (typeof this.watchdogTimer.unref === 'function') {
      this.watchdogTimer.unref();
    }
  }

  private stopWatchdog(): void {
    if (this.watchdogTimer) {
      clearInterval(this.watchdogTimer);
      this.watchdogTimer = null;
    }
  }

  async ensureConnected(): Promise<void> {
    if (!this.shouldStayConnected) return;
    if (this.status === 'awaiting_code' || this.status === 'awaiting_password') return;
    if (this.reconnectingPromise) {
      await this.reconnectingPromise;
      return;
    }

    const store = loadStore();
    const { apiId, apiHash, sessionString } = store.credentials;
    if (!apiId || !apiHash || !sessionString) return;

    if (this.client && this.client.connected && this.status === 'connected') {
      const now = Date.now();
      if (now - this.lastHeartbeatAt >= 4 * 60_000) {
        try {
          await this.client.getMe();
          this.lastHeartbeatAt = now;
        } catch {
          // Heartbeat failed -> force reconnect below
          await this.reconnectWithSavedSession(apiId, apiHash, sessionString);
        }
      }
      return;
    }

    await this.reconnectWithSavedSession(apiId, apiHash, sessionString);
  }

  private async reconnectWithSavedSession(
    apiId: number,
    apiHash: string,
    sessionString: string
  ): Promise<void> {
    if (this.reconnectingPromise) {
      await this.reconnectingPromise;
      return;
    }

    this.reconnectingPromise = (async () => {
      try {
        this.status = 'connecting';
        this.errorMessage = null;
        await this.connectClientWithSession(apiId, apiHash, sessionString);
      } catch (err) {
        this.status = 'error';
        this.errorMessage =
          err instanceof Error
            ? `Menyambung ulang otomatis: ${err.message}`
            : 'Menyambung ulang koneksi 24/7 gagal sementara.';
      } finally {
        this.reconnectingPromise = null;
      }
    })();

    await this.reconnectingPromise;
  }

  async initFromSavedSession(): Promise<void> {
    const store = loadStore();
    const { apiId, apiHash, sessionString } = store.credentials;
    if (!apiId || !apiHash || !sessionString) {
      this.shouldStayConnected = false;
      this.status = 'disconnected';
      return;
    }

    this.shouldStayConnected = true;
    this.startWatchdog();

    try {
      this.status = 'connecting';
      this.errorMessage = null;
      await this.connectClientWithSession(apiId, apiHash, sessionString);
    } catch (err) {
      this.status = 'error';
      this.errorMessage =
        err instanceof Error
          ? `Gagal menyambungkan ulang sesi tersimpan: ${err.message}`
          : 'Gagal menyambungkan ulang sesi tersimpan.';
    }
  }

  private async tearDownClient(): Promise<void> {
    this.pending.rejectCode?.(new Error('Sesi login dibatalkan.'));
    this.pending.rejectPassword?.(new Error('Sesi login dibatalkan.'));
    this.pending = {};
    this.listenerAttached = false;
    this.selfId = null;

    if (this.client) {
      try {
        await this.client.disconnect();
      } catch {
        // Ignore disconnect errors during cleanup
      }
      this.client = null;
    }
  }

  private attachMessageListener(client: TelegramClient): void {
    if (this.listenerAttached) return;
    this.listenerAttached = true;

    client.addEventHandler(async (event: NewMessageEvent) => {
      try {
        const message = event.message;
        if (!message) return;
        // Never reply to our own outgoing messages
        if (message.out) return;

        const text = typeof message.message === 'string' ? message.message : '';
        if (!text.trim()) return;

        const sender = await message.getSender();
        const senderId = sender?.id ? String(sender.id) : String(message.chatId ?? 'unknown');

        if (this.selfId && senderId === this.selfId) return;

        // Ignore Telegram official service account (777000) or bots if sender is bot
        if (senderId === '777000') return;
        if (sender && 'bot' in sender && sender.bot) return;

        const isGroup = Boolean(event.isGroup || event.isChannel);
        if (event.isChannel && !event.isGroup) return; // Never auto-reply to broadcast channels

        const firstName =
          sender && 'firstName' in sender && typeof sender.firstName === 'string'
            ? sender.firstName
            : '';
        const lastName =
          sender && 'lastName' in sender && typeof sender.lastName === 'string'
            ? sender.lastName
            : '';
        const title =
          sender && 'title' in sender && typeof sender.title === 'string' ? sender.title : '';
        const senderName = [firstName, lastName].filter(Boolean).join(' ') || title || 'Pengguna';
        const senderUsername =
          sender && 'username' in sender && typeof sender.username === 'string'
            ? sender.username
            : null;

        const chatId = message.chatId ? String(message.chatId) : senderId;
        const store = loadStore();

        const isBlacklisted = store.settings.blacklist.some((entry) => {
          const norm = normalizeIdentifier(entry);
          return (
            norm === normalizeIdentifier(senderId) ||
            (senderUsername && norm === normalizeIdentifier(senderUsername))
          );
        });
        const passesWhitelist =
          !store.settings.ignoreContactsInWhitelistOnly ||
          store.settings.whitelist.some((entry) => {
            const norm = normalizeIdentifier(entry);
            return (
              norm === normalizeIdentifier(senderId) ||
              (senderUsername && norm === normalizeIdentifier(senderUsername))
            );
          });

        if (
          store.settings.botEnabled &&
          !(isGroup && store.settings.ignoreGroupsByDefault) &&
          !isBlacklisted &&
          passesWhitelist &&
          store.gopayConfig.enabled
        ) {
          const orderedProduct = detectOrderIntent(text, store.products);
          if (orderedProduct) {
            if (store.settings.typingIndicator && message.chatId) {
              try {
                await client.invoke(
                  new Api.messages.SetTyping({
                    peer: message.chatId,
                    action: new Api.SendMessageTypingAction(),
                  })
                );
              } catch {
                // Non-fatal
              }
            }

            const orderRes = await createQrisOrder({
              productId: orderedProduct.id,
              buyerChatId: chatId,
              buyerSenderId: senderId,
              buyerName: senderName,
              buyerUsername: senderUsername,
              source: 'telegram',
            });

            if (!orderRes.ok || !orderRes.order || !orderRes.qrPngBuffer || !orderRes.invoiceCaption) {
              const fallbackNotice =
                orderRes.error || `Pesanan untuk ${orderedProduct.name} belum dapat diproses.`;
              await client.sendMessage(message.chatId ?? senderId, {
                message: fallbackNotice,
                parseMode: 'markdown',
                replyTo: message.id,
              });
              appendLog({
                senderId,
                senderName,
                senderUsername,
                chatType: isGroup ? 'group' : 'private',
                incomingText: text.slice(0, 300),
                matchedRuleId: orderedProduct.id,
                matchedRuleName: `QRIS Order Gagal: ${orderedProduct.name}`,
                replyText: fallbackNotice,
                outcome: 'replied',
                reason: orderRes.error || 'Stok atau QRIS tidak siap.',
              });
              return;
            }

            await this.sendPhotoWithCaption(
              chatId,
              orderRes.qrPngBuffer,
              orderRes.invoiceCaption,
              message.id
            );

            appendLog({
              senderId,
              senderName,
              senderUsername,
              chatType: isGroup ? 'group' : 'private',
              incomingText: text.slice(0, 300),
              matchedRuleId: orderedProduct.id,
              matchedRuleName: `QRIS Invoice: ${orderedProduct.name}`,
              replyText: `Invoice ${orderRes.order.orderCode} (${formatRupiah(orderRes.order.totalAmount)}) dikirim beserta QRIS GoPay.`,
              outcome: 'replied',
              reason: `Menunggu pembayaran mutasi GoPay sebesar ${formatRupiah(orderRes.order.totalAmount)}.`,
            });
            return;
          }
        }

        const evaluation = matchMessageToRules(
          {
            senderId,
            senderName,
            senderUsername,
            chatId,
            chatType: isGroup ? 'group' : 'private',
            text,
          },
          store.rules,
          store.settings,
          this.cooldownMap,
          new Date(),
          {},
          store.products
        );

        const matchedLabel = evaluation.matchedRule
          ? evaluation.matchedRule.name
          : evaluation.matchedProduct
            ? `Produk: ${evaluation.matchedProduct.name}`
            : evaluation.matchedDefaultReply
              ? 'Balasan Default (Semua Pesan)'
              : null;
        const matchedId =
          evaluation.matchedRule?.id ??
          evaluation.matchedProduct?.id ??
          (evaluation.matchedDefaultReply ? 'default_reply' : null);

        if (!evaluation.shouldReply || !evaluation.renderedReply) {
          appendLog({
            senderId,
            senderName,
            senderUsername,
            chatType: isGroup ? 'group' : 'private',
            incomingText: text.slice(0, 300),
            matchedRuleId: matchedId,
            matchedRuleName: matchedLabel,
            replyText: null,
            outcome: 'skipped',
            reason: evaluation.reason,
          });
          return;
        }

        if (evaluation.cooldownKey) {
          this.cooldownMap.set(evaluation.cooldownKey, Date.now());
        }

        if (store.settings.typingIndicator && message.chatId) {
          try {
            await client.invoke(
              new Api.messages.SetTyping({
                peer: message.chatId,
                action: new Api.SendMessageTypingAction(),
              })
            );
          } catch {
            // Typing indicator failure is non-fatal
          }
        }

        if (evaluation.delayMs > 0) {
          await sleep(Math.min(evaluation.delayMs, 15000));
        }

        await client.sendMessage(message.chatId ?? senderId, {
          message: evaluation.renderedReply,
          replyTo: evaluation.quoteOriginal ? message.id : undefined,
        });

        const freshStore = loadStore();
        if (evaluation.matchedRule) {
          const ruleRef = freshStore.rules.find((r) => r.id === evaluation.matchedRule?.id);
          if (ruleRef) {
            ruleRef.hitCount += 1;
            ruleRef.updatedAt = new Date().toISOString();
            saveStore(freshStore);
          }
        } else if (evaluation.matchedProduct) {
          const prodRef = freshStore.products.find(
            (p) => p.id === evaluation.matchedProduct?.id
          );
          if (prodRef) {
            prodRef.hitCount += 1;
            prodRef.updatedAt = new Date().toISOString();
            saveStore(freshStore);
          }
        }

        appendLog({
          senderId,
          senderName,
          senderUsername,
          chatType: isGroup ? 'group' : 'private',
          incomingText: text.slice(0, 300),
          matchedRuleId: matchedId,
          matchedRuleName: matchedLabel,
          replyText: evaluation.renderedReply.slice(0, 500),
          outcome: 'replied',
          reason: evaluation.reason,
        });
      } catch (err) {
        appendLog({
          senderId: 'system',
          senderName: 'Sistem Telegram',
          senderUsername: null,
          chatType: 'private',
          incomingText: '-',
          matchedRuleId: null,
          matchedRuleName: null,
          replyText: null,
          outcome: 'failed',
          reason: err instanceof Error ? err.message : 'Gagal mengirim balasan otomatis.',
        });
      }
    }, new NewMessage({ incoming: true }));
  }

  private async finalizeConnectedClient(
    client: TelegramClient,
    apiId: number,
    apiHash: string,
    phoneRaw?: string
  ): Promise<void> {
    const me = await client.getMe();
    const sessionString = client.session.save() as unknown as string;

    const firstName = 'firstName' in me && typeof me.firstName === 'string' ? me.firstName : null;
    const lastName = 'lastName' in me && typeof me.lastName === 'string' ? me.lastName : null;
    const username = 'username' in me && typeof me.username === 'string' ? me.username : null;
    const telegramId = me.id ? String(me.id) : null;
    const phoneVal =
      phoneRaw || ('phone' in me && typeof me.phone === 'string' ? `+${me.phone}` : null);

    this.selfId = telegramId;

    const store = loadStore();
    store.credentials = {
      apiId,
      apiHash,
      sessionString,
      phoneMasked: maskPhone(phoneVal),
      firstName,
      lastName,
      username,
      telegramId,
      connectedAt: new Date().toISOString(),
    };
    saveStore(store);

    this.shouldStayConnected = true;
    this.lastHeartbeatAt = Date.now();
    this.status = 'connected';
    this.errorMessage = null;
    this.startWatchdog();
    this.attachMessageListener(client);
    void retryPendingDeliveries();
  }

  async startPhoneLogin(params: {
    apiId: number;
    apiHash: string;
    phoneNumber: string;
  }): Promise<TelegramAccountPublic> {
    await this.tearDownClient();

    const { apiId, apiHash, phoneNumber } = params;
    const stringSession = new sessions.StringSession('');
    const client = new TelegramClient(stringSession, apiId, apiHash, {
      connectionRetries: 50,
      retryDelay: 3000,
      autoReconnect: true,
    });

    this.client = client;
    this.status = 'connecting';
    this.errorMessage = null;

    const store = loadStore();
    store.credentials.apiId = apiId;
    store.credentials.apiHash = apiHash;
    store.credentials.phoneMasked = maskPhone(phoneNumber);
    saveStore(store);

    let awaitingStepPromiseResolve: (() => void) | null = null;
    let awaitingStepPromiseReject: ((err: Error) => void) | null = null;

    const firstTransition = new Promise<void>((resolve, reject) => {
      awaitingStepPromiseResolve = resolve;
      awaitingStepPromiseReject = reject;
    });

    const loginPromise = client
      .start({
        phoneNumber: async () => phoneNumber,
        phoneCode: async () => {
          this.status = 'awaiting_code';
          this.errorMessage = null;
          awaitingStepPromiseResolve?.();
          awaitingStepPromiseResolve = null;

          return new Promise<string>((resolve, reject) => {
            this.pending.resolveCode = resolve;
            this.pending.rejectCode = reject;
          });
        },
        password: async () => {
          this.status = 'awaiting_password';
          this.errorMessage = null;
          awaitingStepPromiseResolve?.();
          awaitingStepPromiseResolve = null;

          return new Promise<string>((resolve, reject) => {
            this.pending.resolvePassword = resolve;
            this.pending.rejectPassword = reject;
          });
        },
        onError: (err) => {
          this.errorMessage = err.message || 'Terjadi kesalahan saat otentikasi Telegram.';
          if (awaitingStepPromiseReject) {
            awaitingStepPromiseReject(err);
            awaitingStepPromiseReject = null;
          }
        },
      })
      .then(async () => {
        await this.finalizeConnectedClient(client, apiId, apiHash, phoneNumber);
        awaitingStepPromiseResolve?.();
        awaitingStepPromiseResolve = null;
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : 'Gagal masuk ke akun Telegram.';
        this.status = 'error';
        this.errorMessage = msg;
        awaitingStepPromiseReject?.(err instanceof Error ? err : new Error(msg));
        awaitingStepPromiseReject = null;
      });

    this.pending.loginPromise = loginPromise;

    // Wait until Telegram asks for OTP code, connects immediately, or errors out
    await Promise.race([
      firstTransition,
      sleep(15000).then(() => {
        if (this.status === 'connecting') {
          throw new Error('Koneksi ke server Telegram melewati batas waktu.');
        }
      }),
    ]);

    return this.getPublicAccount();
  }

  async submitOtpCode(code: string): Promise<TelegramAccountPublic> {
    if (this.status !== 'awaiting_code' || !this.pending.resolveCode) {
      throw new Error('Tidak ada permintaan kode OTP yang aktif.');
    }

    const resolver = this.pending.resolveCode;
    this.pending.resolveCode = undefined;
    this.pending.rejectCode = undefined;
    this.status = 'connecting';
    this.errorMessage = null;
    resolver(code.trim());

    // Wait briefly for either connected, awaiting_password, or error
    const deadline = Date.now() + 15000;
    while (this.status === 'connecting' && Date.now() < deadline) {
      await sleep(150);
    }

    return this.getPublicAccount();
  }

  async submitTwoFactorPassword(password: string): Promise<TelegramAccountPublic> {
    if (this.status !== 'awaiting_password' || !this.pending.resolvePassword) {
      throw new Error('Tidak ada permintaan kata sandi 2FA yang aktif.');
    }

    const resolver = this.pending.resolvePassword;
    this.pending.resolvePassword = undefined;
    this.pending.rejectPassword = undefined;
    this.status = 'connecting';
    this.errorMessage = null;
    resolver(password);

    const deadline = Date.now() + 15000;
    while (this.status === 'connecting' && Date.now() < deadline) {
      await sleep(150);
    }

    return this.getPublicAccount();
  }

  async connectClientWithSession(
    apiId: number,
    apiHash: string,
    sessionString: string
  ): Promise<TelegramAccountPublic> {
    await this.tearDownClient();

    const stringSession = new sessions.StringSession(sessionString.trim());
    const client = new TelegramClient(stringSession, apiId, apiHash, {
      connectionRetries: 50,
      retryDelay: 3000,
      autoReconnect: true,
    });

    this.client = client;
    this.status = 'connecting';
    this.errorMessage = null;

    try {
      await client.connect();
      const authorized = await client.isUserAuthorized();
      if (!authorized) {
        await client.disconnect();
        this.client = null;
        this.shouldStayConnected = false;
        this.stopWatchdog();
        this.status = 'error';
        this.errorMessage = 'StringSession tidak valid atau sudah kedaluwarsa.';
        return this.getPublicAccount();
      }

      await this.finalizeConnectedClient(client, apiId, apiHash);
      return this.getPublicAccount();
    } catch (err) {
      this.status = 'error';
      this.errorMessage =
        err instanceof Error ? err.message : 'Gagal terhubung menggunakan StringSession.';
      return this.getPublicAccount();
    }
  }

  async disconnectOnly(): Promise<TelegramAccountPublic> {
    this.shouldStayConnected = false;
    this.stopWatchdog();
    await this.tearDownClient();
    this.status = 'disconnected';
    this.errorMessage = null;
    return this.getPublicAccount();
  }

  async logoutAndClearSession(): Promise<TelegramAccountPublic> {
    this.shouldStayConnected = false;
    this.stopWatchdog();
    if (this.client) {
      try {
        await this.client.invoke(new Api.auth.LogOut());
      } catch {
        // Ignore network errors during logout
      }
    }
    await this.tearDownClient();

    const store = loadStore();
    store.credentials = {
      apiId: null,
      apiHash: null,
      sessionString: null,
      phoneMasked: null,
      firstName: null,
      lastName: null,
      username: null,
      telegramId: null,
      connectedAt: null,
    };
    saveStore(store);

    this.status = 'disconnected';
    this.errorMessage = null;
    return this.getPublicAccount();
  }
}

export const telegramManager = new TelegramUserbotManager();

registerTelegramSender({
  isReady: () => telegramManager.isReady(),
  sendDirectMessage: (chatId, text) => telegramManager.sendDirectMessage(chatId, text),
  sendPhotoWithCaption: (chatId, pngBuffer, caption) =>
    telegramManager.sendPhotoWithCaption(chatId, pngBuffer, caption),
});
