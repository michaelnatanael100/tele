import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DEFAULT_FALLBACK_REPLY_TEXT } from '../src/shared/autoReplyEngine';
import { SAMPLE_GOPAY_STATIC_QRIS } from '../src/shared/qris';
import type {
  AutoReplyRule,
  BotSettings,
  DashboardStats,
  GoPayMerchantConfig,
  GoPayMerchantPublicConfig,
  GoPayMutationEntry,
  MessageLogEntry,
  PaymentOrder,
  ProductAccountItem,
  ProductItem,
  TelegramAccountPublic,
  TelegramConnectionStatus,
} from '../src/shared/types';

export interface TelegramCredentialsStored {
  apiId: number | null;
  apiHash: string | null;
  sessionString: string | null;
  phoneMasked: string | null;
  firstName: string | null;
  lastName: string | null;
  username: string | null;
  telegramId: string | null;
  connectedAt: string | null;
}

export interface AdminAuthStored {
  pinHash: string | null;
  updatedAt: string | null;
}

export interface PersistedStore {
  rules: AutoReplyRule[];
  products: ProductItem[];
  settings: BotSettings;
  credentials: TelegramCredentialsStored;
  logs: MessageLogEntry[];
  adminAuth: AdminAuthStored;
  orders: PaymentOrder[];
  mutations: GoPayMutationEntry[];
  gopayConfig: GoPayMerchantConfig;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_FILE = path.resolve(DATA_DIR, 'store.json');

if (!STORE_FILE.startsWith(DATA_DIR + path.sep)) {
  throw new Error('Invalid store file path outside data directory.');
}

function createInitialGopayConfig(): GoPayMerchantConfig {
  return {
    enabled: true,
    merchantName: 'TOKO DIGITAL TELEBALAS',
    staticQris: SAMPLE_GOPAY_STATIC_QRIS,
    mutationApiUrl: '',
    apiToken: '',
    webhookSecret: crypto.randomBytes(20).toString('hex'),
    pollingEnabled: false,
    pollIntervalSeconds: 20,
    orderExpiryMinutes: 15,
    lastPolledAt: null,
    lastPollStatus: null,
  };
}

function normalizeProductAccounts(raw: unknown): ProductAccountItem[] {
  if (!Array.isArray(raw)) return [];
  const now = new Date().toISOString();
  const normalized: ProductAccountItem[] = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const rec = item as Record<string, unknown>;
    const email = typeof rec.email === 'string' ? rec.email.trim().slice(0, 160) : '';
    const password = typeof rec.password === 'string' ? rec.password.trim().slice(0, 160) : '';
    const extraData = typeof rec.extraData === 'string' ? rec.extraData.trim().slice(0, 1000) : '';
    if (!email && !extraData) continue;
    const status =
      rec.status === 'reserved' || rec.status === 'sold' ? rec.status : 'available';
    normalized.push({
      id:
        typeof rec.id === 'string' && rec.id.trim()
          ? rec.id.trim().slice(0, 64)
          : `acc_${crypto.randomUUID().slice(0, 8)}`,
      email,
      password,
      extraData,
      status,
      soldToOrderId: typeof rec.soldToOrderId === 'string' ? rec.soldToOrderId : null,
      soldAt: typeof rec.soldAt === 'string' ? rec.soldAt : null,
      createdAt: typeof rec.createdAt === 'string' ? rec.createdAt : now,
    });
  }
  return normalized.slice(0, 500);
}

function createInitialStore(): PersistedStore {
  const now = new Date().toISOString();
  return {
    rules: [
      {
        id: 'rule_sapaan',
        name: 'Sapaan Pembuka & Menu Bantuan',
        enabled: true,
        matchType: 'exact',
        pattern: 'halo, hai, p, assalamualaikum',
        caseSensitive: false,
        chatScope: 'private',
        replyText:
          'Halo {nama}, selamat datang! Ketik "harga" untuk melihat katalog produk (Netflix, Spotify, dll) atau ketik "order netflix" untuk langsung checkout QRIS GoPay otomatis.',
        quoteOriginal: false,
        delayMs: 800,
        cooldownSeconds: 120,
        priority: 1,
        hitCount: 14,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'rule_harga',
        name: 'Katalog Harga & Produk',
        enabled: true,
        matchType: 'contains',
        pattern: 'harga, tarif, biaya, pricelist, katalog, produk',
        caseSensitive: false,
        chatScope: 'private',
        replyText:
          'Halo {nama}, berikut daftar produk digital yang tersedia saat ini:\n\n{katalog}\n\nSebutkan nama produk (misal: "netflix") untuk detail atau ketik "order netflix" untuk bayar via QRIS GoPay.',
        quoteOriginal: true,
        delayMs: 900,
        cooldownSeconds: 60,
        priority: 2,
        hitCount: 9,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'rule_jadwal',
        name: 'Cek Jam Kerja & Respon',
        enabled: true,
        matchType: 'contains',
        pattern: 'jadwal, buka, online, sibuk, kapan',
        caseSensitive: false,
        chatScope: 'private',
        replyText:
          'Saat ini pukul {waktu} WIB ({tanggal}). Sistem order & verifikasi QRIS GoPay aktif otomatis 24 jam penuh.',
        quoteOriginal: false,
        delayMs: 700,
        cooldownSeconds: 180,
        priority: 3,
        hitCount: 5,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'rule_afk',
        name: 'Mode Sibuk / Balasan Semua Pesan',
        enabled: false,
        matchType: 'all_incoming',
        pattern: '',
        caseSensitive: false,
        chatScope: 'private',
        replyText:
          'Halo {nama}, saya sedang tidak berada di depan layar. Pesan "{pesan}" sudah diterima pada {waktu} WIB dan akan saya balas setelah kembali.',
        quoteOriginal: false,
        delayMs: 1200,
        cooldownSeconds: 300,
        priority: 99,
        hitCount: 2,
        createdAt: now,
        updatedAt: now,
      },
    ],
    products: [
      {
        id: 'prod_netflix',
        name: 'Netflix Premium 4K',
        category: 'Streaming Video',
        price: 35000,
        duration: '1 Bulan',
        stockStatus: 'tersedia',
        keywords: 'netflix, nf',
        description: 'Profil private 1P1U UHD 4K, support Smart TV/HP/Laptop, garansi penuh 30 hari.',
        replyTemplate:
          'Halo {nama}, detail produk *{produk}*:\n• Durasi: {durasi}\n• Harga: {harga}\n• Status: {stok}\n• Keterangan: {deskripsi}\n\nBalas "order netflix" untuk mendapatkan QRIS GoPay & kirim akun otomatis.',
        autoReplyEnabled: true,
        accounts: [
          {
            id: 'acc_nf_demo_1',
            email: 'demo.netflix1@contoh.id',
            password: 'NfDemo2026!',
            extraData: 'Profil: VIP 1 • PIN: 1122 • Garansi 30 Hari',
            status: 'available',
            soldToOrderId: null,
            soldAt: null,
            createdAt: now,
          },
          {
            id: 'acc_nf_demo_2',
            email: 'demo.netflix2@contoh.id',
            password: 'NfDemo2026@',
            extraData: 'Profil: VIP 2 • PIN: 3344 • Garansi 30 Hari',
            status: 'available',
            soldToOrderId: null,
            soldAt: null,
            createdAt: now,
          },
        ],
        hitCount: 12,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_spotify',
        name: 'Spotify Premium Individual',
        category: 'Streaming Musik',
        price: 25000,
        duration: '1 Bulan',
        stockStatus: 'tersedia',
        keywords: 'spotify, musik',
        description: 'Akun legal bebas iklan, siap pakai dan bergaransi penuh.',
        replyTemplate:
          'Halo {nama}, detail produk *{produk}*:\n• Durasi: {durasi}\n• Harga: {harga}\n• Status: {stok}\n• Keterangan: {deskripsi}\n\nBalas "order spotify" untuk pembayaran otomatis via QRIS GoPay.',
        autoReplyEnabled: true,
        accounts: [
          {
            id: 'acc_sp_demo_1',
            email: 'demo.spotify1@contoh.id',
            password: 'SpotDemo2026!',
            extraData: 'Plan Individual 1 Bulan • Region Indonesia',
            status: 'available',
            soldToOrderId: null,
            soldAt: null,
            createdAt: now,
          },
        ],
        hitCount: 8,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_canva',
        name: 'Canva Pro Education / Team',
        category: 'Desain & Produktivitas',
        price: 18000,
        duration: '1 Tahun',
        stockStatus: 'terbatas',
        keywords: 'canva, desain',
        description: 'Invite link / akun Pro siap pakai, akses semua aset Pro & Brand Kit.',
        replyTemplate:
          'Halo {nama}, detail produk *{produk}*:\n• Durasi: {durasi}\n• Harga: {harga}\n• Status: {stok}\n• Keterangan: {deskripsi}\n\nBalas "order canva" untuk checkout via QRIS GoPay.',
        autoReplyEnabled: true,
        accounts: [],
        hitCount: 4,
        createdAt: now,
        updatedAt: now,
      },
    ],
    settings: {
      botEnabled: true,
      defaultReplyEnabled: true,
      defaultReplyText: DEFAULT_FALLBACK_REPLY_TEXT,
      ignoreGroupsByDefault: true,
      ignoreContactsInWhitelistOnly: false,
      whitelist: [],
      blacklist: [],
      defaultCooldownSeconds: 60,
      typingIndicator: true,
      schedule: {
        enabled: false,
        startTime: '08:00',
        endTime: '21:00',
        timezoneOffsetMinutes: 420,
      },
    },
    credentials: {
      apiId: null,
      apiHash: null,
      sessionString: null,
      phoneMasked: null,
      firstName: null,
      lastName: null,
      username: null,
      telegramId: null,
      connectedAt: null,
    },
    logs: [
      {
        id: 'log_seed_1',
        timestamp: new Date(Date.now() - 42 * 60_000).toISOString(),
        senderId: 'sim_101',
        senderName: 'Raka Pratama',
        senderUsername: 'rakapratama',
        chatType: 'private',
        incomingText: 'Kak, Netflix 1 bulan ready?',
        matchedRuleId: 'prod_netflix',
        matchedRuleName: 'Produk: Netflix Premium 4K',
        replyText:
          'Halo Raka Pratama, detail produk *Netflix Premium 4K*:\n• Durasi: 1 Bulan\n• Harga: Rp 35.000\n• Status: Tersedia',
        outcome: 'simulated',
        reason: 'Cocok dengan produk "Netflix Premium 4K".',
      },
      {
        id: 'log_seed_2',
        timestamp: new Date(Date.now() - 18 * 60_000).toISOString(),
        senderId: 'sim_102',
        senderName: 'Nadia Putri',
        senderUsername: 'nadiaputri',
        chatType: 'group',
        incomingText: 'Ada yang jual Spotify?',
        matchedRuleId: null,
        matchedRuleName: null,
        replyText: null,
        outcome: 'skipped',
        reason: 'Pesan grup diabaikan sesuai pengaturan.',
      },
    ],
    adminAuth: {
      pinHash: null,
      updatedAt: null,
    },
    orders: [],
    mutations: [],
    gopayConfig: createInitialGopayConfig(),
  };
}

let cachedStore: PersistedStore | null = null;

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  }
}

export function loadStore(): PersistedStore {
  if (cachedStore) return cachedStore;

  ensureDataDir();
  if (fs.existsSync(STORE_FILE)) {
    try {
      const raw = fs.readFileSync(STORE_FILE, 'utf8');
      const parsed = JSON.parse(raw) as Partial<PersistedStore>;
      const base = createInitialStore();
      const rawProducts = Array.isArray(parsed.products) ? parsed.products : base.products;
      const products: ProductItem[] = rawProducts.map((p) => ({
        ...p,
        accounts: normalizeProductAccounts((p as Partial<ProductItem>).accounts),
      }));

      cachedStore = {
        rules: Array.isArray(parsed.rules) ? parsed.rules : base.rules,
        products,
        settings: parsed.settings
          ? {
              ...base.settings,
              ...parsed.settings,
              schedule: {
                ...base.settings.schedule,
                ...(parsed.settings.schedule ?? {}),
              },
            }
          : base.settings,
        credentials: parsed.credentials
          ? { ...base.credentials, ...parsed.credentials }
          : base.credentials,
        logs: Array.isArray(parsed.logs) ? parsed.logs : base.logs,
        adminAuth: parsed.adminAuth
          ? { ...base.adminAuth, ...parsed.adminAuth }
          : base.adminAuth,
        orders: Array.isArray(parsed.orders) ? parsed.orders : [],
        mutations: Array.isArray(parsed.mutations) ? parsed.mutations : [],
        gopayConfig: parsed.gopayConfig
          ? {
              ...base.gopayConfig,
              ...parsed.gopayConfig,
              webhookSecret:
                parsed.gopayConfig.webhookSecret || base.gopayConfig.webhookSecret,
            }
          : base.gopayConfig,
      };
      return cachedStore;
    } catch {
      cachedStore = createInitialStore();
      saveStore(cachedStore);
      return cachedStore;
    }
  }

  cachedStore = createInitialStore();
  saveStore(cachedStore);
  return cachedStore;
}

export function saveStore(store: PersistedStore): void {
  ensureDataDir();
  cachedStore = store;
  const tempFile = path.resolve(DATA_DIR, `store.${crypto.randomUUID()}.tmp`);
  if (!tempFile.startsWith(DATA_DIR + path.sep)) {
    throw new Error('Invalid temporary file path.');
  }
  fs.writeFileSync(tempFile, JSON.stringify(store, null, 2), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(tempFile, STORE_FILE);
}

export function maskSecretTail(secret: string | null | undefined, keepLast = 4): string | null {
  if (!secret || secret.length === 0) return null;
  if (secret.length <= keepLast) return '••••';
  return `••••••••${secret.slice(-keepLast)}`;
}

export function maskPhone(phone: string | null | undefined): string | null {
  if (!phone) return null;
  const cleaned = phone.trim();
  if (cleaned.length <= 5) return '•••••';
  return `${cleaned.slice(0, 4)}••••${cleaned.slice(-3)}`;
}

export function buildPublicAccount(
  status: TelegramConnectionStatus,
  errorMessage: string | null
): TelegramAccountPublic {
  const { credentials } = loadStore();
  return {
    status,
    apiId: credentials.apiId,
    apiHashMasked: maskSecretTail(credentials.apiHash, 4),
    hasSession: Boolean(credentials.sessionString),
    phoneMasked: credentials.phoneMasked,
    firstName: credentials.firstName,
    lastName: credentials.lastName,
    username: credentials.username,
    telegramId: credentials.telegramId,
    connectedAt: credentials.connectedAt,
    errorMessage,
  };
}

export function buildPublicGopayConfig(store: PersistedStore): GoPayMerchantPublicConfig {
  const cfg = store.gopayConfig;
  return {
    enabled: cfg.enabled,
    merchantName: cfg.merchantName,
    staticQris: cfg.staticQris,
    mutationApiUrl: cfg.mutationApiUrl,
    hasApiToken: Boolean(cfg.apiToken),
    apiTokenMasked: maskSecretTail(cfg.apiToken, 4),
    hasWebhookSecret: Boolean(cfg.webhookSecret),
    webhookSecretMasked: maskSecretTail(cfg.webhookSecret, 4),
    pollingEnabled: cfg.pollingEnabled,
    pollIntervalSeconds: cfg.pollIntervalSeconds,
    orderExpiryMinutes: cfg.orderExpiryMinutes,
    lastPolledAt: cfg.lastPolledAt,
    lastPollStatus: cfg.lastPollStatus,
  };
}

export function computeStats(store: PersistedStore): DashboardStats {
  let totalReplied = 0;
  let totalSkipped = 0;
  let totalSimulated = 0;

  for (const entry of store.logs) {
    if (entry.outcome === 'replied') totalReplied += 1;
    else if (entry.outcome === 'skipped') totalSkipped += 1;
    else if (entry.outcome === 'simulated') totalSimulated += 1;
  }

  let pendingOrdersCount = 0;
  let paidOrdersCount = 0;
  let totalRevenue = 0;
  for (const ord of store.orders) {
    if (ord.status === 'pending') pendingOrdersCount += 1;
    if (ord.status === 'paid' || ord.status === 'delivered') {
      paidOrdersCount += 1;
      totalRevenue += ord.totalAmount;
    }
  }

  let availableAccountStockCount = 0;
  for (const p of store.products) {
    for (const acc of p.accounts ?? []) {
      if (acc.status === 'available') availableAccountStockCount += 1;
    }
  }

  return {
    totalReplied,
    totalSkipped,
    totalSimulated,
    activeRuleCount: store.rules.filter((r) => r.enabled).length,
    totalRuleCount: store.rules.length,
    activeProductCount: store.products.filter((p) => p.autoReplyEnabled).length,
    totalProductCount: store.products.length,
    pendingOrdersCount,
    paidOrdersCount,
    totalRevenue,
    availableAccountStockCount,
  };
}

export function appendLog(entry: Omit<MessageLogEntry, 'id' | 'timestamp'>): MessageLogEntry {
  const store = loadStore();
  const fullEntry: MessageLogEntry = {
    ...entry,
    id: `log_${crypto.randomUUID().slice(0, 8)}`,
    timestamp: new Date().toISOString(),
  };
  store.logs = [fullEntry, ...store.logs].slice(0, 200);
  saveStore(store);
  return fullEntry;
}
