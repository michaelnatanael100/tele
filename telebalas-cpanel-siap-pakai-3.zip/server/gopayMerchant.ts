import crypto from 'node:crypto';
import net from 'node:net';
import QRCode from 'qrcode';
import {
  formatAccountDeliveryMessage,
  formatRupiah,
  getAvailableAccountCount,
} from '../src/shared/autoReplyEngine';
import {
  extractMerchantNameFromQris,
  generateDynamicQris,
  parseGoPayNotificationAmount,
  validateStaticQris,
} from '../src/shared/qris';
import type {
  GoPayMutationEntry,
  PaymentOrder,
  ProductAccountItem,
  ProductItem,
} from '../src/shared/types';
import { appendLog, loadStore, saveStore, type PersistedStore } from './store';

export interface TelegramSenderBridge {
  isReady: () => boolean;
  sendDirectMessage: (chatId: string, text: string) => Promise<void>;
  sendPhotoWithCaption: (chatId: string, pngBuffer: Buffer, caption: string) => Promise<void>;
}

let telegramSender: TelegramSenderBridge | null = null;
let watchdogTimer: ReturnType<typeof setInterval> | null = null;
let pollInFlight = false;

export function registerTelegramSender(bridge: TelegramSenderBridge): void {
  telegramSender = bridge;
}

export function validateMutationApiUrl(rawUrl: string): { valid: boolean; error?: string } {
  const clean = rawUrl.trim();
  if (!clean) return { valid: true };

  let parsed: URL;
  try {
    parsed = new URL(clean);
  } catch {
    return { valid: false, error: 'Format URL Endpoint Mutasi GoPay tidak valid.' };
  }

  if (parsed.protocol !== 'https:') {
    return {
      valid: false,
      error: 'URL Endpoint Mutasi GoPay wajib menggunakan protokol HTTPS yang aman.',
    };
  }

  if (parsed.username || parsed.password) {
    return { valid: false, error: 'URL tidak boleh menyertakan kredensial username/password.' };
  }

  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host.endsWith('.internal')
  ) {
    return { valid: false, error: 'Host lokal/internal tidak diizinkan untuk polling API.' };
  }

  const ipVersion = net.isIP(host);
  if (ipVersion === 4) {
    const parts = host.split('.').map(Number);
    const [a, b] = parts;
    if (
      a === 10 ||
      a === 127 ||
      a === 0 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127)
    ) {
      return { valid: false, error: 'Alamat IP privat/loopback tidak diizinkan.' };
    }
  } else if (ipVersion === 6) {
    const cleanV6 = host.replace(/^\[|\]$/g, '').toLowerCase();
    if (
      cleanV6 === '::1' ||
      cleanV6 === '::' ||
      cleanV6.startsWith('fc') ||
      cleanV6.startsWith('fd') ||
      cleanV6.startsWith('fe80:')
    ) {
      return { valid: false, error: 'Alamat IPv6 privat/loopback tidak diizinkan.' };
    }
  }

  return { valid: true };
}

function releaseAccountReservation(product: ProductItem | undefined, accountId: string | null): void {
  if (!product || !accountId) return;
  const acc = product.accounts?.find((a) => a.id === accountId);
  if (acc && acc.status === 'reserved') {
    acc.status = 'available';
    acc.soldToOrderId = null;
    acc.soldAt = null;
  }
}

export function expireStaleOrders(store: PersistedStore = loadStore()): number {
  const nowMs = Date.now();
  let changed = 0;

  for (const order of store.orders) {
    if (order.status !== 'pending') continue;
    const expMs = Date.parse(order.expiresAt);
    if (Number.isFinite(expMs) && nowMs > expMs) {
      order.status = 'expired';
      const product = store.products.find((p) => p.id === order.productId);
      releaseAccountReservation(product, order.reservedAccountId);
      changed += 1;
    }
  }

  if (changed > 0) {
    saveStore(store);
  }
  return changed;
}

function allocateUniqueAmount(store: PersistedStore, basePrice: number): {
  uniqueCode: number;
  totalAmount: number;
} {
  const activeAmounts = new Set(
    store.orders.filter((o) => o.status === 'pending').map((o) => o.totalAmount)
  );
  const startOffset = crypto.randomInt(1, 500);
  for (let i = 0; i < 499; i++) {
    const code = ((startOffset + i - 1) % 499) + 1;
    const candidate = basePrice + code;
    if (!activeAmounts.has(candidate)) {
      return { uniqueCode: code, totalAmount: candidate };
    }
  }
  for (let code = 500; code <= 999; code++) {
    const candidate = basePrice + code;
    if (!activeAmounts.has(candidate)) {
      return { uniqueCode: code, totalAmount: candidate };
    }
  }
  throw new Error('Antrean nominal unik sedang penuh. Coba beberapa saat lagi.');
}

export function formatQrisInvoiceCaption(order: PaymentOrder, merchantName: string): string {
  const expiryDate = new Date(order.expiresAt);
  const wibMs = expiryDate.getTime() + 420 * 60_000;
  const d = new Date(wibMs);
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const mm = String(d.getUTCMinutes()).padStart(2, '0');

  return [
    `🧾 *INVOICE QRIS GOPAY MERCHANT*`,
    `Merchant: *${merchantName}*`,
    `Kode Order: \`${order.orderCode}\``,
    `Produk: *${order.productName}*`,
    ``,
    `💰 *Nominal Transfer WAJIB PERSIS:*`,
    `*${formatRupiah(order.totalAmount)}*`,
    `_(Harga ${formatRupiah(order.basePrice)} + Kode Unik ${order.uniqueCode})_`,
    ``,
    `Scan QRIS di atas via *GoPay / Dana / OVO / ShopeePay / BCA / Mobile Banking*.`,
    `⚠️ Pastikan transfer nominal persis sampai 3 digit terakhir agar terbaca otomatis oleh sistem mutasi GoPay.`,
    `⏱ Berlaku sampai pukul ${hh}:${mm} WIB. Akun langsung dikirim ke chat ini begitu pembayaran masuk!`,
  ].join('\n');
}

export async function createQrisOrder(params: {
  productId: string;
  buyerChatId: string;
  buyerSenderId: string;
  buyerName: string;
  buyerUsername?: string | null;
  source: 'telegram' | 'simulator';
}): Promise<{
  ok: boolean;
  error?: string;
  order?: PaymentOrder;
  qrPngBuffer?: Buffer;
  qrDataUrl?: string;
  invoiceCaption?: string;
}> {
  const store = loadStore();
  expireStaleOrders(store);

  if (!store.gopayConfig.enabled) {
    return {
      ok: false,
      error: 'Integrasi pembayaran QRIS GoPay Merchant sedang dinonaktifkan admin.',
    };
  }

  const staticCheck = validateStaticQris(store.gopayConfig.staticQris);
  if (!staticCheck.valid) {
    return {
      ok: false,
      error: staticCheck.error || 'String QRIS Statis GoPay Merchant belum dikonfigurasi dengan valid.',
    };
  }

  const product = store.products.find((p) => p.id === params.productId);
  if (!product) {
    return { ok: false, error: 'Produk tidak ditemukan.' };
  }

  if (product.price <= 0) {
    return { ok: false, error: `Produk "${product.name}" belum memiliki harga di atas Rp 0.` };
  }

  const availableAcc: ProductAccountItem | undefined = (product.accounts ?? []).find(
    (a) => a.status === 'available'
  );
  if (product.stockStatus === 'habis' || !availableAcc) {
    return {
      ok: false,
      error: `Maaf, stok detail akun untuk *${product.name}* sedang habis. Hubungi admin untuk isi ulang stok.`,
    };
  }

  const { uniqueCode, totalAmount } = allocateUniqueAmount(store, Math.round(product.price));
  const dynamicQris = generateDynamicQris(store.gopayConfig.staticQris, totalAmount);

  const qrPngBuffer = await QRCode.toBuffer(dynamicQris, {
    type: 'png',
    width: 420,
    margin: 2,
    errorCorrectionLevel: 'M',
  });
  const qrDataUrl = `data:image/png;base64,${qrPngBuffer.toString('base64')}`;

  const now = new Date();
  const expiryMinutes = Math.max(3, Math.min(180, store.gopayConfig.orderExpiryMinutes || 15));
  const expiresAt = new Date(now.getTime() + expiryMinutes * 60_000).toISOString();
  const orderId = `ord_${crypto.randomUUID().slice(0, 8)}`;
  const orderCode = `GP-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;

  availableAcc.status = 'reserved';
  availableAcc.soldToOrderId = orderId;

  const order: PaymentOrder = {
    id: orderId,
    orderCode,
    productId: product.id,
    productName: product.name,
    basePrice: Math.round(product.price),
    uniqueCode,
    totalAmount,
    buyerChatId: params.buyerChatId,
    buyerSenderId: params.buyerSenderId,
    buyerName: params.buyerName || 'Pembeli',
    buyerUsername: params.buyerUsername ?? null,
    source: params.source,
    qrisPayload: dynamicQris,
    status: 'pending',
    reservedAccountId: availableAcc.id,
    deliveredAccount: null,
    deliveryPending: false,
    deliveryError: null,
    mutationRef: null,
    paidVia: null,
    createdAt: now.toISOString(),
    expiresAt,
    paidAt: null,
    deliveredAt: null,
  };

  store.orders = [order, ...store.orders].slice(0, 250);
  saveStore(store);

  const merchantName =
    store.gopayConfig.merchantName.trim() ||
    extractMerchantNameFromQris(store.gopayConfig.staticQris) ||
    'GOPAY MERCHANT';

  return {
    ok: true,
    order,
    qrPngBuffer,
    qrDataUrl,
    invoiceCaption: formatQrisInvoiceCaption(order, merchantName),
  };
}

async function deliverPaidOrder(order: PaymentOrder): Promise<void> {
  const deliveryText = formatAccountDeliveryMessage({
    buyerName: order.buyerName,
    order,
    account: order.deliveredAccount,
  });

  const store = loadStore();
  const storedOrder = store.orders.find((o) => o.id === order.id);
  if (!storedOrder) return;

  if (storedOrder.source === 'simulator') {
    storedOrder.status = 'delivered';
    storedOrder.deliveredAt = new Date().toISOString();
    storedOrder.deliveryPending = false;
    storedOrder.deliveryError = null;
    saveStore(store);

    appendLog({
      senderId: storedOrder.buyerSenderId,
      senderName: storedOrder.buyerName,
      senderUsername: storedOrder.buyerUsername,
      chatType: 'private',
      incomingText: `[Mutasi QRIS GoPay ${formatRupiah(storedOrder.totalAmount)}]`,
      matchedRuleId: storedOrder.productId,
      matchedRuleName: `QRIS Auto-Delivery: ${storedOrder.productName}`,
      replyText: deliveryText.slice(0, 500),
      outcome: 'simulated',
      reason: `Pembayaran ${storedOrder.orderCode} terbaca (${storedOrder.paidVia ?? 'GoPay'}) & akun terkirim.`,
    });
    return;
  }

  if (!telegramSender || !telegramSender.isReady()) {
    storedOrder.deliveryPending = true;
    storedOrder.deliveryError = 'Koneksi Telegram belum aktif; akan dikirim otomatis saat tersambung.';
    saveStore(store);
    return;
  }

  try {
    await telegramSender.sendDirectMessage(storedOrder.buyerChatId, deliveryText);
    storedOrder.status = 'delivered';
    storedOrder.deliveredAt = new Date().toISOString();
    storedOrder.deliveryPending = false;
    storedOrder.deliveryError = null;
    saveStore(store);

    appendLog({
      senderId: storedOrder.buyerSenderId,
      senderName: storedOrder.buyerName,
      senderUsername: storedOrder.buyerUsername,
      chatType: 'private',
      incomingText: `[Mutasi GoPay ${formatRupiah(storedOrder.totalAmount)}]`,
      matchedRuleId: storedOrder.productId,
      matchedRuleName: `QRIS Auto-Delivery: ${storedOrder.productName}`,
      replyText: deliveryText.slice(0, 500),
      outcome: 'replied',
      reason: `Pembayaran ${storedOrder.orderCode} otomatis terverifikasi via mutasi GoPay & detail akun terkirim.`,
    });
  } catch (err) {
    storedOrder.deliveryPending = true;
    storedOrder.deliveryError =
      err instanceof Error ? err.message : 'Gagal mengirim detail akun ke Telegram pembeli.';
    saveStore(store);
  }
}

export async function processIncomingMutation(params: {
  amount: number;
  mutationRef?: string;
  source: 'api_poll' | 'webhook' | 'simulation';
  senderName?: string | null;
  rawSummary: string;
}): Promise<{
  matched: boolean;
  duplicate: boolean;
  mutation: GoPayMutationEntry;
  order?: PaymentOrder;
}> {
  const cleanAmount = Math.round(params.amount);
  const store = loadStore();
  expireStaleOrders(store);

  const cleanRef =
    params.mutationRef?.trim().slice(0, 120) ||
    `MUT-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

  if (params.mutationRef?.trim()) {
    const existingMut = store.mutations.find((m) => m.mutationRef === cleanRef);
    if (existingMut) {
      return { matched: Boolean(existingMut.matchedOrderCode), duplicate: true, mutation: existingMut };
    }
  }

  const matchedOrder = store.orders.find(
    (o) => o.status === 'pending' && o.totalAmount === cleanAmount
  );

  const nowIso = new Date().toISOString();
  const mutationEntry: GoPayMutationEntry = {
    id: `mut_${crypto.randomUUID().slice(0, 8)}`,
    mutationRef: cleanRef,
    amount: cleanAmount,
    source: params.source,
    senderName: params.senderName?.trim() || null,
    matchedOrderCode: matchedOrder?.orderCode ?? null,
    rawSummary: params.rawSummary.slice(0, 300),
    receivedAt: nowIso,
  };

  store.mutations = [mutationEntry, ...store.mutations].slice(0, 200);

  if (matchedOrder) {
    matchedOrder.status = 'paid';
    matchedOrder.paidAt = nowIso;
    matchedOrder.mutationRef = cleanRef;
    matchedOrder.paidVia =
      params.source === 'api_poll'
        ? 'GoPay Merchant API'
        : params.source === 'webhook'
          ? 'Webhook Notifikasi GoPay'
          : 'Simulasi Mutasi';

    const product = store.products.find((p) => p.id === matchedOrder.productId);
    if (product) {
      const account =
        (matchedOrder.reservedAccountId &&
          product.accounts?.find((a) => a.id === matchedOrder.reservedAccountId)) ||
        product.accounts?.find((a) => a.status === 'available');

      if (account) {
        account.status = 'sold';
        account.soldToOrderId = matchedOrder.id;
        account.soldAt = nowIso;
        matchedOrder.deliveredAccount = {
          email: account.email,
          password: account.password,
          extraData: account.extraData,
        };
      }

      product.hitCount += 1;
      product.updatedAt = nowIso;
      if (getAvailableAccountCount(product) === 0) {
        product.stockStatus = 'habis';
      }
    }
  }

  saveStore(store);

  if (matchedOrder) {
    await deliverPaidOrder(matchedOrder);
    const refreshed = loadStore().orders.find((o) => o.id === matchedOrder.id) ?? matchedOrder;
    return {
      matched: true,
      duplicate: false,
      mutation: mutationEntry,
      order: refreshed,
    };
  }

  return {
    matched: false,
    duplicate: false,
    mutation: mutationEntry,
  };
}

export async function retryOrderDelivery(orderId: string): Promise<{
  ok: boolean;
  error?: string;
  order?: PaymentOrder;
}> {
  const store = loadStore();
  const order = store.orders.find((o) => o.id === orderId);
  if (!order) {
    return { ok: false, error: 'Order tidak ditemukan.' };
  }
  if (order.status !== 'paid' && order.status !== 'delivered') {
    return { ok: false, error: 'Order belum berstatus lunas.' };
  }
  await deliverPaidOrder(order);
  const updated = loadStore().orders.find((o) => o.id === orderId);
  return { ok: true, order: updated };
}

export async function retryPendingDeliveries(): Promise<void> {
  const store = loadStore();
  const pending = store.orders.filter(
    (o) => o.status === 'paid' && o.deliveryPending && o.source === 'telegram'
  );
  for (const ord of pending) {
    await deliverPaidOrder(ord);
  }
}

export function cancelOrder(orderId: string): {
  ok: boolean;
  error?: string;
  order?: PaymentOrder;
} {
  const store = loadStore();
  const order = store.orders.find((o) => o.id === orderId);
  if (!order) {
    return { ok: false, error: 'Order tidak ditemukan.' };
  }
  if (order.status !== 'pending') {
    return { ok: false, error: 'Hanya order berstatus Menunggu yang dapat dibatalkan.' };
  }
  order.status = 'cancelled';
  const product = store.products.find((p) => p.id === order.productId);
  releaseAccountReservation(product, order.reservedAccountId);
  saveStore(store);
  return { ok: true, order };
}

function extractAmountFromApiItem(rec: Record<string, unknown>): number | null {
  const typeVal = String(rec.type ?? rec.mutation_type ?? rec.direction ?? '').toLowerCase();
  if (typeVal === 'db' || typeVal === 'debit' || typeVal === 'out' || typeVal === 'expense') {
    return null;
  }

  const candidateFields = [
    rec.amount,
    rec.nominal,
    rec.credit,
    rec.gross_amount,
    rec.total,
    rec.value,
  ];
  for (const raw of candidateFields) {
    if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) {
      return Math.round(raw);
    }
    if (typeof raw === 'string' && raw.trim()) {
      const parsedFromStr = parseGoPayNotificationAmount(`Rp ${raw.trim()}`);
      if (parsedFromStr) return parsedFromStr;
    }
  }

  const textField = rec.text ?? rec.message ?? rec.notification ?? rec.description ?? rec.title;
  if (typeof textField === 'string' && textField.trim()) {
    return parseGoPayNotificationAmount(textField);
  }
  return null;
}

export async function pollGoPayMerchantMutations(): Promise<{
  ok: boolean;
  statusMessage: string;
  processedCount: number;
  matchedCount: number;
}> {
  if (pollInFlight) {
    return {
      ok: true,
      statusMessage: 'Pengecekan mutasi sedang berjalan.',
      processedCount: 0,
      matchedCount: 0,
    };
  }

  const store = loadStore();
  expireStaleOrders(store);
  const url = store.gopayConfig.mutationApiUrl.trim();
  if (!url) {
    return {
      ok: false,
      statusMessage: 'URL Endpoint Mutasi GoPay belum diisi.',
      processedCount: 0,
      matchedCount: 0,
    };
  }

  const urlCheck = validateMutationApiUrl(url);
  if (!urlCheck.valid) {
    store.gopayConfig.lastPolledAt = new Date().toISOString();
    store.gopayConfig.lastPollStatus = urlCheck.error ?? 'URL tidak valid.';
    saveStore(store);
    return {
      ok: false,
      statusMessage: urlCheck.error ?? 'URL tidak valid.',
      processedCount: 0,
      matchedCount: 0,
    };
  }

  pollInFlight = true;
  try {
    const headers: Record<string, string> = {
      Accept: 'application/json',
    };
    if (store.gopayConfig.apiToken) {
      headers.Authorization = `Bearer ${store.gopayConfig.apiToken}`;
    }

    const res = await fetch(url, {
      method: 'GET',
      headers,
      redirect: 'error',
      signal: AbortSignal.timeout(8000),
    });

    if (!res.ok) {
      const msg = `Endpoint Mutasi merespons HTTP ${res.status}`;
      store.gopayConfig.lastPolledAt = new Date().toISOString();
      store.gopayConfig.lastPollStatus = msg;
      saveStore(store);
      return { ok: false, statusMessage: msg, processedCount: 0, matchedCount: 0 };
    }

    const payload = (await res.json()) as unknown;
    let items: unknown[] = [];
    if (Array.isArray(payload)) {
      items = payload;
    } else if (payload && typeof payload === 'object') {
      const obj = payload as Record<string, unknown>;
      const nested =
        obj.data ?? obj.mutations ?? obj.transactions ?? obj.records ?? obj.results ?? obj.items;
      if (Array.isArray(nested)) {
        items = nested;
      } else if (nested && typeof nested === 'object') {
        const inner = (nested as Record<string, unknown>).mutations ??
          (nested as Record<string, unknown>).transactions ??
          (nested as Record<string, unknown>).hits;
        if (Array.isArray(inner)) items = inner;
      }
    }

    let processedCount = 0;
    let matchedCount = 0;

    for (const rawItem of items.slice(0, 50)) {
      if (!rawItem || typeof rawItem !== 'object') continue;
      const rec = rawItem as Record<string, unknown>;
      const amount = extractAmountFromApiItem(rec);
      if (!amount) continue;

      const refCandidate =
        rec.mutation_id ?? rec.transaction_id ?? rec.reference_id ?? rec.order_id ?? rec.id;
      const mutationRef = refCandidate ? String(refCandidate) : undefined;
      const senderName =
        typeof rec.sender_name === 'string'
          ? rec.sender_name
          : typeof rec.customer_name === 'string'
            ? rec.customer_name
            : typeof rec.buyer_name === 'string'
              ? rec.buyer_name
              : null;
      const summary =
        typeof rec.description === 'string'
          ? rec.description
          : typeof rec.note === 'string'
            ? rec.note
            : `Mutasi masuk ${formatRupiah(amount)}`;

      const outcome = await processIncomingMutation({
        amount,
        mutationRef,
        source: 'api_poll',
        senderName,
        rawSummary: summary,
      });

      if (!outcome.duplicate) {
        processedCount += 1;
        if (outcome.matched) matchedCount += 1;
      }
    }

    const nowIso = new Date().toISOString();
    const fresh = loadStore();
    fresh.gopayConfig.lastPolledAt = nowIso;
    fresh.gopayConfig.lastPollStatus = `Terhubung OK · ${processedCount} mutasi baru (${matchedCount} order cocok)`;
    saveStore(fresh);

    return {
      ok: true,
      statusMessage: fresh.gopayConfig.lastPollStatus,
      processedCount,
      matchedCount,
    };
  } catch (err) {
    const msg =
      err instanceof Error ? `Gagal polling API mutasi: ${err.message}` : 'Gagal polling API mutasi.';
    const fresh = loadStore();
    fresh.gopayConfig.lastPolledAt = new Date().toISOString();
    fresh.gopayConfig.lastPollStatus = msg;
    saveStore(fresh);
    return { ok: false, statusMessage: msg, processedCount: 0, matchedCount: 0 };
  } finally {
    pollInFlight = false;
  }
}

export function startPaymentWatchdog(): void {
  if (watchdogTimer) return;
  watchdogTimer = setInterval(() => {
    const store = loadStore();
    expireStaleOrders(store);

    const hasPending = store.orders.some((o) => o.status === 'pending');
    if (
      store.gopayConfig.enabled &&
      store.gopayConfig.pollingEnabled &&
      store.gopayConfig.mutationApiUrl.trim() &&
      hasPending
    ) {
      const intervalMs = Math.max(10, store.gopayConfig.pollIntervalSeconds || 20) * 1000;
      const lastMs = store.gopayConfig.lastPolledAt
        ? Date.parse(store.gopayConfig.lastPolledAt)
        : 0;
      if (Date.now() - lastMs >= intervalMs) {
        void pollGoPayMerchantMutations();
      }
    }
  }, 15_000);

  if (typeof watchdogTimer.unref === 'function') {
    watchdogTimer.unref();
  }
}
