import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { AdminAuthStatus } from '../src/shared/types';
import { loadStore, saveStore } from './store';

const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours
const MAX_LOGIN_FAILURES = 5;
const LOCKOUT_WINDOW_MS = 5 * 60 * 1000; // 5 minutes

// Read signing secret from env with in-memory random fallback (never written to disk)
const SESSION_SECRET =
  process.env.ADMIN_SESSION_SECRET && process.env.ADMIN_SESSION_SECRET.trim().length >= 16
    ? process.env.ADMIN_SESSION_SECRET.trim()
    : crypto.randomBytes(32).toString('hex');

const revokedTokens = new Map<string, number>(); // jti -> expiresAt
const failedLoginAttempts = new Map<string, { count: number; firstAttemptMs: number }>();

export function validatePinFormat(pin: string): string | null {
  if (typeof pin !== 'string' || !/^\d{4,8}$/.test(pin)) {
    return 'PIN harus terdiri dari 4 hingga 8 digit angka.';
  }
  return null;
}

export function hashPinScrypt(pin: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(pin, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPinScrypt(pin: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, hashHex] = parts;
  if (!salt || !hashHex) return false;
  try {
    const expected = Buffer.from(hashHex, 'hex');
    const actual = crypto.scryptSync(pin, salt, 64);
    if (expected.length !== actual.length) return false;
    return crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export function verifyPinAgainstEnv(pin: string, envPin: string): boolean {
  const a = crypto.createHash('sha256').update(pin, 'utf8').digest();
  const b = crypto.createHash('sha256').update(envPin, 'utf8').digest();
  return crypto.timingSafeEqual(a, b);
}

export function issueSessionToken(
  secret: string = SESSION_SECRET,
  ttlMs: number = SESSION_TTL_MS
): { token: string; expiresAt: number; jti: string } {
  const now = Date.now();
  const expiresAt = now + ttlMs;
  const jti = crypto.randomUUID();
  const payload = Buffer.from(JSON.stringify({ jti, iat: now, exp: expiresAt }), 'utf8').toString(
    'base64url'
  );
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return { token: `${payload}.${sig}`, expiresAt, jti };
}

export function verifySessionToken(
  token: string,
  secret: string = SESSION_SECRET,
  revoked: Map<string, number> = revokedTokens,
  nowMs: number = Date.now()
): { valid: boolean; jti?: string; expiresAt?: number } {
  if (!token || typeof token !== 'string') return { valid: false };
  const parts = token.split('.');
  if (parts.length !== 2) return { valid: false };
  const [payloadB64, sigB64] = parts;
  if (!payloadB64 || !sigB64) return { valid: false };

  const expectedSig = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
  const sigBuf = Buffer.from(sigB64, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return { valid: false };
  }

  try {
    const decoded = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as {
      jti?: string;
      exp?: number;
    };
    if (!decoded.jti || typeof decoded.exp !== 'number') return { valid: false };
    if (decoded.exp <= nowMs) return { valid: false };
    if (revoked.has(decoded.jti)) return { valid: false };
    return { valid: true, jti: decoded.jti, expiresAt: decoded.exp };
  } catch {
    return { valid: false };
  }
}

export function getEnvPin(): string | null {
  const val = process.env.ADMIN_PIN?.trim();
  return val && val.length > 0 ? val : null;
}

export function getAuthStatus(authenticated: boolean): AdminAuthStatus {
  const envPin = getEnvPin();
  const store = loadStore();
  const hasStoredHash = Boolean(store.adminAuth?.pinHash);
  return {
    authenticated,
    needsSetup: !envPin && !hasStoredHash,
    managedByEnv: Boolean(envPin),
    pinUpdatedAt: envPin ? null : (store.adminAuth?.updatedAt ?? null),
  };
}

export function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header || typeof header !== 'string') return null;
  if (!header.startsWith('Bearer ')) return null;
  return header.slice(7).trim() || null;
}

export function requireAdminAuth(req: Request, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  const check = token ? verifySessionToken(token) : { valid: false };
  if (!check.valid) {
    res.status(401).json({ error: 'Sesi admin tidak valid atau sudah berakhir. Silakan login PIN.' });
    return;
  }
  next();
}

export function revokeBearerToken(req: Request): void {
  const token = extractBearerToken(req);
  if (!token) return;
  const check = verifySessionToken(token);
  if (check.valid && check.jti && check.expiresAt) {
    revokedTokens.set(check.jti, check.expiresAt);
    // Prune expired entries
    const now = Date.now();
    for (const [key, exp] of revokedTokens.entries()) {
      if (exp <= now) revokedTokens.delete(key);
    }
  }
}

function getClientKey(req: Request): string {
  return req.ip || req.socket.remoteAddress || 'unknown';
}

export function checkLoginRateLimit(req: Request): { blocked: boolean; retryAfterSec: number } {
  const key = getClientKey(req);
  const rec = failedLoginAttempts.get(key);
  if (!rec) return { blocked: false, retryAfterSec: 0 };

  const elapsed = Date.now() - rec.firstAttemptMs;
  if (elapsed >= LOCKOUT_WINDOW_MS) {
    failedLoginAttempts.delete(key);
    return { blocked: false, retryAfterSec: 0 };
  }

  if (rec.count >= MAX_LOGIN_FAILURES) {
    return {
      blocked: true,
      retryAfterSec: Math.max(1, Math.ceil((LOCKOUT_WINDOW_MS - elapsed) / 1000)),
    };
  }
  return { blocked: false, retryAfterSec: 0 };
}

export function recordLoginFailure(req: Request): void {
  const key = getClientKey(req);
  const now = Date.now();
  const rec = failedLoginAttempts.get(key);
  if (!rec || now - rec.firstAttemptMs >= LOCKOUT_WINDOW_MS) {
    failedLoginAttempts.set(key, { count: 1, firstAttemptMs: now });
  } else {
    rec.count += 1;
  }
}

export function clearLoginFailures(req: Request): void {
  failedLoginAttempts.delete(getClientKey(req));
}

export function verifyAdminPin(pin: string): boolean {
  const envPin = getEnvPin();
  if (envPin) {
    return verifyPinAgainstEnv(pin, envPin);
  }
  const store = loadStore();
  if (!store.adminAuth?.pinHash) return false;
  return verifyPinScrypt(pin, store.adminAuth.pinHash);
}

export function claimInitialPin(pin: string): { ok: boolean; error?: string } {
  const envPin = getEnvPin();
  if (envPin) {
    return { ok: false, error: 'PIN admin sudah dikonfigurasi melalui environment server.' };
  }

  const store = loadStore();
  if (store.adminAuth?.pinHash) {
    return { ok: false, error: 'PIN admin sudah pernah dibuat sebelumnya.' };
  }

  const formatErr = validatePinFormat(pin);
  if (formatErr) {
    return { ok: false, error: formatErr };
  }

  store.adminAuth = {
    pinHash: hashPinScrypt(pin),
    updatedAt: new Date().toISOString(),
  };
  saveStore(store);
  return { ok: true };
}

export function updateAdminPin(
  currentPin: string,
  newPin: string
): { ok: boolean; error?: string } {
  const envPin = getEnvPin();
  if (envPin) {
    return {
      ok: false,
      error: 'PIN dikelola melalui secret environment server (ADMIN_PIN) dan tidak dapat diubah di UI.',
    };
  }

  if (!verifyAdminPin(currentPin)) {
    return { ok: false, error: 'PIN saat ini salah.' };
  }

  const formatErr = validatePinFormat(newPin);
  if (formatErr) {
    return { ok: false, error: formatErr };
  }

  const store = loadStore();
  store.adminAuth = {
    pinHash: hashPinScrypt(newPin),
    updatedAt: new Date().toISOString(),
  };
  saveStore(store);
  return { ok: true };
}
