<?php
/**
 * TeleBalas - Web Installer cPanel Shared Hosting (Tanpa SSH / Terminal)
 * ----------------------------------------------------------------------
 * Unggah file install.php ini bersama telebalas-cpanel-siap-pakai.zip
 * ke folder aplikasi cPanel Anda, lalu buka: https://domain-anda.com/install.php
 */
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

$baseDir = __DIR__;
$lockFile = $baseDir . '/.install.lock';
$defaultZip = 'telebalas-cpanel-siap-pakai.zip';

function h(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function detectSiteUrl(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'domain-anda.com';
    $host = preg_replace('/[^a-zA-Z0-9.:\-]/', '', (string)$host);
    return $scheme . '://' . ($host ?: 'domain-anda.com');
}

function isSafeZipEntry(string $name): bool {
    if ($name === '' || strpos($name, "\0") !== false) return false;
    if ($name[0] === '/' || $name[0] === '\\') return false;
    if (preg_match('/^[a-zA-Z]:/', $name)) return false;
    $normalized = str_replace('\\', '/', $name);
    $parts = explode('/', $normalized);
    foreach ($parts as $part) {
        if ($part === '..') return false;
    }
    return true;
}

function readLockData(string $lockFile): ?array {
    if (!is_file($lockFile)) return null;
    $raw = @file_get_contents($lockFile);
    if ($raw === false) return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

$lockData = readLockData($lockFile);

// Handle 1-click self-delete after install
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_installer') {
    $submittedToken = (string)($_POST['delete_token'] ?? '');
    $expectedToken = is_array($lockData) ? (string)($lockData['deleteToken'] ?? '') : '';
    if ($expectedToken !== '' && hash_equals($expectedToken, $submittedToken)) {
        $deleted = @unlink(__FILE__);
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installer Dihapus - TeleBalas</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#070b14;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px}.card{max-width:520px;background:#0f172a;border:1px solid #1e293b;border-radius:16px;padding:28px}h1{margin:0 0 10px;font-size:20px;color:#34d399}p{margin:0 0 14px;font-size:14px;line-height:1.6;color:#cbd5e1}a{display:inline-block;background:#0284c7;color:#fff;text-decoration:none;padding:10px 18px;border-radius:10px;font-weight:600;font-size:14px}</style></head><body><div class="card">';
        if ($deleted) {
            echo '<h1>File install.php Berhasil Dihapus</h1><p>Demi keamanan, file installer telah dihapus dari hosting Anda. Silakan lanjutkan langkah Setup Node.js App &amp; Cron Jobs di cPanel lalu buka website Anda.</p>';
        } else {
            echo '<h1>Gagal Menghapus Otomatis</h1><p>Silakan hapus file <code>install.php</code> secara manual melalui File Manager cPanel demi keamanan.</p>';
        }
        echo '<a href="/">Buka TeleBalas</a></div></body></html>';
        exit;
    }
}

$zipFiles = [];
foreach (glob($baseDir . '/*.zip') ?: [] as $zf) {
    $zipFiles[] = basename($zf);
}
usort($zipFiles, function ($a, $b) use ($defaultZip) {
    if ($a === $defaultZip) return -1;
    if ($b === $defaultZip) return 1;
    return strcmp($a, $b);
});

$phpOk = version_compare(PHP_VERSION, '7.4.0', '>=');
$zipExtOk = class_exists('ZipArchive');
$dirWritable = is_writable($baseDir);
$alreadyExtracted = is_file($baseDir . '/app.cjs') && is_file($baseDir . '/dist/index.html');
$siteUrl = detectSiteUrl();

$errors = [];
$installSuccess = false;
$summary = [];
$deleteToken = is_array($lockData) ? (string)($lockData['deleteToken'] ?? '') : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'install') {
    if ($lockData !== null) {
        $errors[] = 'Installer terkunci karena file .install.lock sudah ada. Hapus file .install.lock lewat File Manager cPanel hanya jika Anda benar-benar ingin mengulang instalasi.';
    } else {
        $selectedZip = basename((string)($_POST['zip_file'] ?? ''));
        $adminPin = trim((string)($_POST['admin_pin'] ?? ''));
        $overwriteStore = isset($_POST['overwrite_store']) && $_POST['overwrite_store'] === '1';

        if ($adminPin !== '' && !preg_match('/^\d{4,8}$/', $adminPin)) {
            $errors[] = 'PIN Admin harus berupa 4 sampai 8 digit angka, atau kosongkan untuk diatur lewat web.';
        }

        if (!$dirWritable) {
            $errors[] = 'Direktori saat ini tidak memiliki izin tulis (writable). Periksa permission folder di File Manager cPanel (755).';
        }

        if (empty($errors)) {
            // 1. Extract ZIP if available and selected
            if ($selectedZip !== '' && in_array($selectedZip, $zipFiles, true)) {
                if (!$zipExtOk) {
                    $errors[] = 'Ekstensi PHP ZipArchive tidak aktif di hosting Anda. Ekstrak file ZIP secara manual lewat File Manager cPanel (klik kanan -> Extract), lalu jalankan ulang installer ini tanpa memilih ZIP.';
                } else {
                    $zip = new ZipArchive();
                    $zipPath = $baseDir . '/' . $selectedZip;
                    if ($zip->open($zipPath) !== true) {
                        $errors[] = 'Gagal membuka file ZIP: ' . $selectedZip;
                    } else {
                        $extractedCount = 0;
                        for ($i = 0; $i < $zip->numFiles; $i++) {
                            $entryName = (string)$zip->getNameIndex($i);
                            if (!isSafeZipEntry($entryName)) {
                                continue;
                            }
                            $cleanName = ltrim(str_replace('\\', '/', $entryName), '/');
                            if ($cleanName === '' || $cleanName === '.env' || $cleanName === 'install.php') {
                                continue;
                            }
                            if (!$overwriteStore && $cleanName === 'data/store.json' && is_file($baseDir . '/data/store.json')) {
                                continue;
                            }
                            $targetPath = $baseDir . '/' . $cleanName;
                            if (substr($cleanName, -1) === '/') {
                                if (!is_dir($targetPath)) {
                                    @mkdir($targetPath, 0755, true);
                                }
                                continue;
                            }
                            $parentDir = dirname($targetPath);
                            if (!is_dir($parentDir)) {
                                @mkdir($parentDir, 0755, true);
                            }
                            $content = $zip->getFromIndex($i);
                            if ($content !== false) {
                                @file_put_contents($targetPath, $content);
                                $extractedCount++;
                            }
                        }
                        $zip->close();
                        $summary[] = 'Berhasil mengekstrak ' . $extractedCount . ' file dari ' . $selectedZip . '.';
                    }
                }
            } elseif (!$alreadyExtracted) {
                $errors[] = 'File ZIP belum dipilih dan file aplikasi (app.cjs & dist/) belum ditemukan. Upload telebalas-cpanel-siap-pakai.zip terlebih dahulu.';
            } else {
                $summary[] = 'Menggunakan file aplikasi TeleBalas yang sudah terekstrak.';
            }
        }

        if (empty($errors)) {
            // 2. Prepare data/store.json
            $dataDir = $baseDir . '/data';
            if (!is_dir($dataDir)) {
                @mkdir($dataDir, 0700, true);
            } else {
                @chmod($dataDir, 0700);
            }
            $storePath = $dataDir . '/store.json';
            $backupJson = $baseDir . '/database/telebalas-database.json';
            if ((!is_file($storePath) || $overwriteStore) && is_file($backupJson)) {
                @copy($backupJson, $storePath);
                $summary[] = 'Database awal data/store.json berhasil disiapkan.';
            }
            if (is_file($storePath)) {
                @chmod($storePath, 0600);
            }

            // 3. Create .env safely if not present
            $envPath = $baseDir . '/.env';
            if (!is_file($envPath)) {
                $secret = bin2hex(random_bytes(32));
                $envLines = [
                    'NODE_ENV=production',
                    'PORT=3000',
                    'ADMIN_SESSION_SECRET=' . $secret,
                    'ADMIN_PIN=' . $adminPin,
                ];
                $written = @file_put_contents($envPath, implode(PHP_EOL, $envLines) . PHP_EOL);
                if ($written === false) {
                    $errors[] = 'Gagal menulis file .env. Periksa izin folder cPanel Anda.';
                } else {
                    @chmod($envPath, 0600);
                    $summary[] = $adminPin !== ''
                        ? 'File .env berhasil dibuat dengan ADMIN_PIN pilihan Anda.'
                        : 'File .env berhasil dibuat (PIN admin akan diatur saat pertama kali membuka website).';
                }
            } else {
                $summary[] = 'File .env sudah ada dan tetap dipertahankan.';
            }
        }

        if (empty($errors)) {
            $deleteToken = bin2hex(random_bytes(24));
            @file_put_contents(
                $lockFile,
                json_encode([
                    'installedAt' => gmdate('c'),
                    'deleteToken' => $deleteToken,
                ], JSON_PRETTY_PRINT)
            );
            @chmod($lockFile, 0600);
            $lockData = ['installedAt' => gmdate('c'), 'deleteToken' => $deleteToken];
            $installSuccess = true;
        }
    }
}

$cronCommand = 'curl -fsS ' . $siteUrl . '/api/keepalive >/dev/null 2>&1';
$appRootHint = basename($baseDir);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Installer cPanel Shared Hosting - TeleBalas</title>
  <style>
    :root{color-scheme:dark light}
    *{box-sizing:border-box}
    body{margin:0;padding:28px 16px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#060a13;color:#e2e8f0;line-height:1.55}
    .wrap{max-width:780px;margin:0 auto}
    .hero{background:linear-gradient(135deg,#0b1120,#111d38,#0e294d);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:24px 28px;margin-bottom:20px}
    .hero h1{margin:0 0 6px;font-size:22px;color:#fff}
    .hero p{margin:0;font-size:13.5px;color:#cbd5e1}
    .card{background:#0f1624;border:1px solid #1e293b;border-radius:16px;padding:22px 24px;margin-bottom:18px}
    .card h2{margin:0 0 12px;font-size:15.5px;color:#f8fafc}
    .checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
    .check{background:#0b1120;border:1px solid #1e293b;border-radius:12px;padding:12px 14px;font-size:13px}
    .ok{color:#34d399;font-weight:600}.bad{color:#fb7185;font-weight:600}.warn{color:#fbbf24;font-weight:600}
    label{display:block;font-size:12.5px;font-weight:600;color:#cbd5e1;margin-bottom:6px}
    input[type=text],input[type=password],select{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #334155;background:#090f1d;color:#f8fafc;font-size:14px;margin-bottom:14px}
    .checkline{display:flex;align-items:center;gap:8px;font-size:13px;color:#cbd5e1;margin-bottom:16px;cursor:pointer}
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:11px;padding:11px 20px;font-size:14px;font-weight:600;cursor:pointer;color:#fff;background:linear-gradient(90deg,#0284c7,#4f46e5)}
    .btn:hover{opacity:.95}
    .btn-danger{background:linear-gradient(90deg,#e11d48,#be123c)}
    .alert{border-radius:12px;padding:13px 16px;font-size:13.5px;margin-bottom:16px}
    .alert-err{background:rgba(225,29,72,.14);border:1px solid rgba(244,63,94,.35);color:#fecdd3}
    .alert-ok{background:rgba(16,185,129,.12);border:1px solid rgba(52,211,153,.35);color:#a7f3d0}
    .alert-warn{background:rgba(245,158,11,.12);border:1px solid rgba(251,191,36,.35);color:#fde68a}
    code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#070b14;border:1px solid #1e293b;border-radius:8px;color:#7dd3fc}
    code{padding:2px 6px;font-size:12.5px}
    pre{padding:12px 14px;overflow-x:auto;font-size:12.5px;margin:8px 0}
    ol{margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#cbd5e1}
    li{margin-bottom:9px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>TeleBalas — Installer Web cPanel Shared Hosting</h1>
      <p>Pasang website &amp; bot auto-reply Telegram 24/7 langsung dari browser tanpa SSH atau Terminal.</p>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-err">
        <strong>Instalasi belum dapat dilanjutkan:</strong>
        <ul style="margin:6px 0 0;padding-left:18px">
          <?php foreach ($errors as $err): ?>
            <li><?php echo h($err); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($installSuccess): ?>
      <div class="alert alert-ok">
        <strong>Instalasi File &amp; Database Selesai!</strong>
        <ul style="margin:6px 0 0;padding-left:18px">
          <?php foreach ($summary as $item): ?>
            <li><?php echo h($item); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="card">
        <h2>Langkah Berikutnya di cPanel (Tanpa SSH / Terminal)</h2>
        <ol>
          <li>Buka menu <strong>Setup Node.js App</strong> di cPanel Anda, lalu klik <strong>Create Application</strong>:
            <br>Node.js version: <code>18 / 20 / 22</code> · Mode: <code>Production</code> · Application root: <code><?php echo h($appRootHint); ?></code> · Application startup file: <code>app.cjs</code>
          </li>
          <li>Klik <strong>Create</strong>, lalu klik tombol <strong>Run NPM Install</strong> pada bagian Detected configuration files.</li>
          <li>Klik tombol <strong>Restart</strong> di bagian atas Setup Node.js App.</li>
          <li><strong>Agar Bot Aktif 24 Jam / 7 Hari Non-Stop:</strong> Buka menu <strong>Cron Jobs</strong> di cPanel, pilih jadwal <em>Once Per Five Minutes</em> (<code>*/5 * * * *</code>), lalu masukkan perintah ini:
            <pre><?php echo h($cronCommand); ?></pre>
            Cron Job GUI ini mencegah Shared Hosting menidurkan aplikasi Node.js dan menjaga koneksi MTProto Telegram tetap hidup 24/7.
          </li>
        </ol>
      </div>

      <?php if ($deleteToken !== ''): ?>
        <div class="card">
          <h2>Langkah Keamanan Wajib</h2>
          <p style="font-size:13.5px;color:#cbd5e1;margin-top:0">Hapus file <code>install.php</code> sekarang agar tidak bisa diakses pihak lain.</p>
          <form method="post">
            <input type="hidden" name="action" value="delete_installer">
            <input type="hidden" name="delete_token" value="<?php echo h($deleteToken); ?>">
            <button type="submit" class="btn btn-danger">Hapus install.php Sekarang</button>
          </form>
        </div>
      <?php endif; ?>

    <?php elseif ($lockData !== null): ?>
      <div class="alert alert-warn">
        <strong>Installer Sudah Terkunci (.install.lock ditemukan)</strong><br>
        TeleBalas sudah pernah diinstal pada folder ini pada <code><?php echo h((string)($lockData['installedAt'] ?? '-')); ?></code>. Jika Anda perlu menginstal ulang, hapus file <code>.install.lock</code> melalui File Manager cPanel.
      </div>
      <?php if ($deleteToken !== ''): ?>
        <div class="card">
          <form method="post">
            <input type="hidden" name="action" value="delete_installer">
            <input type="hidden" name="delete_token" value="<?php echo h($deleteToken); ?>">
            <button type="submit" class="btn btn-danger">Hapus install.php Sekarang</button>
          </form>
        </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="card">
        <h2>1. Pemeriksaan Hosting cPanel</h2>
        <div class="checks">
          <div class="check">Versi PHP: <span class="<?php echo $phpOk ? 'ok' : 'bad'; ?>"><?php echo h(PHP_VERSION); ?></span></div>
          <div class="check">Ekstensi ZipArchive: <span class="<?php echo $zipExtOk ? 'ok' : 'warn'; ?>"><?php echo $zipExtOk ? 'Tersedia' : 'Tidak Aktif (Ekstrak manual)'; ?></span></div>
          <div class="check">Izin Folder: <span class="<?php echo $dirWritable ? 'ok' : 'bad'; ?>"><?php echo $dirWritable ? 'Bisa Ditulis' : 'Read-Only'; ?></span></div>
          <div class="check">Status Aplikasi: <span class="ok"><?php echo $alreadyExtracted ? 'Sudah Terekstrak' : (count($zipFiles) > 0 ? 'ZIP Siap Ekstrak' : 'Menunggu ZIP'); ?></span></div>
        </div>
      </div>

      <form method="post" class="card">
        <input type="hidden" name="action" value="install">
        <h2>2. Konfigurasi &amp; Ekstrak Otomatis</h2>

        <label for="zip_file">Pilih Paket ZIP TeleBalas</label>
        <select id="zip_file" name="zip_file">
          <?php if ($alreadyExtracted): ?>
            <option value="">(Lewati ekstrak — file aplikasi sudah tersedia di folder ini)</option>
          <?php endif; ?>
          <?php foreach ($zipFiles as $zf): ?>
            <option value="<?php echo h($zf); ?>" <?php echo $zf === $defaultZip ? 'selected' : ''; ?>><?php echo h($zf); ?></option>
          <?php endforeach; ?>
          <?php if (empty($zipFiles) && !$alreadyExtracted): ?>
            <option value="">Belum ada file .zip di folder ini</option>
          <?php endif; ?>
        </select>

        <label for="admin_pin">PIN Admin Panel (4–8 digit angka, opsional)</label>
        <input id="admin_pin" name="admin_pin" type="password" inputmode="numeric" pattern="[0-9]{4,8}" maxlength="8" placeholder="Kosongkan untuk membuat PIN saat membuka website pertama kali">

        <label class="checkline">
          <input type="checkbox" name="overwrite_store" value="1">
          <span>Timpa <code>data/store.json</code> dengan database bawaan ZIP (centang hanya untuk instalasi baru)</span>
        </label>

        <button type="submit" class="btn">Ekstrak &amp; Pasang TeleBalas Sekarang</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
