export interface QrisTag {
  id: string;
  value: string;
}

/**
 * Standard EMVCo QRIS CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF).
 */
export function crc16Ccitt(input: string): string {
  let crc = 0xffff;
  for (let i = 0; i < input.length; i++) {
    crc ^= input.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

export function parseQrisTags(payload: string): QrisTag[] | null {
  const clean = payload.trim();
  if (clean.length < 16 || !clean.startsWith('0002')) return null;

  const tags: QrisTag[] = [];
  let cursor = 0;

  while (cursor < clean.length) {
    if (cursor + 4 > clean.length) return null;
    const id = clean.slice(cursor, cursor + 2);
    const lenStr = clean.slice(cursor + 2, cursor + 4);
    if (!/^\d{2}$/.test(id) || !/^\d{2}$/.test(lenStr)) return null;
    const len = Number(lenStr);
    const valStart = cursor + 4;
    const valEnd = valStart + len;
    if (valEnd > clean.length) return null;
    const value = clean.slice(valStart, valEnd);
    tags.push({ id, value });
    cursor = valEnd;
  }

  return tags;
}

export function serializeQrisTags(tags: QrisTag[]): string {
  return tags
    .map((t) => `${t.id}${String(t.value.length).padStart(2, '0')}${t.value}`)
    .join('');
}

export function validateStaticQris(payload: string): { valid: boolean; error?: string } {
  const clean = payload.trim();
  if (!clean) {
    return { valid: false, error: 'String QRIS GoPay Merchant tidak boleh kosong.' };
  }
  const tags = parseQrisTags(clean);
  if (!tags || tags.length < 5) {
    return { valid: false, error: 'Format TLV QRIS tidak valid. Pastikan diawali 000201...' };
  }
  const crcTag = tags.find((t) => t.id === '63');
  if (!crcTag || crcTag.value.length !== 4) {
    return { valid: false, error: 'Tag checksum CRC (63) QRIS tidak ditemukan.' };
  }

  const withoutCrc = clean.slice(0, clean.length - 4);
  const expectedCrc = crc16Ccitt(withoutCrc);
  if (expectedCrc !== crcTag.value.toUpperCase()) {
    return {
      valid: false,
      error: `Checksum CRC QRIS tidak cocok (seharusnya ${expectedCrc}, terbaca ${crcTag.value}).`,
    };
  }

  return { valid: true };
}

/**
 * Converts a static QRIS GoPay Merchant payload into a dynamic QRIS with exact nominal.
 */
export function generateDynamicQris(staticQris: string, amount: number): string {
  const cleanAmount = Math.max(1, Math.round(amount));
  const check = validateStaticQris(staticQris);
  if (!check.valid) {
    throw new Error(check.error || 'String QRIS GoPay Merchant tidak valid.');
  }

  const tags = parseQrisTags(staticQris.trim())!;
  const withoutCrc = tags.filter((t) => t.id !== '63');

  // Set Point of Initiation Method (01) -> 12 (Dynamic QR)
  const tag01 = withoutCrc.find((t) => t.id === '01');
  if (tag01) {
    tag01.value = '12';
  } else {
    withoutCrc.splice(1, 0, { id: '01', value: '12' });
  }

  // Ensure Currency Code (53) = 360 (IDR)
  if (!withoutCrc.some((t) => t.id === '53')) {
    withoutCrc.push({ id: '53', value: '360' });
  }

  // Set Transaction Amount (54) right before Tag 58/59 or after Tag 53
  const amountTag: QrisTag = { id: '54', value: String(cleanAmount) };
  const existing54Idx = withoutCrc.findIndex((t) => t.id === '54');
  if (existing54Idx >= 0) {
    withoutCrc[existing54Idx] = amountTag;
  } else {
    const idx58 = withoutCrc.findIndex((t) => Number(t.id) >= 58);
    if (idx58 >= 0) {
      withoutCrc.splice(idx58, 0, amountTag);
    } else {
      withoutCrc.push(amountTag);
    }
  }

  const bodyWithCrcPrefix = `${serializeQrisTags(withoutCrc)}6304`;
  const crc = crc16Ccitt(bodyWithCrcPrefix);
  return `${bodyWithCrcPrefix}${crc}`;
}

export function extractMerchantNameFromQris(qrisPayload: string): string | null {
  const tags = parseQrisTags(qrisPayload);
  if (!tags) return null;
  return tags.find((t) => t.id === '59')?.value || null;
}

/**
 * Generates a valid CRC-16 EMVCo QRIS sample string for testing/preview before merchant pastes their real QRIS.
 */
export function buildSampleStaticQris(merchantName = 'TELEBALAS GOPAY'): string {
  const body = serializeQrisTags([
    { id: '00', value: '01' },
    { id: '01', value: '11' },
    { id: '26', value: '0011ID.GOPAY.WWW011893600914000000000102152000000000000010303UMI' },
    { id: '52', value: '5732' },
    { id: '53', value: '360' },
    { id: '58', value: 'ID' },
    { id: '59', value: merchantName.slice(0, 25).toUpperCase() },
    { id: '60', value: 'JAKARTA' },
    { id: '61', value: '12190' },
  ]);
  const base = `${body}6304`;
  return `${base}${crc16Ccitt(base)}`;
}

export const SAMPLE_GOPAY_STATIC_QRIS = buildSampleStaticQris('TOKO DIGITAL TELEBALAS');

/**
 * Extracts exact integer IDR amount from Indonesian GoPay Merchant notification strings
 * (e.g., "Pembayaran QRIS sebesar Rp 35.147 berhasil diterima" -> 35147).
 */
export function parseGoPayNotificationAmount(text: string): number | null {
  const clean = text.trim();
  if (!clean) return null;

  // Match Rp 35.147 / Rp35.147 / IDR 35,147 / Rp 35.147,00
  const match = /(?:rp|idr)\.?\s*([0-9][0-9.,]*)/i.exec(clean);
  if (!match) return null;

  let rawNum = match[1];
  // Strip trailing ,00 or .00 decimals if present
  rawNum = rawNum.replace(/([.,]00)$/, '');
  const digitsOnly = rawNum.replace(/[^0-9]/g, '');
  if (!digitsOnly) return null;

  const parsed = Number(digitsOnly);
  if (!Number.isSafeInteger(parsed) || parsed <= 0 || parsed > 100_000_000) {
    return null;
  }
  return parsed;
}
