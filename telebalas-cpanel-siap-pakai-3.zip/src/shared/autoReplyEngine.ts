import type {
  AutoReplyRule,
  BotSchedule,
  BotSettings,
  IncomingMessageInput,
  MatchEvaluationResult,
  PaymentOrder,
  ProductAccountItem,
  ProductItem,
  ProductStockStatus,
} from './types';

export const DEFAULT_FALLBACK_REPLY_TEXT =
  'Halo {nama}, terima kasih sudah menghubungi saya di Telegram. Pesan Anda ("{pesan}") sudah diterima pada pukul {waktu} WIB dan akan segera saya balas.\n\nBerikut katalog layanan yang tersedia saat ini:\n{katalog}';

export interface RuleValidationInput {
  name: string;
  matchType: AutoReplyRule['matchType'];
  pattern: string;
  replyText: string;
  delayMs: number;
  cooldownSeconds: number;
  priority: number;
}

export interface ProductValidationInput {
  name: string;
  category: string;
  price: number;
  duration: string;
  keywords: string;
  replyTemplate: string;
}

export interface ProductAccountValidationInput {
  email: string;
  password: string;
  extraData: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

export function formatRupiah(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.max(0, Math.round(amount)) : 0;
  return `Rp ${safe.toLocaleString('id-ID')}`;
}

export function stockStatusLabel(status: ProductStockStatus): string {
  switch (status) {
    case 'tersedia':
      return 'Tersedia';
    case 'terbatas':
      return 'Stok Terbatas';
    case 'habis':
      return 'Stok Habis';
  }
}

export function getAvailableAccountCount(product: ProductItem): number {
  return (product.accounts ?? []).filter((a) => a.status === 'available').length;
}

export function validateProductAccountInput(
  input: ProductAccountValidationInput
): ValidationResult {
  const errors: Record<string, string> = {};
  const email = input.email?.trim() ?? '';
  const password = input.password?.trim() ?? '';
  const extraData = input.extraData?.trim() ?? '';

  if (!email && !extraData) {
    errors.email = 'Minimal isi Email/Username atau Data Lain akun.';
  } else if (email.length > 160) {
    errors.email = 'Email/Username maksimal 160 karakter.';
  }

  if (password.length > 160) {
    errors.password = 'Password maksimal 160 karakter.';
  }

  if (extraData.length > 1000) {
    errors.extraData = 'Data tambahan maksimal 1000 karakter.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

const ORDER_COMMAND_PREFIXES = ['order', 'beli', 'checkout', 'bayar', 'pesan', 'buy', 'qris'];

export function detectOrderIntent(text: string, products: ProductItem[]): ProductItem | null {
  const clean = text.trim().toLowerCase();
  if (!clean) return null;

  const hasOrderVerb = ORDER_COMMAND_PREFIXES.some((verb) => {
    const re = new RegExp(`(?:^|\\s)${verb}(?:\\s|$)`, 'i');
    return re.test(clean);
  });
  if (!hasOrderVerb) return null;

  const activeProducts = products.filter((p) => p.autoReplyEnabled);
  return activeProducts.find((product) => doesProductMatchText(product, clean)) ?? null;
}

export function formatAccountDeliveryMessage(params: {
  buyerName: string;
  order: PaymentOrder;
  account: { email: string; password: string; extraData: string } | null;
}): string {
  const { buyerName, order, account } = params;
  const lines = [
    `✅ *Pembayaran QRIS GoPay Terverifikasi!*`,
    ``,
    `Halo ${buyerName || 'Kak'}, pembayaran untuk pesanan *${order.orderCode}* sebesar *${formatRupiah(order.totalAmount)}* telah otomatis terbaca oleh sistem mutasi GoPay Merchant.`,
    ``,
    `📦 *Detail Produk:* ${order.productName}`,
  ];

  if (account) {
    lines.push(`🔐 *Detail Akun Anda:*`);
    if (account.email) lines.push(`• Email / Login: \`${account.email}\``);
    if (account.password) lines.push(`• Password: \`${account.password}\``);
    if (account.extraData) lines.push(`• Info / Data Lain: ${account.extraData}`);
  } else {
    lines.push(
      `📌 Pesanan Anda sudah lunas dan dicatat. Admin akan segera memproses pengiriman/aktivasi ke akun Anda.`
    );
  }

  lines.push('', 'Terima kasih sudah berbelanja! Simpan data akun ini baik-baik.');
  return lines.join('\n');
}

export function validateRuleInput(input: RuleValidationInput): ValidationResult {
  const errors: Record<string, string> = {};

  if (!input.name || input.name.trim().length < 2) {
    errors.name = 'Nama aturan minimal 2 karakter.';
  } else if (input.name.trim().length > 80) {
    errors.name = 'Nama aturan maksimal 80 karakter.';
  }

  if (input.matchType !== 'all_incoming') {
    if (!input.pattern || input.pattern.trim().length === 0) {
      errors.pattern = 'Kata kunci atau pola wajib diisi.';
    } else if (input.pattern.trim().length > 300) {
      errors.pattern = 'Pola maksimal 300 karakter.';
    } else if (input.matchType === 'regex') {
      try {
        new RegExp(input.pattern.trim(), 'u');
      } catch {
        errors.pattern = 'Format ekspresi reguler (Regex) tidak valid.';
      }
    }
  }

  if (!input.replyText || input.replyText.trim().length === 0) {
    errors.replyText = 'Teks balasan otomatis wajib diisi.';
  } else if (input.replyText.trim().length > 4000) {
    errors.replyText = 'Teks balasan maksimal 4000 karakter.';
  }

  if (!Number.isFinite(input.delayMs) || input.delayMs < 0 || input.delayMs > 30000) {
    errors.delayMs = 'Jeda balasan harus antara 0 hingga 30.000 ms.';
  }

  if (
    !Number.isFinite(input.cooldownSeconds) ||
    input.cooldownSeconds < 0 ||
    input.cooldownSeconds > 86400
  ) {
    errors.cooldownSeconds = 'Cooldown harus antara 0 hingga 86.400 detik.';
  }

  if (!Number.isFinite(input.priority) || input.priority < 1 || input.priority > 999) {
    errors.priority = 'Prioritas harus antara 1 hingga 999.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function validateProductInput(input: ProductValidationInput): ValidationResult {
  const errors: Record<string, string> = {};

  if (!input.name || input.name.trim().length < 2) {
    errors.name = 'Nama produk minimal 2 karakter.';
  } else if (input.name.trim().length > 80) {
    errors.name = 'Nama produk maksimal 80 karakter.';
  }

  if (!input.category || input.category.trim().length < 2) {
    errors.category = 'Kategori produk wajib diisi.';
  }

  if (!Number.isFinite(input.price) || input.price < 0 || input.price > 100_000_000) {
    errors.price = 'Harga produk harus antara Rp 0 hingga Rp 100.000.000.';
  }

  if (!input.duration || input.duration.trim().length === 0) {
    errors.duration = 'Durasi atau satuan paket wajib diisi.';
  }

  if (!input.keywords || input.keywords.trim().length === 0) {
    errors.keywords = 'Kata kunci pemicu produk wajib diisi (misal: netflix, nf).';
  }

  if (!input.replyTemplate || input.replyTemplate.trim().length === 0) {
    errors.replyTemplate = 'Template balasan produk wajib diisi.';
  } else if (input.replyTemplate.trim().length > 4000) {
    errors.replyTemplate = 'Template balasan maksimal 4000 karakter.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

function parseMinutes(hhmm: string): number | null {
  const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(hhmm.trim());
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}

export function isWithinSchedule(schedule: BotSchedule, now: Date = new Date()): boolean {
  if (!schedule.enabled) return true;

  const startMin = parseMinutes(schedule.startTime);
  const endMin = parseMinutes(schedule.endTime);
  if (startMin === null || endMin === null) return true;
  if (startMin === endMin) return true;

  const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
  const offset = Number.isFinite(schedule.timezoneOffsetMinutes)
    ? schedule.timezoneOffsetMinutes
    : 420;
  const localMinutes = ((utcMinutes + offset) % 1440 + 1440) % 1440;

  if (startMin < endMin) {
    return localMinutes >= startMin && localMinutes < endMin;
  }
  return localMinutes >= startMin || localMinutes < endMin;
}

export function normalizeIdentifier(value: string): string {
  return value.trim().replace(/^@/, '').toLowerCase();
}

function isInIdentifierList(
  senderId: string,
  senderUsername: string | null | undefined,
  list: string[]
): boolean {
  if (!list || list.length === 0) return false;
  const normalizedList = new Set(list.map(normalizeIdentifier).filter(Boolean));
  if (normalizedList.has(normalizeIdentifier(senderId))) return true;
  if (senderUsername && normalizedList.has(normalizeIdentifier(senderUsername))) return true;
  return false;
}

export function doesRuleMatchText(rule: AutoReplyRule, text: string): boolean {
  const incoming = text.trim();
  if (!incoming && rule.matchType !== 'all_incoming') return false;

  if (rule.matchType === 'all_incoming') {
    return true;
  }

  const hay = rule.caseSensitive ? incoming : incoming.toLowerCase();
  const needleRaw = rule.pattern.trim();
  const needle = rule.caseSensitive ? needleRaw : needleRaw.toLowerCase();

  switch (rule.matchType) {
    case 'exact':
      return hay === needle;
    case 'contains': {
      const parts = needle
        .split(',')
        .map((p) => p.trim())
        .filter(Boolean);
      return parts.some((part) => hay.includes(part));
    }
    case 'starts_with':
      return hay.startsWith(needle);
    case 'regex': {
      try {
        const flags = rule.caseSensitive ? 'u' : 'iu';
        const re = new RegExp(needleRaw, flags);
        return re.test(incoming);
      } catch {
        return false;
      }
    }
    default:
      return false;
  }
}

export function doesProductMatchText(product: ProductItem, text: string): boolean {
  const hay = text.trim().toLowerCase();
  if (!hay) return false;
  const parts = product.keywords
    .split(',')
    .map((k) => k.trim().toLowerCase())
    .filter(Boolean);
  return parts.some((kw) => hay.includes(kw));
}

export function buildProductCatalogText(products: ProductItem[]): string {
  const active = products.filter((p) => p.autoReplyEnabled && p.stockStatus !== 'habis');
  if (active.length === 0) {
    return 'Saat ini belum ada produk yang tersedia di katalog.';
  }
  return active
    .map(
      (p) =>
        `• ${p.name} (${p.duration}) — ${formatRupiah(p.price)} [${stockStatusLabel(p.stockStatus)}]`
    )
    .join('\n');
}

export function renderReplyTemplate(
  template: string,
  context: {
    senderName: string;
    senderUsername?: string | null;
    incomingText: string;
    now?: Date;
    timezoneOffsetMinutes?: number;
    products?: ProductItem[];
    product?: ProductItem | null;
  }
): string {
  const now = context.now ?? new Date();
  const offsetMin = context.timezoneOffsetMinutes ?? 420;
  const localMs = now.getTime() + offsetMin * 60_000;
  const localDate = new Date(localMs);

  const hh = String(localDate.getUTCHours()).padStart(2, '0');
  const mm = String(localDate.getUTCMinutes()).padStart(2, '0');
  const waktu = `${hh}:${mm}`;

  const dd = String(localDate.getUTCDate()).padStart(2, '0');
  const mo = String(localDate.getUTCMonth() + 1).padStart(2, '0');
  const yyyy = localDate.getUTCFullYear();
  const tanggal = `${dd}/${mo}/${yyyy}`;

  const safeName = context.senderName.trim() || 'Kak';
  const safeUsername = context.senderUsername
    ? `@${context.senderUsername.replace(/^@/, '')}`
    : safeName;

  let rendered = template
    .replace(/\{nama\}/gi, safeName)
    .replace(/\{username\}/gi, safeUsername)
    .replace(/\{pesan\}/gi, context.incomingText.trim())
    .replace(/\{waktu\}/gi, waktu)
    .replace(/\{tanggal\}/gi, tanggal);

  if (context.products) {
    rendered = rendered.replace(/\{katalog\}/gi, buildProductCatalogText(context.products));
  }

  if (context.product) {
    rendered = rendered
      .replace(/\{produk\}/gi, context.product.name)
      .replace(/\{harga\}/gi, formatRupiah(context.product.price))
      .replace(/\{durasi\}/gi, context.product.duration)
      .replace(/\{stok\}/gi, stockStatusLabel(context.product.stockStatus))
      .replace(/\{deskripsi\}/gi, context.product.description || '-');
  }

  return rendered;
}

export interface MatchOptions {
  ignoreScheduleAndCooldown?: boolean;
}

export function matchMessageToRules(
  input: IncomingMessageInput,
  rules: AutoReplyRule[],
  settings: BotSettings,
  cooldownMap: Map<string, number>,
  now: Date = new Date(),
  options: MatchOptions = {},
  products: ProductItem[] = []
): MatchEvaluationResult {
  if (!settings.botEnabled) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: 'Bot auto-reply sedang dinonaktifkan.',
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null,
    };
  }

  if (input.chatType === 'group' && settings.ignoreGroupsByDefault) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: 'Pesan grup diabaikan sesuai pengaturan.',
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null,
    };
  }

  if (isInIdentifierList(input.senderId, input.senderUsername, settings.blacklist)) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: 'Pengirim masuk dalam daftar blokir (blacklist).',
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null,
    };
  }

  if (
    settings.ignoreContactsInWhitelistOnly &&
    !isInIdentifierList(input.senderId, input.senderUsername, settings.whitelist)
  ) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: 'Mode whitelist aktif: pengirim tidak terdaftar di whitelist.',
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null,
    };
  }

  if (!options.ignoreScheduleAndCooldown && !isWithinSchedule(settings.schedule, now)) {
    return {
      shouldReply: false,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply: null,
      reason: `Di luar jam aktif (${settings.schedule.startTime}–${settings.schedule.endTime}).`,
      delayMs: 0,
      quoteOriginal: false,
      cooldownKey: null,
    };
  }

  const orderedRules = [...rules]
    .filter((r) => r.enabled && (r.chatScope === 'all' || r.chatScope === input.chatType))
    .sort((a, b) => a.priority - b.priority);

  const specificRule = orderedRules.find(
    (rule) => rule.matchType !== 'all_incoming' && doesRuleMatchText(rule, input.text)
  );

  if (specificRule) {
    const cooldownSec =
      specificRule.cooldownSeconds >= 0
        ? specificRule.cooldownSeconds
        : settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:${specificRule.id}`;

    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === 'number') {
        const elapsedSec = (now.getTime() - lastSentMs) / 1000;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: specificRule,
            matchedProduct: null,
            matchedDefaultReply: false,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey,
          };
        }
      }
    }

    const renderedReply = renderReplyTemplate(specificRule.replyText, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products,
    });

    return {
      shouldReply: true,
      matchedRule: specificRule,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply,
      reason: `Cocok dengan aturan "${specificRule.name}" (${specificRule.matchType}).`,
      delayMs: specificRule.delayMs,
      quoteOriginal: specificRule.quoteOriginal,
      cooldownKey,
    };
  }

  // Next evaluate product auto-reply keywords (private & all messages when enabled)
  const matchedProduct = products.find(
    (product) => product.autoReplyEnabled && doesProductMatchText(product, input.text)
  );

  if (matchedProduct) {
    const cooldownSec = settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:prod_${matchedProduct.id}`;

    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === 'number') {
        const elapsedSec = (now.getTime() - lastSentMs) / 1000;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: null,
            matchedProduct,
            matchedDefaultReply: false,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam produk (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey,
          };
        }
      }
    }

    const renderedReply = renderReplyTemplate(matchedProduct.replyTemplate, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products,
      product: matchedProduct,
    });

    return {
      shouldReply: true,
      matchedRule: null,
      matchedProduct,
      matchedDefaultReply: false,
      renderedReply,
      reason: `Cocok dengan produk "${matchedProduct.name}".`,
      delayMs: 800,
      quoteOriginal: true,
      cooldownKey,
    };
  }

  // Fallback all_incoming rule
  const fallbackRule = orderedRules.find((rule) => rule.matchType === 'all_incoming');
  if (fallbackRule) {
    const cooldownSec =
      fallbackRule.cooldownSeconds >= 0
        ? fallbackRule.cooldownSeconds
        : settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:${fallbackRule.id}`;

    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === 'number') {
        const elapsedSec = (now.getTime() - lastSentMs) / 1000;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: fallbackRule,
            matchedProduct: null,
            matchedDefaultReply: false,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey,
          };
        }
      }
    }

    const renderedReply = renderReplyTemplate(fallbackRule.replyText, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products,
    });

    return {
      shouldReply: true,
      matchedRule: fallbackRule,
      matchedProduct: null,
      matchedDefaultReply: false,
      renderedReply,
      reason: `Cocok dengan aturan "${fallbackRule.name}" (${fallbackRule.matchType}).`,
      delayMs: fallbackRule.delayMs,
      quoteOriginal: fallbackRule.quoteOriginal,
      cooldownKey,
    };
  }

  // Global catch-all default reply if enabled (handles empty rules or unmatched messages)
  if (settings.defaultReplyEnabled) {
    const templateText = settings.defaultReplyText?.trim() || DEFAULT_FALLBACK_REPLY_TEXT;
    const cooldownSec = settings.defaultCooldownSeconds;
    const cooldownKey = `${input.chatId}:default_reply`;

    if (!options.ignoreScheduleAndCooldown && cooldownSec > 0) {
      const lastSentMs = cooldownMap.get(cooldownKey);
      if (typeof lastSentMs === 'number') {
        const elapsedSec = (now.getTime() - lastSentMs) / 1000;
        if (elapsedSec < cooldownSec) {
          const remaining = Math.ceil(cooldownSec - elapsedSec);
          return {
            shouldReply: false,
            matchedRule: null,
            matchedProduct: null,
            matchedDefaultReply: true,
            renderedReply: null,
            reason: `Dalam masa jeda anti-spam balasan default (${remaining} detik tersisa).`,
            delayMs: 0,
            quoteOriginal: false,
            cooldownKey,
          };
        }
      }
    }

    const renderedReply = renderReplyTemplate(templateText, {
      senderName: input.senderName,
      senderUsername: input.senderUsername,
      incomingText: input.text,
      now,
      timezoneOffsetMinutes: settings.schedule.timezoneOffsetMinutes,
      products,
    });

    return {
      shouldReply: true,
      matchedRule: null,
      matchedProduct: null,
      matchedDefaultReply: true,
      renderedReply,
      reason: 'Menggunakan balasan default untuk semua pesan masuk.',
      delayMs: 800,
      quoteOriginal: false,
      cooldownKey,
    };
  }

  return {
    shouldReply: false,
    matchedRule: null,
    matchedProduct: null,
    matchedDefaultReply: false,
    renderedReply: null,
    reason: 'Tidak ada aturan aktif atau produk yang cocok dengan isi pesan.',
    delayMs: 0,
    quoteOriginal: false,
    cooldownKey: null,
  };
}
