export type MatchType =
  | 'exact'
  | 'contains'
  | 'starts_with'
  | 'regex'
  | 'all_incoming';

export type ChatScope = 'private' | 'group' | 'all';

export type TelegramConnectionStatus =
  | 'disconnected'
  | 'connecting'
  | 'awaiting_code'
  | 'awaiting_password'
  | 'connected'
  | 'error';

export type LogOutcome = 'replied' | 'skipped' | 'simulated' | 'failed';

export type ProductStockStatus = 'tersedia' | 'terbatas' | 'habis';

export type ProductAccountStatus = 'available' | 'reserved' | 'sold';

export interface ProductAccountItem {
  id: string;
  email: string;
  password: string;
  extraData: string;
  status: ProductAccountStatus;
  soldToOrderId: string | null;
  soldAt: string | null;
  createdAt: string;
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: number;
  duration: string;
  stockStatus: ProductStockStatus;
  keywords: string;
  description: string;
  replyTemplate: string;
  autoReplyEnabled: boolean;
  accounts: ProductAccountItem[];
  hitCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface AutoReplyRule {
  id: string;
  name: string;
  enabled: boolean;
  matchType: MatchType;
  pattern: string;
  caseSensitive: boolean;
  chatScope: ChatScope;
  replyText: string;
  quoteOriginal: boolean;
  delayMs: number;
  cooldownSeconds: number;
  priority: number;
  hitCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface BotSchedule {
  enabled: boolean;
  startTime: string; // HH:MM (24h)
  endTime: string;   // HH:MM (24h)
  timezoneOffsetMinutes: number; // e.g., +420 for WIB (UTC+7)
}

export interface BotSettings {
  botEnabled: boolean;
  defaultReplyEnabled: boolean;
  defaultReplyText: string;
  ignoreGroupsByDefault: boolean;
  ignoreContactsInWhitelistOnly: boolean;
  whitelist: string[];
  blacklist: string[];
  defaultCooldownSeconds: number;
  typingIndicator: boolean;
  schedule: BotSchedule;
}

export interface TelegramAccountPublic {
  status: TelegramConnectionStatus;
  apiId: number | null;
  apiHashMasked: string | null;
  hasSession: boolean;
  phoneMasked: string | null;
  firstName: string | null;
  lastName: string | null;
  username: string | null;
  telegramId: string | null;
  connectedAt: string | null;
  errorMessage: string | null;
}

export interface MessageLogEntry {
  id: string;
  timestamp: string;
  senderId: string;
  senderName: string;
  senderUsername: string | null;
  chatType: 'private' | 'group';
  incomingText: string;
  matchedRuleId: string | null;
  matchedRuleName: string | null;
  replyText: string | null;
  outcome: LogOutcome;
  reason: string;
}

export type OrderStatus = 'pending' | 'paid' | 'delivered' | 'expired' | 'cancelled';

export interface PaymentOrder {
  id: string;
  orderCode: string;
  productId: string;
  productName: string;
  basePrice: number;
  uniqueCode: number;
  totalAmount: number;
  buyerChatId: string;
  buyerSenderId: string;
  buyerName: string;
  buyerUsername: string | null;
  source: 'telegram' | 'simulator';
  qrisPayload: string;
  status: OrderStatus;
  reservedAccountId: string | null;
  deliveredAccount: {
    email: string;
    password: string;
    extraData: string;
  } | null;
  deliveryPending: boolean;
  deliveryError: string | null;
  mutationRef: string | null;
  paidVia: string | null;
  createdAt: string;
  expiresAt: string;
  paidAt: string | null;
  deliveredAt: string | null;
}

export interface GoPayMutationEntry {
  id: string;
  mutationRef: string;
  amount: number;
  source: 'api_poll' | 'webhook' | 'simulation';
  senderName: string | null;
  matchedOrderCode: string | null;
  rawSummary: string;
  receivedAt: string;
}

export interface GoPayMerchantConfig {
  enabled: boolean;
  merchantName: string;
  staticQris: string;
  mutationApiUrl: string;
  apiToken: string;
  webhookSecret: string;
  pollingEnabled: boolean;
  pollIntervalSeconds: number;
  orderExpiryMinutes: number;
  lastPolledAt: string | null;
  lastPollStatus: string | null;
}

export interface GoPayMerchantPublicConfig {
  enabled: boolean;
  merchantName: string;
  staticQris: string;
  mutationApiUrl: string;
  hasApiToken: boolean;
  apiTokenMasked: string | null;
  hasWebhookSecret: boolean;
  webhookSecretMasked: string | null;
  pollingEnabled: boolean;
  pollIntervalSeconds: number;
  orderExpiryMinutes: number;
  lastPolledAt: string | null;
  lastPollStatus: string | null;
}

export interface DashboardStats {
  totalReplied: number;
  totalSkipped: number;
  totalSimulated: number;
  activeRuleCount: number;
  totalRuleCount: number;
  activeProductCount: number;
  totalProductCount: number;
  pendingOrdersCount: number;
  paidOrdersCount: number;
  totalRevenue: number;
  availableAccountStockCount: number;
}

export interface AppStateResponse {
  rules: AutoReplyRule[];
  products: ProductItem[];
  settings: BotSettings;
  account: TelegramAccountPublic;
  logs: MessageLogEntry[];
  orders: PaymentOrder[];
  mutations: GoPayMutationEntry[];
  gopayConfig: GoPayMerchantPublicConfig;
  stats: DashboardStats;
}

export interface IncomingMessageInput {
  senderId: string;
  senderName: string;
  senderUsername?: string | null;
  chatId: string;
  chatType: 'private' | 'group';
  text: string;
}

export interface MatchEvaluationResult {
  shouldReply: boolean;
  matchedRule: AutoReplyRule | null;
  matchedProduct: ProductItem | null;
  matchedDefaultReply: boolean;
  renderedReply: string | null;
  reason: string;
  delayMs: number;
  quoteOriginal: boolean;
  cooldownKey: string | null;
}

export interface AdminAuthStatus {
  authenticated: boolean;
  needsSetup: boolean;
  managedByEnv: boolean;
  pinUpdatedAt: string | null;
}
