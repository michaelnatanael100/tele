import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import {
  changeAdminPin,
  clearAuthToken,
  clearLogs,
  connectTelegramSession,
  createProduct,
  createRule,
  deleteProduct,
  deleteRule,
  disconnectTelegram,
  fetchAppState,
  fetchAuthStatus,
  logoutAdmin,
  logoutTelegram,
  runSimulation,
  setAuthToken,
  setUnauthorizedHandler,
  startTelegramLogin,
  updateProduct,
  updateRule,
  updateSettings,
  verifyTelegramOtp,
  verifyTelegramPassword,
} from './api/client';
import { ConnectionSection } from './components/ConnectionSection';
import { ExportSection } from './components/ExportSection';
import { LogsSection } from './components/LogsSection';
import { OverviewSection } from './components/OverviewSection';
import { PaymentSection } from './components/PaymentSection';
import { PinAuthScreen } from './components/PinAuthScreen';
import { ProductModal } from './components/ProductModal';
import { ProductsSection } from './components/ProductsSection';
import { RuleModal } from './components/RuleModal';
import { RulesSection } from './components/RulesSection';
import { SettingsSection } from './components/SettingsSection';
import { Sidebar, type NavSection } from './components/Sidebar';
import { SimulatorSection } from './components/SimulatorSection';
import { TopBar } from './components/TopBar';
import { useTheme } from './utils/theme';
import type {
  AdminAuthStatus,
  AppStateResponse,
  AutoReplyRule,
  BotSettings,
  ProductItem,
} from './shared/types';

export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [authStatus, setAuthStatus] = useState<AdminAuthStatus | null>(null);
  const [authenticated, setAuthenticated] = useState(false);
  const [authChecking, setAuthChecking] = useState(true);

  const [state, setState] = useState<AppStateResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [activeSection, setActiveSection] = useState<NavSection>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [ruleModalOpen, setRuleModalOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<AutoReplyRule | null>(null);
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);
  const [togglingBot, setTogglingBot] = useState(false);

  const checkAuth = useCallback(async () => {
    setAuthChecking(true);
    try {
      const status = await fetchAuthStatus();
      setAuthStatus(status);
      setAuthenticated(status.authenticated);
      setLoadError(null);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Gagal memeriksa status admin.');
    } finally {
      setAuthChecking(false);
    }
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setAuthenticated(false);
      setState(null);
      void checkAuth();
    });
    return () => setUnauthorizedHandler(null);
  }, [checkAuth]);

  useEffect(() => {
    void checkAuth();
  }, [checkAuth]);

  const refreshState = useCallback(async () => {
    try {
      const next = await fetchAppState();
      setState(next);
      setLoadError(null);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Gagal memuat data aplikasi.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authenticated) return;
    setLoading(true);
    void refreshState();
  }, [authenticated, refreshState]);

  // Periodically refresh state when Telegram account is connected so live incoming logs appear
  useEffect(() => {
    if (!authenticated || state?.account.status !== 'connected') return;
    const timer = window.setInterval(() => {
      void refreshState();
    }, 5000);
    return () => window.clearInterval(timer);
  }, [authenticated, state?.account.status, refreshState]);

  const handleAuthenticated = (token: string, nextStatus: AdminAuthStatus) => {
    setAuthToken(token);
    setAuthStatus(nextStatus);
    setAuthenticated(true);
  };

  const handleLogout = async () => {
    try {
      await logoutAdmin();
    } catch {
      // Ignore network errors when locking panel locally
    }
    clearAuthToken();
    setAuthenticated(false);
    setState(null);
    setActiveSection('overview');
    setRuleModalOpen(false);
    setProductModalOpen(false);
    setMobileMenuOpen(false);
    void checkAuth();
  };

  const handleChangePin = async (currentPin: string, newPin: string) => {
    const res = await changeAdminPin(currentPin, newPin);
    setAuthToken(res.token);
    setAuthStatus(res.status);
  };

  const handleToggleGlobalBot = async () => {
    if (!state) return;
    setTogglingBot(true);
    try {
      await updateSettings({ botEnabled: !state.settings.botEnabled });
      await refreshState();
    } finally {
      setTogglingBot(false);
    }
  };

  const handleOpenNewRule = () => {
    setEditingRule(null);
    setRuleModalOpen(true);
  };

  const handleEditRule = (rule: AutoReplyRule) => {
    setEditingRule(rule);
    setRuleModalOpen(true);
  };

  const handleSaveRule = async (
    payload: Omit<AutoReplyRule, 'id' | 'hitCount' | 'createdAt' | 'updatedAt'>,
    existingId?: string
  ) => {
    if (existingId) {
      await updateRule(existingId, payload);
    } else {
      await createRule(payload);
    }
    await refreshState();
  };

  const handleToggleRule = async (rule: AutoReplyRule) => {
    await updateRule(rule.id, { enabled: !rule.enabled });
    await refreshState();
  };

  const handleDeleteRule = async (rule: AutoReplyRule) => {
    await deleteRule(rule.id);
    await refreshState();
  };

  const handleOpenNewProduct = () => {
    setEditingProduct(null);
    setProductModalOpen(true);
  };

  const handleEditProduct = (product: ProductItem) => {
    setEditingProduct(product);
    setProductModalOpen(true);
  };

  const handleSaveProduct = async (
    payload: Omit<ProductItem, 'id' | 'hitCount' | 'createdAt' | 'updatedAt'>,
    existingId?: string
  ) => {
    if (existingId) {
      await updateProduct(existingId, payload);
    } else {
      await createProduct(payload);
    }
    await refreshState();
  };

  const handleToggleProduct = async (product: ProductItem) => {
    await updateProduct(product.id, { autoReplyEnabled: !product.autoReplyEnabled });
    await refreshState();
  };

  const handleDeleteProduct = async (product: ProductItem) => {
    await deleteProduct(product.id);
    await refreshState();
  };

  const handleSaveSettings = async (next: BotSettings) => {
    await updateSettings(next);
    await refreshState();
  };

  const handleRunSimulation = async (payload: {
    senderName: string;
    senderUsername?: string;
    chatType: 'private' | 'group';
    text: string;
    ignoreConstraints?: boolean;
  }) => {
    const res = await runSimulation(payload);
    await refreshState();
    return res.evaluation;
  };

  const handleClearLogs = async () => {
    await clearLogs();
    await refreshState();
  };

  if (authChecking) {
    return (
      <div className="min-h-screen bg-[#F6F8FB] dark:bg-[#060A13] flex items-center justify-center p-6">
        <div className="w-full max-w-md rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-8 space-y-4">
          <div className="h-8 w-40 rounded bg-slate-200 dark:bg-slate-800 animate-pulse" />
          <div className="h-12 w-full rounded-xl bg-slate-100 dark:bg-slate-800/70 animate-pulse" />
          <div className="h-11 w-full rounded-xl bg-slate-200 dark:bg-slate-800 animate-pulse" />
        </div>
      </div>
    );
  }

  if (!authenticated && authStatus) {
    return (
      <MotionConfig reducedMotion="user">
        <PinAuthScreen
          authStatus={authStatus}
          theme={theme}
          onToggleTheme={toggleTheme}
          onAuthenticated={handleAuthenticated}
        />
      </MotionConfig>
    );
  }

  if (loading || (!state && !loadError)) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#060A13] flex">
        <div className="hidden lg:block w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B0F17] p-5 space-y-4">
          <div className="h-6 w-28 rounded bg-slate-200 dark:bg-slate-800 animate-pulse" />
          <div className="space-y-2 pt-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <div key={n} className="h-9 rounded-lg bg-slate-100 dark:bg-slate-800/60 animate-pulse" />
            ))}
          </div>
        </div>
        <div className="flex-1 p-8 space-y-6">
          <div className="h-8 w-56 rounded bg-slate-200 dark:bg-slate-800 animate-pulse" />
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((n) => (
              <div
                key={n}
                className="h-28 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F1624] animate-pulse"
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (loadError || !state) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#060A13] flex items-center justify-center p-6">
        <div className="max-w-md w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 text-center space-y-4">
          <h1 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            Gagal Memuat Aplikasi
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {loadError ?? 'Terjadi kesalahan server.'}
          </p>
          <button
            type="button"
            onClick={() => {
              void checkAuth();
              if (authenticated) void refreshState();
            }}
            className="rounded-lg bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700"
          >
            Coba Lagi
          </button>
        </div>
      </div>
    );
  }

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#F6F8FB] dark:bg-[#060A13] bg-[radial-gradient(circle_at_90%_0%,rgba(14,165,233,0.08),transparent_36%),radial-gradient(circle_at_12%_18%,rgba(99,102,241,0.06),transparent_34%)] dark:bg-[radial-gradient(circle_at_90%_0%,rgba(56,189,248,0.12),transparent_38%),radial-gradient(circle_at_12%_18%,rgba(99,102,241,0.10),transparent_36%)] text-slate-900 dark:text-slate-100 flex transition-colors duration-200">
        <Sidebar
          activeSection={activeSection}
          onSelectSection={setActiveSection}
          account={state.account}
          botEnabled={state.settings.botEnabled}
          mobileOpen={mobileMenuOpen}
          onCloseMobile={() => setMobileMenuOpen(false)}
        />

        <div className="flex-1 min-w-0 flex flex-col">
          <TopBar
            activeSection={activeSection}
            botEnabled={state.settings.botEnabled}
            togglingBot={togglingBot}
            theme={theme}
            onToggleTheme={toggleTheme}
            onToggleBot={handleToggleGlobalBot}
            onOpenNewRule={handleOpenNewRule}
            onOpenMobileMenu={() => setMobileMenuOpen(true)}
            onLogout={() => void handleLogout()}
          />

          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              >
                {activeSection === 'overview' && (
                  <OverviewSection
                    stats={state.stats}
                    rules={state.rules}
                    logs={state.logs}
                    settings={state.settings}
                    account={state.account}
                    onNavigate={setActiveSection}
                    onOpenNewRule={handleOpenNewRule}
                  />
                )}

                {activeSection === 'products' && (
                  <ProductsSection
                    products={state.products}
                    onOpenNewProduct={handleOpenNewProduct}
                    onEditProduct={handleEditProduct}
                    onToggleProduct={handleToggleProduct}
                    onDeleteProduct={handleDeleteProduct}
                  />
                )}

                {activeSection === 'payment' && (
                  <PaymentSection
                    products={state.products}
                    orders={state.orders}
                    mutations={state.mutations}
                    gopayConfig={state.gopayConfig}
                    stats={state.stats}
                    onRefreshState={refreshState}
                    onNavigateProducts={() => setActiveSection('products')}
                  />
                )}

                {activeSection === 'rules' && (
                  <RulesSection
                    rules={state.rules}
                    defaultReplyEnabled={state.settings.defaultReplyEnabled}
                    onOpenNewRule={handleOpenNewRule}
                    onEditRule={handleEditRule}
                    onToggleRule={handleToggleRule}
                    onDeleteRule={handleDeleteRule}
                    onOpenSettings={() => setActiveSection('settings')}
                  />
                )}

                {activeSection === 'simulator' && (
                  <SimulatorSection onRunSimulation={handleRunSimulation} />
                )}

                {activeSection === 'connection' && (
                  <ConnectionSection
                    account={state.account}
                    onStartLogin={async (payload) => {
                      const res = await startTelegramLogin(payload);
                      await refreshState();
                      return res.account;
                    }}
                    onVerifyOtp={async (code) => {
                      const res = await verifyTelegramOtp(code);
                      await refreshState();
                      return res.account;
                    }}
                    onVerifyPassword={async (password) => {
                      const res = await verifyTelegramPassword(password);
                      await refreshState();
                      return res.account;
                    }}
                    onConnectSession={async (payload) => {
                      const res = await connectTelegramSession(payload);
                      await refreshState();
                      return res.account;
                    }}
                    onDisconnect={async () => {
                      const res = await disconnectTelegram();
                      await refreshState();
                      return res.account;
                    }}
                    onLogout={async () => {
                      const res = await logoutTelegram();
                      await refreshState();
                      return res.account;
                    }}
                  />
                )}

                {activeSection === 'logs' && (
                  <LogsSection logs={state.logs} onClearLogs={handleClearLogs} />
                )}

                {activeSection === 'export' && (
                  <ExportSection stats={state.stats} onRestored={refreshState} />
                )}

                {activeSection === 'settings' && authStatus && (
                  <SettingsSection
                    settings={state.settings}
                    authStatus={authStatus}
                    onSaveSettings={handleSaveSettings}
                    onChangePin={handleChangePin}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>

        <RuleModal
          open={ruleModalOpen}
          editingRule={editingRule}
          onClose={() => setRuleModalOpen(false)}
          onSave={handleSaveRule}
        />

        <ProductModal
          open={productModalOpen}
          editingProduct={editingProduct}
          onClose={() => setProductModalOpen(false)}
          onSave={handleSaveProduct}
        />
      </div>
    </MotionConfig>
  );
}
