import type {
  AdminAuthStatus,
  AppStateResponse,
  AutoReplyRule,
  BotSettings,
  DashboardStats,
  GoPayMerchantPublicConfig,
  GoPayMutationEntry,
  MatchEvaluationResult,
  MessageLogEntry,
  PaymentOrder,
  ProductAccountItem,
  ProductItem,
  TelegramAccountPublic,
} from '../shared/types';

let inMemoryAuthToken: string | null = null;
let onUnauthorizedCallback: (() => void) | null = null;

export function setAuthToken(token: string | null): void {
  inMemoryAuthToken = token;
}

export function clearAuthToken(): void {
  inMemoryAuthToken = null;
}

export function setUnauthorizedHandler(handler: (() => void) | null): void {
  onUnauthorizedCallback = handler;
}

interface RequestConfig extends RequestInit {
  skipUnauthorizedHook?: boolean;
}

async function requestJson<T>(url: string, options: RequestConfig = {}): Promise<T> {
  const { skipUnauthorizedHook, headers: customHeaders, ...restOptions } = options;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(customHeaders as Record<string, string> | undefined),
  };

  if (inMemoryAuthToken) {
    headers.Authorization = `Bearer ${inMemoryAuthToken}`;
  }

  const res = await fetch(url, {
    ...restOptions,
    headers,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && !skipUnauthorizedHook) {
      clearAuthToken();
      onUnauthorizedCallback?.();
    }
    const err = new Error(
      typeof data?.error === 'string' ? data.error : 'Permintaan ke server gagal.'
    ) as Error & { fieldErrors?: Record<string, string>; status?: number };
    err.status = res.status;
    if (data?.errors && typeof data.errors === 'object') {
      err.fieldErrors = data.errors as Record<string, string>;
    }
    throw err;
  }
  return data as T;
}

export function fetchAuthStatus(): Promise<AdminAuthStatus> {
  return requestJson<AdminAuthStatus>('/api/auth/status', { skipUnauthorizedHook: true });
}

export function setupAdminPin(pin: string): Promise<{
  token: string;
  expiresAt: number;
  status: AdminAuthStatus;
}> {
  return requestJson('/api/auth/setup', {
    method: 'POST',
    body: JSON.stringify({ pin }),
    skipUnauthorizedHook: true,
  });
}

export function loginWithPin(pin: string): Promise<{
  token: string;
  expiresAt: number;
  status: AdminAuthStatus;
}> {
  return requestJson('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ pin }),
    skipUnauthorizedHook: true,
  });
}

export function logoutAdmin(): Promise<{ status: AdminAuthStatus }> {
  return requestJson('/api/auth/logout', {
    method: 'POST',
    skipUnauthorizedHook: true,
  });
}

export function changeAdminPin(
  currentPin: string,
  newPin: string
): Promise<{
  token: string;
  expiresAt: number;
  status: AdminAuthStatus;
}> {
  return requestJson('/api/auth/change-pin', {
    method: 'POST',
    body: JSON.stringify({ currentPin, newPin }),
    skipUnauthorizedHook: true,
  });
}

export function fetchAppState(): Promise<AppStateResponse> {
  return requestJson<AppStateResponse>('/api/state');
}

export function createRule(
  payload: Omit<AutoReplyRule, 'id' | 'hitCount' | 'createdAt' | 'updatedAt'>
): Promise<{ rule: AutoReplyRule }> {
  return requestJson<{ rule: AutoReplyRule }>('/api/rules', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function updateRule(
  id: string,
  payload: Partial<AutoReplyRule>
): Promise<{ rule: AutoReplyRule }> {
  return requestJson<{ rule: AutoReplyRule }>(`/api/rules/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export function deleteRule(id: string): Promise<{ deletedId: string }> {
  return requestJson<{ deletedId: string }>(`/api/rules/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
}

export function createProduct(
  payload: Omit<ProductItem, 'id' | 'hitCount' | 'createdAt' | 'updatedAt'>
): Promise<{ product: ProductItem }> {
  return requestJson<{ product: ProductItem }>('/api/products', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function updateProduct(
  id: string,
  payload: Partial<ProductItem>
): Promise<{ product: ProductItem }> {
  return requestJson<{ product: ProductItem }>(`/api/products/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export function deleteProduct(id: string): Promise<{ deletedId: string }> {
  return requestJson<{ deletedId: string }>(`/api/products/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
}

export function addProductAccounts(
  productId: string,
  accounts: Pick<ProductAccountItem, 'email' | 'password' | 'extraData'>[]
): Promise<{ product: ProductItem; addedCount: number }> {
  return requestJson<{ product: ProductItem; addedCount: number }>(
    `/api/products/${encodeURIComponent(productId)}/accounts`,
    {
      method: 'POST',
      body: JSON.stringify({ accounts }),
    }
  );
}

export function deleteProductAccount(
  productId: string,
  accountId: string
): Promise<{ product: ProductItem }> {
  return requestJson<{ product: ProductItem }>(
    `/api/products/${encodeURIComponent(productId)}/accounts/${encodeURIComponent(accountId)}`,
    {
      method: 'DELETE',
    }
  );
}

export function updateGopayConfig(payload: {
  enabled?: boolean;
  merchantName?: string;
  staticQris?: string;
  mutationApiUrl?: string;
  apiToken?: string;
  clearApiToken?: boolean;
  webhookSecret?: string;
  pollingEnabled?: boolean;
  pollIntervalSeconds?: number;
  orderExpiryMinutes?: number;
}): Promise<{ gopayConfig: GoPayMerchantPublicConfig; stats: DashboardStats }> {
  return requestJson('/api/payment/gopay/config', {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export function rotateGopayWebhookSecret(): Promise<{
  gopayConfig: GoPayMerchantPublicConfig;
  plainWebhookSecret: string;
}> {
  return requestJson('/api/payment/gopay/rotate-secret', {
    method: 'POST',
  });
}

export function pollGopayMutationsNow(): Promise<{
  result: { ok: boolean; statusMessage: string; processedCount: number; matchedCount: number };
  gopayConfig: GoPayMerchantPublicConfig;
  orders: PaymentOrder[];
  mutations: GoPayMutationEntry[];
  products: ProductItem[];
  stats: DashboardStats;
}> {
  return requestJson('/api/payment/gopay/poll-now', {
    method: 'POST',
  });
}

export function createTestQrisOrder(payload: {
  productId: string;
  buyerName?: string;
}): Promise<{
  order: PaymentOrder;
  qrDataUrl: string;
  invoiceCaption: string;
  orders: PaymentOrder[];
  products: ProductItem[];
  stats: DashboardStats;
}> {
  return requestJson('/api/payment/gopay/test-order', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function simulateGopayMutation(payload: {
  amount?: number;
  notificationText?: string;
  senderName?: string;
}): Promise<{
  outcome: {
    matched: boolean;
    duplicate: boolean;
    mutation: GoPayMutationEntry;
    order?: PaymentOrder;
  };
  orders: PaymentOrder[];
  mutations: GoPayMutationEntry[];
  products: ProductItem[];
  logs: MessageLogEntry[];
  stats: DashboardStats;
}> {
  return requestJson('/api/payment/gopay/simulate-mutation', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function cancelPaymentOrder(orderId: string): Promise<{
  order: PaymentOrder;
  orders: PaymentOrder[];
  products: ProductItem[];
  stats: DashboardStats;
}> {
  return requestJson(`/api/payment/orders/${encodeURIComponent(orderId)}/cancel`, {
    method: 'POST',
  });
}

export function resendPaymentOrder(orderId: string): Promise<{
  order: PaymentOrder;
  orders: PaymentOrder[];
  logs: MessageLogEntry[];
  stats: DashboardStats;
}> {
  return requestJson(`/api/payment/orders/${encodeURIComponent(orderId)}/resend`, {
    method: 'POST',
  });
}

export function updateSettings(payload: Partial<BotSettings>): Promise<{ settings: BotSettings }> {
  return requestJson<{ settings: BotSettings }>('/api/settings', {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export function runSimulation(payload: {
  senderName: string;
  senderUsername?: string;
  chatType: 'private' | 'group';
  text: string;
  ignoreConstraints?: boolean;
}): Promise<{ evaluation: MatchEvaluationResult; logEntry: MessageLogEntry }> {
  return requestJson<{ evaluation: MatchEvaluationResult; logEntry: MessageLogEntry }>(
    '/api/simulate',
    {
      method: 'POST',
      body: JSON.stringify(payload),
    }
  );
}

export function clearLogs(): Promise<{ logs: MessageLogEntry[] }> {
  return requestJson<{ logs: MessageLogEntry[] }>('/api/logs/clear', {
    method: 'POST',
  });
}

export function startTelegramLogin(payload: {
  apiId: number;
  apiHash: string;
  phoneNumber: string;
}): Promise<{ account: TelegramAccountPublic }> {
  return requestJson<{ account: TelegramAccountPublic }>('/api/telegram/login/start', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function verifyTelegramOtp(code: string): Promise<{ account: TelegramAccountPublic }> {
  return requestJson<{ account: TelegramAccountPublic }>('/api/telegram/login/verify-code', {
    method: 'POST',
    body: JSON.stringify({ code }),
  });
}

export function verifyTelegramPassword(
  password: string
): Promise<{ account: TelegramAccountPublic }> {
  return requestJson<{ account: TelegramAccountPublic }>('/api/telegram/login/verify-password', {
    method: 'POST',
    body: JSON.stringify({ password }),
  });
}

export function connectTelegramSession(payload: {
  apiId: number;
  apiHash: string;
  sessionString: string;
}): Promise<{ account: TelegramAccountPublic }> {
  return requestJson<{ account: TelegramAccountPublic }>('/api/telegram/login/session', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function disconnectTelegram(): Promise<{ account: TelegramAccountPublic }> {
  return requestJson<{ account: TelegramAccountPublic }>('/api/telegram/disconnect', {
    method: 'POST',
  });
}

export function logoutTelegram(): Promise<{ account: TelegramAccountPublic }> {
  return requestJson<{ account: TelegramAccountPublic }>('/api/telegram/logout', {
    method: 'POST',
  });
}

async function downloadAuthenticatedFile(url: string, fallbackFilename: string): Promise<void> {
  const headers: Record<string, string> = {};
  if (inMemoryAuthToken) {
    headers.Authorization = `Bearer ${inMemoryAuthToken}`;
  }
  const res = await fetch(url, { headers });
  if (!res.ok) {
    if (res.status === 401) {
      clearAuthToken();
      onUnauthorizedCallback?.();
    }
    const errJson = await res.json().catch(() => ({}));
    throw new Error(
      typeof errJson?.error === 'string' ? errJson.error : 'Gagal mengunduh file dari server.'
    );
  }
  const blob = await res.blob();
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = fallbackFilename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
}

export function downloadCpanelBundle(includeLogs = true): Promise<void> {
  return downloadAuthenticatedFile(
    `/api/export/bundle?includeLogs=${includeLogs ? 'true' : 'false'}`,
    'telebalas-cpanel-siap-pakai.zip'
  );
}

export function downloadDatabaseJson(includeLogs = true): Promise<void> {
  return downloadAuthenticatedFile(
    `/api/export/database.json?includeLogs=${includeLogs ? 'true' : 'false'}`,
    'telebalas-database.json'
  );
}

export function downloadDatabaseSql(): Promise<void> {
  return downloadAuthenticatedFile('/api/export/database.sql', 'telebalas-database.sql');
}

export function downloadPhpInstaller(): Promise<void> {
  return downloadAuthenticatedFile('/api/export/install.php', 'install.php');
}

export function restoreDatabase(payload: unknown): Promise<{
  restoredRulesCount: number;
  restoredProductsCount: number;
}> {
  return requestJson('/api/export/restore-database', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}
