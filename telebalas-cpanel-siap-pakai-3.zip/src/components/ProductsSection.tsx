import { useMemo, useState } from 'react';
import { KeyRound, Pencil, Plus, Search, ShoppingBag, Trash2 } from 'lucide-react';
import {
  formatRupiah,
  getAvailableAccountCount,
  stockStatusLabel,
} from '../shared/autoReplyEngine';
import type { ProductItem, ProductStockStatus } from '../shared/types';

interface ProductsSectionProps {
  products: ProductItem[];
  onOpenNewProduct: () => void;
  onEditProduct: (product: ProductItem) => void;
  onToggleProduct: (product: ProductItem) => Promise<void>;
  onDeleteProduct: (product: ProductItem) => Promise<void>;
}

function stockTextColor(status: ProductStockStatus): string {
  switch (status) {
    case 'tersedia':
      return 'text-emerald-700 dark:text-emerald-400 font-semibold';
    case 'terbatas':
      return 'text-amber-700 dark:text-amber-400 font-semibold';
    case 'habis':
      return 'text-rose-700 dark:text-rose-400 font-semibold';
  }
}

export function ProductsSection({
  products,
  onOpenNewProduct,
  onEditProduct,
  onToggleProduct,
  onDeleteProduct,
}: ProductsSectionProps) {
  const [search, setSearch] = useState('');
  const [stockFilter, setStockFilter] = useState<'all' | ProductStockStatus>('all');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      if (stockFilter !== 'all' && p.stockStatus !== stockFilter) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.keywords.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    });
  }, [products, search, stockFilter]);

  const handleToggle = async (product: ProductItem) => {
    setBusyId(product.id);
    try {
      await onToggleProduct(product);
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async (product: ProductItem) => {
    setBusyId(product.id);
    try {
      await onDeleteProduct(product);
      setConfirmDeleteId(null);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Katalog Produk Jualan
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Tambahkan layanan digital seperti Netflix, Spotify, atau Canva agar bot otomatis
            membalas harga & stok saat ditanya pembeli. Gunakan variabel{' '}
            <code className="font-mono text-xs text-slate-800 dark:text-slate-200 bg-slate-200/70 dark:bg-slate-800 px-1.5 py-0.5 rounded">
              {'{katalog}'}
            </code>{' '}
            di aturan harga.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenNewProduct}
          className="inline-flex items-center gap-2 self-start rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 transition-all whitespace-nowrap"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Tambah Produk</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500"
            aria-hidden="true"
          />
          <label htmlFor="search-products" className="sr-only">
            Cari produk jualan
          </label>
          <input
            id="search-products"
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari produk, kategori, atau kata kunci..."
            className="w-full rounded-xl border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-900 pl-10 pr-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 dark:bg-slate-800/80 p-1 self-start overflow-x-auto max-w-full">
          {(
            [
              { id: 'all', label: `Semua (${products.length})` },
              {
                id: 'tersedia',
                label: `Tersedia (${products.filter((p) => p.stockStatus === 'tersedia').length})`,
              },
              {
                id: 'terbatas',
                label: `Terbatas (${products.filter((p) => p.stockStatus === 'terbatas').length})`,
              },
              {
                id: 'habis',
                label: `Habis (${products.filter((p) => p.stockStatus === 'habis').length})`,
              },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setStockFilter(tab.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                stockFilter === tab.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Product Table */}
      <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
        {filteredProducts.length === 0 ? (
          <div className="p-12 text-center">
            <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
              <ShoppingBag className="h-5 w-5" aria-hidden="true" />
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-slate-100">
              {products.length === 0
                ? 'Belum ada produk jualan yang ditambahkan.'
                : 'Tidak ada produk yang cocok dengan filter pencarian.'}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {products.length === 0
                ? 'Tambahkan produk seperti Netflix, Spotify, atau layanan lainnya untuk balasan otomatis.'
                : 'Coba ubah kata kunci pencarian atau pilih filter "Semua".'}
            </p>
            {products.length === 0 && (
              <button
                type="button"
                onClick={onOpenNewProduct}
                className="mt-4 inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-700"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Tambah Produk Pertama</span>
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 px-5">Produk & Deskripsi</th>
                  <th className="py-3.5 px-4">Harga & Durasi</th>
                  <th className="py-3.5 px-4">Kata Kunci Pemicu</th>
                  <th className="py-3.5 px-4">Stok</th>
                  <th className="py-3.5 px-4 text-right">Terpicu</th>
                  <th className="py-3.5 px-4">Auto-Reply</th>
                  <th className="py-3.5 px-5 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {filteredProducts.map((product) => (
                  <tr
                    key={product.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors align-top"
                  >
                    <td className="py-4 px-5 max-w-xs">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">
                        {product.name}
                      </div>
                      <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                        {product.category}
                        {product.description ? ` · ${product.description}` : ''}
                      </div>
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="font-mono text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                        {formatRupiah(product.price)}
                      </div>
                      <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                        {product.duration}
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="font-mono text-xs text-slate-600 dark:text-slate-400 max-w-[180px] break-words">
                        {product.keywords}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-xs whitespace-nowrap space-y-1">
                      <div className={stockTextColor(product.stockStatus)}>
                        {stockStatusLabel(product.stockStatus)}
                      </div>
                      <button
                        type="button"
                        onClick={() => onEditProduct(product)}
                        className="inline-flex items-center gap-1 text-[11px] font-medium text-sky-700 dark:text-sky-400 hover:underline"
                      >
                        <KeyRound className="h-3 w-3" aria-hidden="true" />
                        <span className="tabular-nums">
                          {getAvailableAccountCount(product)} Akun Siap Kirim
                        </span>
                      </button>
                    </td>
                    <td className="py-4 px-4 text-right font-mono text-xs font-medium text-slate-700 dark:text-slate-300 tabular-nums whitespace-nowrap">
                      {product.hitCount}x
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <button
                        type="button"
                        role="switch"
                        aria-checked={product.autoReplyEnabled}
                        disabled={busyId === product.id}
                        onClick={() => handleToggle(product)}
                        aria-label={`${product.autoReplyEnabled ? 'Nonaktifkan' : 'Aktifkan'} auto-reply produk ${product.name}`}
                        className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300"
                      >
                        <span
                          className={`relative inline-flex h-5 w-9 shrink-0 rounded-full transition-colors duration-150 ${
                            product.autoReplyEnabled
                              ? 'bg-emerald-600'
                              : 'bg-slate-300 dark:bg-slate-700'
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-xs transition-transform duration-150 mt-0.5 ${
                              product.autoReplyEnabled ? 'translate-x-4.5' : 'translate-x-0.5'
                            }`}
                          />
                        </span>
                        <span
                          className={
                            product.autoReplyEnabled
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : 'text-slate-500 dark:text-slate-400'
                          }
                        >
                          {product.autoReplyEnabled ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </button>
                    </td>
                    <td className="py-4 px-5 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditProduct(product)}
                          aria-label={`Edit produk ${product.name}`}
                          className="rounded-lg p-1.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors"
                        >
                          <Pencil className="h-4 w-4" aria-hidden="true" />
                        </button>

                        {confirmDeleteId === product.id ? (
                          <div className="inline-flex items-center gap-1 ml-1">
                            <button
                              type="button"
                              disabled={busyId === product.id}
                              onClick={() => handleDelete(product)}
                              aria-label={`Konfirmasi hapus produk ${product.name}`}
                              className="rounded-lg bg-rose-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-rose-700"
                            >
                              Hapus
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                            >
                              Batal
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(product.id)}
                            aria-label={`Hapus produk ${product.name}`}
                            className="rounded-lg p-1.5 text-slate-500 dark:text-slate-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-700 dark:hover:text-rose-400 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" aria-hidden="true" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
