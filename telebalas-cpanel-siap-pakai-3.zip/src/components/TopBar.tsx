import { Lock, Menu, Moon, Plus, Power, Sun } from 'lucide-react';
import type { NavSection } from './Sidebar';
import type { ThemeMode } from '../utils/theme';

interface TopBarProps {
  activeSection: NavSection;
  botEnabled: boolean;
  togglingBot: boolean;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onToggleBot: () => void;
  onOpenNewRule: () => void;
  onOpenMobileMenu: () => void;
  onLogout: () => void;
}

const SECTION_TITLES: Record<NavSection, string> = {
  overview: 'Ringkasan',
  products: 'Produk Jualan',
  payment: 'QRIS GoPay Merchant',
  rules: 'Aturan Balasan',
  simulator: 'Simulasi Uji',
  connection: 'Koneksi Akun',
  logs: 'Log Aktivitas',
  export: 'Backup & cPanel',
  settings: 'Pengaturan',
};

export function TopBar({
  activeSection,
  botEnabled,
  togglingBot,
  theme,
  onToggleTheme,
  onToggleBot,
  onOpenNewRule,
  onOpenMobileMenu,
  onLogout,
}: TopBarProps) {
  const isDark = theme === 'dark';

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-2 sm:gap-4 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-[#0B101C]/80 backdrop-blur-xl px-3 sm:px-6 lg:px-8 transition-colors duration-200">
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Buka menu navigasi"
          className="lg:hidden rounded-xl p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white shrink-0"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2 text-sm min-w-0">
          <span className="hidden sm:inline text-slate-400 dark:text-slate-500 whitespace-nowrap">
            TeleBalas
          </span>
          <span className="hidden sm:inline text-slate-300 dark:text-slate-700" aria-hidden="true">
            /
          </span>
          <h1 className="font-semibold text-slate-900 dark:text-slate-100 truncate">
            {SECTION_TITLES[activeSection]}
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
        <button
          type="button"
          onClick={onToggleBot}
          disabled={togglingBot}
          aria-pressed={botEnabled}
          aria-label={botEnabled ? 'Auto-Reply Aktif' : 'Auto-Reply Dijeda'}
          className={`inline-flex items-center gap-1.5 sm:gap-2 rounded-xl border px-2.5 sm:px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
            botEnabled
              ? 'border-emerald-200 dark:border-emerald-500/30 bg-gradient-to-r from-emerald-50 to-teal-50/70 dark:from-emerald-950/60 dark:to-teal-950/50 text-emerald-800 dark:text-emerald-300 hover:from-emerald-100 hover:to-teal-100 dark:hover:from-emerald-900/60 dark:hover:to-teal-900/50'
              : 'border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
          }`}
        >
          <Power className="h-3.5 w-3.5 shrink-0" />
          <span className="sm:hidden">{botEnabled ? 'Aktif' : 'Dijeda'}</span>
          <span className="hidden sm:inline">
            {botEnabled ? 'Auto-Reply Aktif' : 'Auto-Reply Dijeda'}
          </span>
        </button>

        <button
          type="button"
          onClick={onOpenNewRule}
          aria-label="Tambah Aturan"
          className="inline-flex items-center gap-1.5 sm:gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-2.5 sm:px-4 py-2 text-xs font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 transition-all whitespace-nowrap shrink-0"
        >
          <Plus className="h-3.5 w-3.5 shrink-0" />
          <span className="sm:hidden">Aturan</span>
          <span className="hidden sm:inline">Tambah Aturan</span>
        </button>

        <button
          type="button"
          id="theme-toggle-btn"
          onClick={onToggleTheme}
          aria-pressed={isDark}
          aria-label={isDark ? 'Aktifkan Mode Terang' : 'Aktifkan Mode Gelap'}
          title={isDark ? 'Ganti ke Mode Terang' : 'Ganti ke Mode Gelap'}
          className="inline-flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
        >
          {isDark ? (
            <Sun className="h-4 w-4 text-amber-400" aria-hidden="true" />
          ) : (
            <Moon className="h-4 w-4 text-slate-600" aria-hidden="true" />
          )}
        </button>

        <button
          type="button"
          onClick={onLogout}
          aria-label="Kunci Panel"
          title="Kunci Admin Panel"
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 sm:px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          <Lock className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span className="hidden md:inline">Kunci Panel</span>
        </button>
      </div>
    </header>
  );
}
