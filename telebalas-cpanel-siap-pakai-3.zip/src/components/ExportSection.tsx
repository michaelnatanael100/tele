import { useRef, useState } from 'react';
import {
  Activity,
  Check,
  Copy,
  Database,
  Download,
  FileArchive,
  FileCode2,
  FolderDown,
  Globe,
  Server,
  Upload,
} from 'lucide-react';
import { motion } from 'motion/react';
import {
  downloadCpanelBundle,
  downloadDatabaseJson,
  downloadDatabaseSql,
  downloadPhpInstaller,
  restoreDatabase,
} from '../api/client';
import type { DashboardStats } from '../shared/types';

interface ExportSectionProps {
  stats: DashboardStats;
  onRestored: () => Promise<void>;
}

const BUNDLE_ITEMS = [
  { name: 'install.php', desc: 'Installer web GUI cPanel Shared Hosting tanpa SSH / Terminal' },
  { name: 'app.cjs', desc: 'Startup Node.js siap jalan di cPanel (Phusion Passenger)' },
  { name: 'dist/', desc: 'Frontend modern (Light & Dark Mode) siap pakai' },
  { name: 'data/store.json', desc: 'Database aturan, produk jualan & pengaturan Anda' },
  { name: 'database/*.json & .sql', desc: 'Cadangan database JSON & SQL (siap import phpMyAdmin)' },
  { name: '/api/keepalive', desc: 'Endpoint watchdog 24/7 untuk Cron Jobs cPanel Shared Hosting' },
];

export function ExportSection({ stats, onRestored }: ExportSectionProps) {
  const [includeLogs, setIncludeLogs] = useState(true);
  const [downloadingBundle, setDownloadingBundle] = useState(false);
  const [downloadingPhp, setDownloadingPhp] = useState(false);
  const [downloadingJson, setDownloadingJson] = useState(false);
  const [downloadingSql, setDownloadingSql] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [copiedCron, setCopiedCron] = useState(false);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const siteOrigin =
    typeof window !== 'undefined' && window.location?.origin
      ? window.location.origin
      : 'https://domain-anda.com';
  const cronCommand = `curl -fsS ${siteOrigin}/api/keepalive >/dev/null 2>&1`;

  const handleDownloadBundle = async () => {
    setNotice(null);
    setDownloadingBundle(true);
    try {
      await downloadCpanelBundle(includeLogs);
      setNotice({
        type: 'success',
        text: 'Paket lengkap cPanel (ZIP + database + install.php) berhasil diunduh.',
      });
    } catch (err) {
      setNotice({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal mengunduh paket lengkap cPanel.',
      });
    } finally {
      setDownloadingBundle(false);
    }
  };

  const handleDownloadPhp = async () => {
    setNotice(null);
    setDownloadingPhp(true);
    try {
      await downloadPhpInstaller();
      setNotice({
        type: 'success',
        text: 'File installer web install.php berhasil diunduh. Upload ke cPanel bersama file ZIP lalu buka domain-anda.com/install.php.',
      });
    } catch (err) {
      setNotice({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal mengunduh file install.php.',
      });
    } finally {
      setDownloadingPhp(false);
    }
  };

  const handleDownloadJson = async () => {
    setNotice(null);
    setDownloadingJson(true);
    try {
      await downloadDatabaseJson(includeLogs);
      setNotice({
        type: 'success',
        text: 'File database JSON (telebalas-database.json) berhasil diunduh.',
      });
    } catch (err) {
      setNotice({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal mengunduh database JSON.',
      });
    } finally {
      setDownloadingJson(false);
    }
  };

  const handleDownloadSql = async () => {
    setNotice(null);
    setDownloadingSql(true);
    try {
      await downloadDatabaseSql();
      setNotice({
        type: 'success',
        text: 'File database SQL (telebalas-database.sql) berhasil diunduh.',
      });
    } catch (err) {
      setNotice({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal mengunduh database SQL.',
      });
    } finally {
      setDownloadingSql(false);
    }
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setNotice(null);
    setRestoring(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as unknown;
      const result = await restoreDatabase(parsed);
      await onRestored();
      setNotice({
        type: 'success',
        text: `Database berhasil dipulihkan: ${result.restoredRulesCount} aturan & ${result.restoredProductsCount} produk jualan dimuat.`,
      });
    } catch (err) {
      setNotice({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'Gagal memulihkan database. Pastikan file berformat JSON TeleBalas yang valid.',
      });
    } finally {
      setRestoring(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleCopyCron = async () => {
    try {
      await navigator.clipboard.writeText(cronCommand);
      setCopiedCron(true);
      window.setTimeout(() => setCopiedCron(false), 1800);
    } catch {
      // Ignore clipboard failures
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
          Backup Database & Installer cPanel
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Unduh paket script lengkap, database, dan file <code className="font-mono">install.php</code>{' '}
          untuk di-install langsung di cPanel Shared Hosting tanpa SSH / Terminal dan aktif 24 jam / 7 hari.
        </p>
      </div>

      {notice && (
        <div
          role={notice.type === 'error' ? 'alert' : 'status'}
          className={`rounded-2xl border px-4 py-3 text-sm font-medium ${
            notice.type === 'error'
              ? 'border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
              : 'border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
          }`}
        >
          {notice.text}
        </div>
      )}

      {/* Primary Hero cPanel Bundle Card */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0B0F17] via-[#101C36] to-[#0E2A4D] p-6 sm:p-7 text-white shadow-xl shadow-slate-900/10 border border-white/10"
      >
        <div
          className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-sky-500/20 blur-3xl"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute -left-16 -bottom-20 h-56 w-56 rounded-full bg-indigo-500/20 blur-3xl"
          aria-hidden="true"
        />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-sky-300">
              <FileArchive className="h-4 w-4" aria-hidden="true" />
              <span>Siap cPanel Shared Hosting — Tanpa SSH / Terminal</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              Unduh Script Lengkap + Database + Web Installer (install.php)
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Berisi {stats.totalRuleCount} aturan balasan, {stats.totalProductCount} produk jualan,{' '}
              <code className="font-mono text-sky-300">install.php</code>, dan mekanisme auto-reconnect
              Telegram 24/7. Upload ke File Manager cPanel, buka{' '}
              <code className="font-mono text-sky-300">/install.php</code> di browser, lalu jalankan{' '}
              <code className="font-mono text-sky-300">app.cjs</code> di Setup Node.js App.
            </p>

            <label className="inline-flex items-center gap-2.5 text-xs text-slate-200 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={includeLogs}
                onChange={(e) => setIncludeLogs(e.target.checked)}
                className="h-4 w-4 rounded border-slate-500 text-sky-500"
              />
              <span>Sertakan riwayat log aktivitas terbaru dalam paket database</span>
            </label>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleDownloadBundle}
              disabled={downloadingBundle}
              className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-gradient-to-r from-sky-500 via-blue-500 to-indigo-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-sky-500/25 hover:from-sky-400 hover:to-indigo-500 disabled:opacity-60 transition-all whitespace-nowrap"
            >
              <FolderDown className="h-4 w-4" aria-hidden="true" />
              <span>
                {downloadingBundle
                  ? 'Menyiapkan Paket ZIP...'
                  : 'Download Paket cPanel (.zip)'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPhp}
              disabled={downloadingPhp}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/10 px-5 py-2.5 text-xs font-semibold text-white hover:bg-white/15 disabled:opacity-60 transition-colors whitespace-nowrap"
            >
              <Globe className="h-3.5 w-3.5 text-sky-300" aria-hidden="true" />
              <span>
                {downloadingPhp ? 'Mengunduh...' : 'Download Web Installer (install.php)'}
              </span>
            </button>
          </div>
        </div>

        <div className="relative z-10 mt-6 pt-5 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {BUNDLE_ITEMS.map((item) => (
            <div
              key={item.name}
              className="rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5"
            >
              <div className="font-mono text-xs font-semibold text-sky-300">{item.name}</div>
              <div className="mt-0.5 text-xs text-slate-300 leading-snug">{item.desc}</div>
            </div>
          ))}
        </div>
      </motion.section>

      {/* Database Download & Restore Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-sky-50 to-indigo-50 dark:from-sky-950/60 dark:to-indigo-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-500/30">
              <Database className="h-4 w-4" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Download Database Terpisah
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Ekspor aturan, katalog produk, dan pengaturan dalam format JSON atau SQL.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 pt-1">
            <button
              type="button"
              onClick={handleDownloadJson}
              disabled={downloadingJson}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-60 transition-colors"
            >
              <Download className="h-3.5 w-3.5 text-sky-600 dark:text-sky-400" aria-hidden="true" />
              <span>
                {downloadingJson ? 'Mengunduh...' : 'Download Database JSON (.json)'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleDownloadSql}
              disabled={downloadingSql}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-60 transition-colors"
            >
              <FileCode2
                className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400"
                aria-hidden="true"
              />
              <span>
                {downloadingSql ? 'Mengunduh...' : 'Download Database SQL (.sql)'}
              </span>
            </button>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/60 dark:to-teal-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-500/30">
              <Upload className="h-4 w-4" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Upload / Restore Database
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Muat ulang aturan & produk dari file backup JSON tanpa menghapus PIN admin Anda.
              </p>
            </div>
          </div>

          <div className="pt-1 flex flex-wrap items-center gap-3">
            <input
              ref={fileInputRef}
              id="restore-database-input"
              type="file"
              accept=".json,application/json"
              onChange={handleRestoreFile}
              className="sr-only"
            />
            <label
              htmlFor="restore-database-input"
              className={`inline-flex cursor-pointer items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2.5 text-xs font-semibold text-white shadow-sm shadow-emerald-600/20 hover:from-emerald-500 hover:to-teal-500 transition-all ${
                restoring ? 'opacity-60 pointer-events-none' : ''
              }`}
            >
              <Upload className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{restoring ? 'Memulihkan Database...' : 'Pilih File Backup (.json)'}</span>
            </label>
          </div>
        </section>
      </div>

      {/* Zero-SSH Shared Hosting Installation + 24/7 Uptime Guide */}
      <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-slate-100 to-slate-200/70 dark:from-slate-800 dark:to-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            <Server className="h-4 w-4" aria-hidden="true" />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Cara Install di cPanel Shared Hosting (Tanpa SSH / Terminal) &amp; Aktif 24 Jam / 7 Hari
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Cukup gunakan File Manager, Setup Node.js App, dan Cron Jobs di GUI cPanel.
            </p>
          </div>
        </div>

        <ol className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          <li className="rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 p-4 space-y-1">
            <div className="font-semibold text-slate-900 dark:text-slate-100">
              1. Upload ZIP &amp; install.php ke File Manager
            </div>
            <p>
              Upload{' '}
              <code className="font-mono text-slate-800 dark:text-sky-300">
                telebalas-cpanel-siap-pakai.zip
              </code>{' '}
              dan{' '}
              <code className="font-mono text-slate-800 dark:text-sky-300">install.php</code> ke
              folder domain/aplikasi Anda, lalu buka{' '}
              <code className="font-mono text-slate-800 dark:text-sky-300">
                https://domain-anda.com/install.php
              </code>{' '}
              lewat browser.
            </p>
          </li>

          <li className="rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 p-4 space-y-1">
            <div className="font-semibold text-slate-900 dark:text-slate-100">
              2. Pasang Otomatis &amp; Hapus install.php
            </div>
            <p>
              Klik <strong>Ekstrak &amp; Pasang TeleBalas Sekarang</strong> untuk mengekstrak seluruh
              script, database <code className="font-mono">data/store.json</code>, dan file{' '}
              <code className="font-mono">.env</code> secara otomatis tanpa Terminal. Lalu klik{' '}
              <strong>Hapus install.php Sekarang</strong>.
            </p>
          </li>

          <li className="rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 p-4 space-y-1">
            <div className="font-semibold text-slate-900 dark:text-slate-100">
              3. Aktifkan di Menu Setup Node.js App
            </div>
            <p>
              Pilih <strong>Node.js 18/20/22</strong>, mode <strong>Production</strong>, Application
              root folder aplikasi Anda, dan startup file{' '}
              <code className="font-mono text-sky-700 dark:text-sky-300 font-semibold">app.cjs</code>.
              Klik <strong>Create</strong>, klik tombol <strong>Run NPM Install</strong>, lalu klik{' '}
              <strong>Restart</strong>.
            </p>
          </li>

          <li className="rounded-xl border border-emerald-200/80 dark:border-emerald-500/30 bg-emerald-50/50 dark:bg-emerald-950/25 p-4 space-y-1.5">
            <div className="flex items-center gap-1.5 font-semibold text-emerald-900 dark:text-emerald-300">
              <Activity className="h-3.5 w-3.5" aria-hidden="true" />
              <span>4. Wajib: Cron Jobs cPanel Agar Bot Aktif 24/7 Non-Stop</span>
            </div>
            <p className="text-slate-700 dark:text-slate-300">
              Di menu <strong>Cron Jobs</strong> cPanel (tanpa SSH), pilih jadwal{' '}
              <strong>Once Per Five Minutes (*/5 * * * *)</strong> lalu masukkan perintah ini agar
              Shared Hosting tidak menidurkan bot:
            </p>
            <div className="mt-1 flex items-center justify-between gap-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-1.5 font-mono text-[11px] text-slate-800 dark:text-sky-300">
              <span className="truncate">{cronCommand}</span>
              <button
                type="button"
                onClick={handleCopyCron}
                aria-label="Salin perintah cron keepalive 24 jam"
                className="inline-flex items-center gap-1 text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 shrink-0"
              >
                {copiedCron ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedCron ? 'Disalin' : 'Salin'}</span>
              </button>
            </div>
          </li>
        </ol>
      </section>
    </div>
  );
}
