import { useState } from 'react';
import { Delete, Eye, EyeOff, KeyRound, Lock, Moon, Send, ShieldCheck, Sun } from 'lucide-react';
import { motion } from 'motion/react';
import { loginWithPin, setupAdminPin } from '../api/client';
import type { AdminAuthStatus } from '../shared/types';
import type { ThemeMode } from '../utils/theme';

interface PinAuthScreenProps {
  authStatus: AdminAuthStatus;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onAuthenticated: (token: string, nextStatus: AdminAuthStatus) => void;
}

const KEYPAD_KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clear', '0', 'back'] as const;

export function PinAuthScreen({
  authStatus,
  theme,
  onToggleTheme,
  onAuthenticated,
}: PinAuthScreenProps) {
  const isDark = theme === 'dark';
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isSetup = authStatus.needsSetup;

  const sanitizePin = (raw: string) => raw.replace(/\D/g, '').slice(0, 8);

  const handleKeypadPress = (key: (typeof KEYPAD_KEYS)[number]) => {
    setError(null);
    if (key === 'clear') {
      setPin('');
      return;
    }
    if (key === 'back') {
      setPin((prev) => prev.slice(0, -1));
      return;
    }
    setPin((prev) => (prev.length < 8 ? prev + key : prev));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!/^\d{4,8}$/.test(pin)) {
      setError('PIN harus terdiri dari 4 hingga 8 digit angka.');
      return;
    }

    if (isSetup && pin !== confirmPin) {
      setError('Konfirmasi PIN tidak sama. Periksa kembali PIN Anda.');
      return;
    }

    setSubmitting(true);
    try {
      const res = isSetup ? await setupAdminPin(pin) : await loginWithPin(pin);
      onAuthenticated(res.token, res.status);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memverifikasi PIN admin.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] dark:bg-[#060A13] bg-[radial-gradient(circle_at_top_left,_rgba(14,165,233,0.16),_transparent_46%),radial-gradient(circle_at_bottom_right,_rgba(99,102,241,0.14),_transparent_44%)] dark:bg-[radial-gradient(circle_at_top_left,_rgba(56,189,248,0.16),_transparent_46%),radial-gradient(circle_at_bottom_right,_rgba(99,102,241,0.16),_transparent_44%)] flex flex-col items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0, y: 14, scale: 0.985 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-xl shadow-slate-900/[0.06] dark:shadow-black/40 overflow-hidden"
      >
        {/* Dark Brand Header with Gradient */}
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0B0F17] via-[#0F172A] to-[#0C2547] px-6 py-6 text-white border-b border-white/[0.08]">
          <div
            className="pointer-events-none absolute -right-10 -top-10 h-36 w-36 rounded-full bg-sky-500/20 blur-2xl"
            aria-hidden="true"
          />

          <div className="relative z-10 flex items-center justify-between gap-3">
            <div className="inline-flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-sky-400 via-sky-500 to-indigo-600 text-white shadow-md shadow-sky-500/30">
                <Send className="h-4 w-4" aria-hidden="true" />
              </span>
              <span
                className="text-lg font-semibold tracking-tight text-white"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                TeleBalas
              </span>
            </div>

            <div className="flex items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-300">
                <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Admin Panel</span>
              </span>
              <button
                type="button"
                id="auth-theme-toggle-btn"
                onClick={onToggleTheme}
                aria-pressed={isDark}
                aria-label={isDark ? 'Aktifkan Mode Terang' : 'Aktifkan Mode Gelap'}
                title={isDark ? 'Ganti ke Mode Terang' : 'Ganti ke Mode Gelap'}
                className="rounded-lg border border-white/15 bg-white/10 p-1.5 text-slate-200 hover:bg-white/20 transition-colors"
              >
                {isDark ? (
                  <Sun className="h-3.5 w-3.5 text-amber-300" aria-hidden="true" />
                ) : (
                  <Moon className="h-3.5 w-3.5 text-sky-200" aria-hidden="true" />
                )}
              </button>
            </div>
          </div>

          <h1 className="relative z-10 mt-4 text-xl font-bold tracking-tight text-white">
            {isSetup ? 'Buat PIN Admin Pertama' : 'Masuk Admin Panel'}
          </h1>
          <p className="relative z-10 mt-1 text-xs text-slate-300 leading-relaxed">
            {isSetup
              ? 'Tetapkan PIN 4–8 digit untuk mengunci akses dashboard bot, aturan balasan, dan katalog produk Anda.'
              : 'Masukkan PIN admin 4–8 digit untuk mengelola auto-reply Telegram dan katalog produk jualan.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              role="alert"
              className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-xs font-medium text-rose-800 dark:text-rose-200"
            >
              {error}
            </motion.div>
          )}

          {authStatus.managedByEnv && !isSetup && (
            <div className="rounded-xl border border-sky-200/80 dark:border-sky-500/25 bg-gradient-to-r from-sky-50 to-indigo-50/70 dark:from-sky-950/50 dark:to-indigo-950/50 px-3.5 py-2.5 text-xs text-sky-900 dark:text-sky-200 flex items-start gap-2">
              <ShieldCheck
                className="h-4 w-4 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5"
                aria-hidden="true"
              />
              <span>
                PIN dikelola melalui environment server (<code className="font-mono">ADMIN_PIN</code>
                ).
              </span>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="admin-pin-input"
                className="text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                {isSetup ? 'PIN Admin Baru (4–8 digit angka)' : 'PIN Admin'}
              </label>
              <button
                type="button"
                onClick={() => setShowPin((v) => !v)}
                className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
              >
                {showPin ? (
                  <>
                    <EyeOff className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Sembunyikan</span>
                  </>
                ) : (
                  <>
                    <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Lihat</span>
                  </>
                )}
              </button>
            </div>

            <div className="relative">
              <KeyRound
                className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500"
                aria-hidden="true"
              />
              <input
                id="admin-pin-input"
                type={showPin ? 'text' : 'password'}
                inputMode="numeric"
                autoComplete={isSetup ? 'new-password' : 'current-password'}
                autoFocus
                value={pin}
                onChange={(e) => {
                  setError(null);
                  setPin(sanitizePin(e.target.value));
                }}
                placeholder="••••••"
                maxLength={8}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 pl-10 pr-4 py-3 text-center font-mono text-lg font-semibold tracking-[0.35em] text-slate-900 dark:text-slate-100 tabular-nums placeholder:tracking-normal placeholder:text-slate-300 dark:placeholder:text-slate-600 transition-shadow focus:border-sky-500"
              />
            </div>
          </div>

          {isSetup ? (
            <div>
              <label
                htmlFor="admin-pin-confirm"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Ulangi PIN Admin
              </label>
              <input
                id="admin-pin-confirm"
                type={showPin ? 'text' : 'password'}
                inputMode="numeric"
                autoComplete="new-password"
                value={confirmPin}
                onChange={(e) => {
                  setError(null);
                  setConfirmPin(sanitizePin(e.target.value));
                }}
                placeholder="Ketik ulang PIN"
                maxLength={8}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-3 text-center font-mono text-lg font-semibold tracking-[0.35em] text-slate-900 dark:text-slate-100 tabular-nums placeholder:tracking-normal placeholder:text-sm placeholder:font-sans placeholder:font-normal placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-2 pt-1" aria-label="Keypad PIN">
              {KEYPAD_KEYS.map((key) => {
                if (key === 'clear') {
                  return (
                    <motion.button
                      key={key}
                      whileTap={{ scale: 0.96 }}
                      type="button"
                      onClick={() => handleKeypadPress(key)}
                      className="rounded-xl border border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-900 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      Bersihkan
                    </motion.button>
                  );
                }
                if (key === 'back') {
                  return (
                    <motion.button
                      key={key}
                      whileTap={{ scale: 0.96 }}
                      type="button"
                      onClick={() => handleKeypadPress(key)}
                      aria-label="Hapus satu digit"
                      className="flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-900 py-2.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Delete className="h-4 w-4" aria-hidden="true" />
                    </motion.button>
                  );
                }
                return (
                  <motion.button
                    key={key}
                    whileTap={{ scale: 0.95 }}
                    type="button"
                    onClick={() => handleKeypadPress(key)}
                    className="rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/80 py-2.5 font-mono text-base font-semibold text-slate-800 dark:text-slate-100 hover:border-sky-300 dark:hover:border-sky-500/50 hover:bg-sky-50/40 dark:hover:bg-sky-950/40 transition-colors tabular-nums"
                  >
                    {key}
                  </motion.button>
                );
              })}
            </div>
          )}

          <motion.button
            whileTap={{ scale: 0.985 }}
            type="submit"
            disabled={submitting}
            className="w-full rounded-xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 px-4 py-3 text-sm font-semibold text-white shadow-md shadow-sky-600/25 hover:from-sky-600 hover:to-indigo-700 disabled:opacity-60 transition-all"
          >
            {submitting
              ? 'Memproses...'
              : isSetup
                ? 'Simpan PIN & Masuk Dashboard'
                : 'Buka Admin Panel'}
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
}
