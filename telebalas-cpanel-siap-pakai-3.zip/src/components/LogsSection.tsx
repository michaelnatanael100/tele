import { useMemo, useState } from 'react';
import { Search, Trash2 } from 'lucide-react';
import type { LogOutcome, MessageLogEntry } from '../shared/types';

interface LogsSectionProps {
  logs: MessageLogEntry[];
  onClearLogs: () => Promise<void>;
}

function formatDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '-';
  return date.toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function renderOutcome(outcome: LogOutcome) {
  switch (outcome) {
    case 'replied':
      return <span className="text-emerald-700 dark:text-emerald-400 font-medium">Terkirim</span>;
    case 'simulated':
      return <span className="text-sky-700 dark:text-sky-400 font-medium">Simulasi</span>;
    case 'skipped':
      return <span className="text-amber-700 dark:text-amber-400 font-medium">Dilewati</span>;
    case 'failed':
      return <span className="text-rose-700 dark:text-rose-400 font-medium">Gagal</span>;
  }
}

export function LogsSection({ logs, onClearLogs }: LogsSectionProps) {
  const [search, setSearch] = useState('');
  const [outcomeFilter, setOutcomeFilter] = useState<'all' | LogOutcome>('all');
  const [clearing, setClearing] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return logs.filter((entry) => {
      if (outcomeFilter !== 'all' && entry.outcome !== outcomeFilter) return false;
      if (!q) return true;
      return (
        entry.senderName.toLowerCase().includes(q) ||
        entry.incomingText.toLowerCase().includes(q) ||
        (entry.matchedRuleName ?? '').toLowerCase().includes(q) ||
        entry.reason.toLowerCase().includes(q)
      );
    });
  }, [logs, search, outcomeFilter]);

  const handleClear = async () => {
    setClearing(true);
    try {
      await onClearLogs();
    } finally {
      setClearing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Log Aktivitas Bot
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Riwayat pesan masuk, hasil pencocokan aturan, dan balasan otomatis yang dikirim.
          </p>
        </div>

        {logs.length > 0 && (
          <button
            type="button"
            disabled={clearing}
            onClick={handleClear}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap self-start sm:self-auto"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>{clearing ? 'Membersihkan...' : 'Bersihkan Log'}</span>
          </button>
        )}
      </div>

      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500"
            aria-hidden="true"
          />
          <label htmlFor="search-logs" className="sr-only">
            Cari log aktivitas
          </label>
          <input
            id="search-logs"
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari pengirim, isi pesan, atau aturan..."
            className="w-full rounded-xl border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-900 pl-10 pr-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-xl bg-slate-200/70 dark:bg-slate-800/80 p-1 self-start">
          {(
            [
              { id: 'all', label: 'Semua' },
              { id: 'replied', label: 'Terkirim' },
              { id: 'simulated', label: 'Simulasi' },
              { id: 'skipped', label: 'Dilewati' },
              { id: 'failed', label: 'Gagal' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setOutcomeFilter(tab.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                outcomeFilter === tab.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-sm text-slate-500 dark:text-slate-400">
            {logs.length === 0
              ? 'Belum ada log aktivitas. Coba jalankan simulasi atau sambungkan akun Telegram.'
              : 'Tidak ada entri log yang sesuai filter.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 px-5">Waktu</th>
                  <th className="py-3.5 px-4">Pengirim</th>
                  <th className="py-3.5 px-4">Pesan Masuk & Balasan</th>
                  <th className="py-3.5 px-4">Aturan / Keterangan</th>
                  <th className="py-3.5 px-5">Hasil</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {filtered.map((entry) => (
                  <tr
                    key={entry.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors align-top"
                  >
                    <td className="py-4 px-5 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
                      {formatDateTime(entry.timestamp)}
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {entry.senderName}
                      </div>
                      <div className="text-xs text-slate-400 dark:text-slate-500">
                        {entry.senderUsername ? `@${entry.senderUsername}` : entry.senderId} ·{' '}
                        {entry.chatType === 'private' ? 'Pribadi' : 'Grup'}
                      </div>
                    </td>
                    <td className="py-4 px-4 max-w-md space-y-1.5">
                      <div className="text-slate-900 dark:text-slate-100">{entry.incomingText}</div>
                      {entry.replyText && (
                        <div className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-700/80 rounded-lg px-3 py-2 whitespace-pre-line">
                          Balasan: {entry.replyText}
                        </div>
                      )}
                    </td>
                    <td className="py-4 px-4 max-w-xs">
                      <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        {entry.matchedRuleName ?? '-'}
                      </div>
                      <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                        {entry.reason}
                      </div>
                    </td>
                    <td className="py-4 px-5 text-xs whitespace-nowrap">
                      {renderOutcome(entry.outcome)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
