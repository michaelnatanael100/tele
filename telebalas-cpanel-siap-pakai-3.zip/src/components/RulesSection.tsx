import { useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2 } from 'lucide-react';
import type { AutoReplyRule, MatchType } from '../shared/types';

interface RulesSectionProps {
  rules: AutoReplyRule[];
  defaultReplyEnabled: boolean;
  onOpenNewRule: () => void;
  onEditRule: (rule: AutoReplyRule) => void;
  onToggleRule: (rule: AutoReplyRule) => Promise<void>;
  onDeleteRule: (rule: AutoReplyRule) => Promise<void>;
  onOpenSettings: () => void;
}

const MATCH_TYPE_LABELS: Record<MatchType, string> = {
  exact: 'Persis sama',
  contains: 'Mengandung',
  starts_with: 'Diawali',
  regex: 'Regex',
  all_incoming: 'Semua pesan',
};

const SCOPE_LABELS: Record<AutoReplyRule['chatScope'], string> = {
  private: 'Pribadi',
  group: 'Grup',
  all: 'Semua',
};

export function RulesSection({
  rules,
  defaultReplyEnabled,
  onOpenNewRule,
  onEditRule,
  onToggleRule,
  onDeleteRule,
  onOpenSettings,
}: RulesSectionProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const filteredRules = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...rules]
      .sort((a, b) => a.priority - b.priority)
      .filter((rule) => {
        if (statusFilter === 'active' && !rule.enabled) return false;
        if (statusFilter === 'inactive' && rule.enabled) return false;
        if (!q) return true;
        return (
          rule.name.toLowerCase().includes(q) ||
          rule.pattern.toLowerCase().includes(q) ||
          rule.replyText.toLowerCase().includes(q)
        );
      });
  }, [rules, search, statusFilter]);

  const handleToggle = async (rule: AutoReplyRule) => {
    setBusyId(rule.id);
    try {
      await onToggleRule(rule);
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async (rule: AutoReplyRule) => {
    setBusyId(rule.id);
    try {
      await onDeleteRule(rule);
      setConfirmDeleteId(null);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Aturan Auto-Reply
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Aturan dievaluasi berurutan dari angka prioritas terkecil. Mendukung variabel{' '}
          <code className="font-mono text-xs text-slate-800 dark:text-slate-200 bg-slate-200/70 dark:bg-slate-800 px-1.5 py-0.5 rounded">
            {'{nama}'}
          </code>
          ,{' '}
          <code className="font-mono text-xs text-slate-800 dark:text-slate-200 bg-slate-200/70 dark:bg-slate-800 px-1.5 py-0.5 rounded">
            {'{waktu}'}
          </code>
          , dan{' '}
          <code className="font-mono text-xs text-slate-800 dark:text-slate-200 bg-slate-200/70 dark:bg-slate-800 px-1.5 py-0.5 rounded">
            {'{pesan}'}
          </code>
          .
        </p>
      </div>

      {/* Default Catch-All Fallback Info */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-2xl border border-sky-200/80 dark:border-sky-500/25 bg-gradient-to-r from-sky-50/80 to-indigo-50/60 dark:from-sky-950/45 dark:to-indigo-950/45 px-5 py-3.5">
        <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
          <span className="font-semibold text-slate-900 dark:text-slate-100">
            Balasan Default Semua Pesan:{' '}
            <span
              className={
                defaultReplyEnabled
                  ? 'text-emerald-700 dark:text-emerald-400'
                  : 'text-slate-500 dark:text-slate-400'
              }
            >
              {defaultReplyEnabled ? 'Aktif' : 'Nonaktif'}
            </span>
          </span>{' '}
          —{' '}
          {defaultReplyEnabled
            ? 'Jika tidak ada aturan atau produk yang cocok (termasuk saat daftar aturan kosong), semua pesan masuk dalam kata apa pun tetap dibalas otomatis.'
            : 'Saat ini pesan yang tidak cocok dengan aturan atau produk akan dilewati.'}
        </div>
        <button
          type="button"
          onClick={onOpenSettings}
          className="self-start sm:self-auto rounded-xl border border-sky-200 dark:border-sky-500/30 bg-white dark:bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-sky-700 dark:text-sky-300 hover:bg-sky-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
        >
          Atur Balasan Default
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500"
            aria-hidden="true"
          />
          <label htmlFor="search-rules" className="sr-only">
            Cari aturan balasan
          </label>
          <input
            id="search-rules"
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama aturan, kata kunci, atau balasan..."
            className="w-full rounded-xl border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-900 pl-10 pr-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 dark:bg-slate-800/80 p-1 self-start">
          {(
            [
              { id: 'all', label: `Semua (${rules.length})` },
              { id: 'active', label: `Aktif (${rules.filter((r) => r.enabled).length})` },
              { id: 'inactive', label: `Nonaktif (${rules.filter((r) => !r.enabled).length})` },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setStatusFilter(tab.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === tab.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rules Table */}
      <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
        {filteredRules.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {rules.length === 0
                ? 'Belum ada aturan auto-reply yang dibuat.'
                : 'Tidak ada aturan yang cocok dengan pencarian Anda.'}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {rules.length === 0
                ? 'Tambahkan aturan kata kunci pertama untuk membalas pesan Telegram secara otomatis.'
                : 'Coba ubah kata kunci pencarian atau pilih filter "Semua".'}
            </p>
            {rules.length === 0 && (
              <button
                type="button"
                onClick={onOpenNewRule}
                className="mt-4 inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-700"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Tambah Aturan Pertama</span>
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 px-5">Prioritas</th>
                  <th className="py-3.5 px-4">Aturan & Balasan</th>
                  <th className="py-3.5 px-4">Pemicu</th>
                  <th className="py-3.5 px-4">Cakupan</th>
                  <th className="py-3.5 px-4 text-right">Terpicu</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-5 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {filteredRules.map((rule) => (
                  <tr
                    key={rule.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors align-top"
                  >
                    <td className="py-4 px-5 font-mono text-xs font-medium text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
                      #{rule.priority}
                    </td>
                    <td className="py-4 px-4 max-w-sm">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">
                        {rule.name}
                      </div>
                      <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 line-clamp-2 whitespace-pre-line leading-relaxed">
                        {rule.replyText}
                      </p>
                      <div className="mt-2 flex items-center gap-2 text-xs text-slate-400 dark:text-slate-500 tabular-nums">
                        <span>Jeda {rule.delayMs} ms</span>
                        <span aria-hidden="true">·</span>
                        <span>Cooldown {rule.cooldownSeconds} dtk</span>
                        {rule.quoteOriginal && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>Quote reply</span>
                          </>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="text-xs font-medium text-slate-700 dark:text-slate-300">
                        {MATCH_TYPE_LABELS[rule.matchType]}
                      </div>
                      <div className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400 max-w-[190px] truncate">
                        {rule.matchType === 'all_incoming' ? 'Semua pesan' : rule.pattern}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-xs text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {SCOPE_LABELS[rule.chatScope]}
                    </td>
                    <td className="py-4 px-4 text-right font-mono text-xs font-medium text-slate-700 dark:text-slate-300 tabular-nums whitespace-nowrap">
                      {rule.hitCount}x
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <button
                        type="button"
                        role="switch"
                        aria-checked={rule.enabled}
                        disabled={busyId === rule.id}
                        onClick={() => handleToggle(rule)}
                        aria-label={`${rule.enabled ? 'Nonaktifkan' : 'Aktifkan'} aturan ${rule.name}`}
                        className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300"
                      >
                        <span
                          className={`relative inline-flex h-5 w-9 shrink-0 rounded-full transition-colors duration-150 ${
                            rule.enabled ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-xs transition-transform duration-150 mt-0.5 ${
                              rule.enabled ? 'translate-x-4.5' : 'translate-x-0.5'
                            }`}
                          />
                        </span>
                        <span
                          className={
                            rule.enabled
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : 'text-slate-500 dark:text-slate-400'
                          }
                        >
                          {rule.enabled ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </button>
                    </td>
                    <td className="py-4 px-5 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditRule(rule)}
                          aria-label={`Edit aturan ${rule.name}`}
                          className="rounded-lg p-1.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>

                        {confirmDeleteId === rule.id ? (
                          <div className="inline-flex items-center gap-1 ml-1">
                            <button
                              type="button"
                              disabled={busyId === rule.id}
                              onClick={() => handleDelete(rule)}
                              aria-label={`Konfirmasi hapus aturan ${rule.name}`}
                              className="rounded-lg bg-rose-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-rose-700"
                            >
                              Hapus
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                            >
                              Batal
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(rule.id)}
                            aria-label={`Hapus aturan ${rule.name}`}
                            className="rounded-lg p-1.5 text-slate-500 dark:text-slate-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-700 dark:hover:text-rose-400 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
