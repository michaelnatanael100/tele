import { useState } from 'react';
import { CheckCircle2, KeyRound, LogOut, Smartphone, Unplug } from 'lucide-react';
import type { TelegramAccountPublic } from '../shared/types';

interface ConnectionSectionProps {
  account: TelegramAccountPublic;
  onStartLogin: (payload: {
    apiId: number;
    apiHash: string;
    phoneNumber: string;
  }) => Promise<TelegramAccountPublic>;
  onVerifyOtp: (code: string) => Promise<TelegramAccountPublic>;
  onVerifyPassword: (password: string) => Promise<TelegramAccountPublic>;
  onConnectSession: (payload: {
    apiId: number;
    apiHash: string;
    sessionString: string;
  }) => Promise<TelegramAccountPublic>;
  onDisconnect: () => Promise<TelegramAccountPublic>;
  onLogout: () => Promise<TelegramAccountPublic>;
}

export function ConnectionSection({
  account,
  onStartLogin,
  onVerifyOtp,
  onVerifyPassword,
  onConnectSession,
  onDisconnect,
  onLogout,
}: ConnectionSectionProps) {
  const [authTab, setAuthTab] = useState<'phone' | 'session'>('phone');
  const [apiId, setApiId] = useState(account.apiId ? String(account.apiId) : '');
  const [apiHash, setApiHash] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [twoFactorPassword, setTwoFactorPassword] = useState('');
  const [sessionString, setSessionString] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartPhone = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericId = Number(apiId.trim());
    if (!Number.isInteger(numericId) || numericId <= 0) {
      setError('API ID harus berupa angka valid dari my.telegram.org.');
      return;
    }
    if (!apiHash.trim()) {
      setError('API Hash wajib diisi.');
      return;
    }
    if (!phoneNumber.trim()) {
      setError('Nomor telepon Telegram wajib diisi (misal +628123456789).');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onStartLogin({
        apiId: numericId,
        apiHash: apiHash.trim(),
        phoneNumber: phoneNumber.trim(),
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memulai koneksi Telegram.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode.trim()) {
      setError('Masukkan kode OTP yang dikirim ke aplikasi Telegram Anda.');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onVerifyOtp(otpCode.trim());
      setOtpCode('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verifikasi kode OTP gagal.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!twoFactorPassword) {
      setError('Masukkan kata sandi verifikasi dua langkah (2FA) akun Telegram Anda.');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onVerifyPassword(twoFactorPassword);
      setTwoFactorPassword('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verifikasi 2FA gagal.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSessionConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericId = Number(apiId.trim());
    if (!Number.isInteger(numericId) || numericId <= 0) {
      setError('API ID wajib berupa angka positif.');
      return;
    }
    if (!apiHash.trim() || !sessionString.trim()) {
      setError('API Hash dan StringSession wajib diisi.');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onConnectSession({
        apiId: numericId,
        apiHash: apiHash.trim(),
        sessionString: sessionString.trim(),
      });
      setSessionString('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal menghubungkan StringSession.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDisconnect = async () => {
    setError(null);
    setSubmitting(true);
    try {
      await onDisconnect();
    } finally {
      setSubmitting(false);
    }
  };

  const handleLogout = async () => {
    setError(null);
    setSubmitting(true);
    try {
      await onLogout();
    } finally {
      setSubmitting(false);
    }
  };

  const displayError = error || account.errorMessage;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Koneksi Akun Telegram Pribadi
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Hubungkan akun Telegram pribadi Anda melalui protokol MTProto agar bot dapat menerima
          dan membalas pesan secara langsung 24 jam / 7 hari.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section className="lg:col-span-7 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          {account.status === 'connected' ? (
            <div className="space-y-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {[account.firstName, account.lastName].filter(Boolean).join(' ') ||
                        'Akun Telegram Terhubung'}
                    </h3>
                    <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-mono space-x-2">
                      {account.username && <span>@{account.username}</span>}
                      {account.phoneMasked && <span>· {account.phoneMasked}</span>}
                      {account.telegramId && <span>· ID {account.telegramId}</span>}
                    </div>
                  </div>
                </div>
                <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                  Aktif 24/7
                </span>
              </div>

              <p className="text-sm text-slate-600 dark:text-slate-300">
                Bot sedang aktif memantau pesan masuk di akun pribadi Anda dengan reconnect otomatis
                24 jam dan akan membalas sesuai daftar aturan serta jadwal yang diaktifkan.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={handleDisconnect}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <Unplug className="h-4 w-4" />
                  <span>Putuskan Sementara</span>
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={handleLogout}
                  className="inline-flex items-center gap-2 rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-2 text-sm font-medium text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/50"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Keluar & Hapus Sesi</span>
                </button>
              </div>
            </div>
          ) : account.status === 'awaiting_code' ? (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Masukkan Kode Verifikasi OTP
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Telegram telah mengirimkan kode login 5 digit ke aplikasi Telegram pada nomor{' '}
                <span className="font-mono font-medium text-slate-900 dark:text-slate-100">
                  {account.phoneMasked ?? 'Anda'}
                </span>
                .
              </p>

              {displayError && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
                >
                  {displayError}
                </div>
              )}

              <div>
                <label
                  htmlFor="tg-otp-code"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Kode OTP Telegram
                </label>
                <input
                  id="tg-otp-code"
                  type="text"
                  inputMode="numeric"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="12345"
                  className="w-full max-w-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-base font-mono tracking-widest text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="rounded-xl bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-sky-600/20 hover:bg-sky-700 disabled:opacity-60"
                >
                  {submitting ? 'Memverifikasi...' : 'Verifikasi Kode'}
                </button>
                <button
                  type="button"
                  onClick={handleDisconnect}
                  className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Batalkan
                </button>
              </div>
            </form>
          ) : account.status === 'awaiting_password' ? (
            <form onSubmit={handleVerifyPassword} className="space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Verifikasi Dua Langkah (2FA)
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Akun Telegram Anda dilindungi kata sandi cloud (2FA). Masukkan kata sandi untuk
                menyelesaikan proses masuk.
              </p>

              {displayError && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
                >
                  {displayError}
                </div>
              )}

              <div>
                <label
                  htmlFor="tg-2fa-password"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Kata Sandi 2FA Telegram
                </label>
                <input
                  id="tg-2fa-password"
                  type="password"
                  value={twoFactorPassword}
                  onChange={(e) => setTwoFactorPassword(e.target.value)}
                  className="w-full max-w-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="rounded-xl bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-sky-600/20 hover:bg-sky-700 disabled:opacity-60"
                >
                  {submitting ? 'Memproses...' : 'Masuk Sekarang'}
                </button>
                <button
                  type="button"
                  onClick={handleDisconnect}
                  className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Batalkan
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-5">
              <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 dark:bg-slate-800/80 p-1 w-fit">
                <button
                  type="button"
                  onClick={() => {
                    setAuthTab('phone');
                    setError(null);
                  }}
                  className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    authTab === 'phone'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Smartphone className="h-3.5 w-3.5" />
                  <span>Nomor HP & OTP</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthTab('session');
                    setError(null);
                  }}
                  className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    authTab === 'session'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <KeyRound className="h-3.5 w-3.5" />
                  <span>StringSession</span>
                </button>
              </div>

              {displayError && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
                >
                  {displayError}
                </div>
              )}

              {authTab === 'phone' ? (
                <form onSubmit={handleStartPhone} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="tg-api-id"
                        className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                      >
                        API ID
                      </label>
                      <input
                        id="tg-api-id"
                        type="text"
                        inputMode="numeric"
                        value={apiId}
                        onChange={(e) => setApiId(e.target.value)}
                        placeholder="Contoh: 12345678"
                        className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="tg-api-hash"
                        className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                      >
                        API Hash
                      </label>
                      <input
                        id="tg-api-hash"
                        type="password"
                        value={apiHash}
                        onChange={(e) => setApiHash(e.target.value)}
                        placeholder={account.apiHashMasked ?? '32 karakter heksadesimal'}
                        className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="tg-phone"
                      className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                    >
                      Nomor Telepon Akun Telegram
                    </label>
                    <input
                      id="tg-phone"
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="+6281234567890"
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting || account.status === 'connecting'}
                    className="rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-sky-600/20 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all"
                  >
                    {submitting || account.status === 'connecting'
                      ? 'Mengirim Permintaan OTP...'
                      : 'Kirim Kode OTP'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleSessionConnect} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="tg-sess-api-id"
                        className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                      >
                        API ID
                      </label>
                      <input
                        id="tg-sess-api-id"
                        type="text"
                        inputMode="numeric"
                        value={apiId}
                        onChange={(e) => setApiId(e.target.value)}
                        placeholder="Contoh: 12345678"
                        className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="tg-sess-api-hash"
                        className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                      >
                        API Hash
                      </label>
                      <input
                        id="tg-sess-api-hash"
                        type="password"
                        value={apiHash}
                        onChange={(e) => setApiHash(e.target.value)}
                        placeholder="32 karakter heksadesimal"
                        className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="tg-string-session"
                      className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                    >
                      GramJS StringSession
                    </label>
                    <textarea
                      id="tg-string-session"
                      rows={3}
                      value={sessionString}
                      onChange={(e) => setSessionString(e.target.value)}
                      placeholder="1BQANOTEu..."
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-sky-600/20 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all"
                  >
                    {submitting ? 'Menghubungkan...' : 'Hubungkan StringSession'}
                  </button>
                </form>
              )}
            </div>
          )}
        </section>

        <aside className="lg:col-span-5 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Cara Mendapatkan API ID & API Hash
          </h3>
          <ol className="space-y-3 text-sm text-slate-600 dark:text-slate-300 list-decimal pl-4">
            <li>
              Buka situs resmi{' '}
              <span className="font-mono text-xs text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                my.telegram.org
              </span>{' '}
              dan login dengan nomor HP akun Telegram pribadi Anda.
            </li>
            <li>
              Pilih menu{' '}
              <span className="font-semibold text-slate-800 dark:text-slate-100">
                API development tools
              </span>
              .
            </li>
            <li>
              Buat aplikasi baru (isi nama dan shortname bebas, pilih platform{' '}
              <span className="font-medium text-slate-800 dark:text-slate-100">Desktop</span>).
            </li>
            <li>
              Salin{' '}
              <span className="font-semibold text-slate-800 dark:text-slate-100">App api_id</span>{' '}
              dan{' '}
              <span className="font-semibold text-slate-800 dark:text-slate-100">App api_hash</span>{' '}
              lalu masukkan ke formulir di samping.
            </li>
          </ol>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Kredensial API Hash dan StringSession disimpan khusus di server lokal aplikasi dan tidak
            pernah dikirim kembali ke browser dalam teks terbuka.
          </div>
        </aside>
      </div>
    </div>
  );
}
