import { useState } from 'react';
import { CheckCheck, Send } from 'lucide-react';
import { motion } from 'motion/react';
import type { MatchEvaluationResult } from '../shared/types';

interface SimulatorSectionProps {
  onRunSimulation: (payload: {
    senderName: string;
    senderUsername?: string;
    chatType: 'private' | 'group';
    text: string;
    ignoreConstraints?: boolean;
  }) => Promise<MatchEvaluationResult>;
}

const PRESET_MESSAGES = [
  'Halo',
  'Kak, Netflix 1 bulan ready?',
  'Spotify ready?',
  'Info katalog harga dong',
  'Permisi kak mau tanya apapun bebas',
];

export function SimulatorSection({ onRunSimulation }: SimulatorSectionProps) {
  const [senderName, setSenderName] = useState('Budi Santoso');
  const [senderUsername, setSenderUsername] = useState('budisantoso');
  const [chatType, setChatType] = useState<'private' | 'group'>('private');
  const [text, setText] = useState('Kak, info harga paketnya dong');
  const [ignoreConstraints, setIgnoreConstraints] = useState(true);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastSubmittedText, setLastSubmittedText] = useState<string | null>(null);
  const [result, setResult] = useState<MatchEvaluationResult | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      setError('Isi pesan simulasi tidak boleh kosong.');
      return;
    }
    setError(null);
    setRunning(true);
    try {
      const evalResult = await onRunSimulation({
        senderName: senderName.trim() || 'Pengguna Uji',
        senderUsername: senderUsername.trim() || undefined,
        chatType,
        text: text.trim(),
        ignoreConstraints,
      });
      setLastSubmittedText(text.trim());
      setResult(evalResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Simulasi gagal dijalankan.');
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Simulasi Uji Balasan
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Uji bagaimana aturan Anda merespon pesan masuk sebelum menghubungkan akun Telegram pribadi.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section className="lg:col-span-6 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div
                role="alert"
                className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
              >
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="sim-sender-name"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Nama Pengirim
                </label>
                <input
                  id="sim-sender-name"
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label
                  htmlFor="sim-sender-username"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Username Telegram
                </label>
                <input
                  id="sim-sender-username"
                  type="text"
                  value={senderUsername}
                  onChange={(e) => setSenderUsername(e.target.value)}
                  placeholder="tanpa @"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="sim-chat-type"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Sumber Pesan
              </label>
              <select
                id="sim-chat-type"
                value={chatType}
                onChange={(e) => setChatType(e.target.value as 'private' | 'group')}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              >
                <option value="private">Chat Pribadi (DM)</option>
                <option value="group">Grup Telegram</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="sim-text"
                  className="text-xs font-semibold text-slate-700 dark:text-slate-300"
                >
                  Isi Pesan Masuk
                </label>
                <span className="text-xs text-slate-400 dark:text-slate-500">
                  Contoh cepat di bawah
                </span>
              </div>
              <textarea
                id="sim-text"
                rows={3}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Ketik pesan seolah-olah dikirim ke Telegram pribadi Anda..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {PRESET_MESSAGES.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setText(preset)}
                    className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <label className="inline-flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-400 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={ignoreConstraints}
                onChange={(e) => setIgnoreConstraints(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-sky-600"
              />
              <span>Abaikan jadwal jam aktif & cooldown anti-spam saat pengujian berulang</span>
            </label>

            <div className="pt-2">
              <button
                type="submit"
                disabled={running}
                className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all"
              >
                <Send className="h-4 w-4" />
                <span>{running ? 'Menguji...' : 'Uji Balasan'}</span>
              </button>
            </div>
          </form>
        </section>

        <section className="lg:col-span-6 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
          <div className="border-b border-slate-100 dark:border-slate-800 px-6 py-4 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Pratinjau & Hasil Evaluasi
            </h3>
            {result && (
              <span
                className={`text-xs font-semibold ${
                  result.shouldReply
                    ? 'text-emerald-700 dark:text-emerald-400'
                    : 'text-amber-700 dark:text-amber-400'
                }`}
              >
                {result.shouldReply ? 'Balasan Terkirim' : 'Tidak Membalas'}
              </span>
            )}
          </div>

          {!result ? (
            <div className="p-12 text-center text-sm text-slate-500 dark:text-slate-400">
              Jalankan uji pesan di sebelah kiri untuk melihat aturan mana yang cocok dan hasil
              interpolasi balasannya.
            </div>
          ) : (
            <div className="p-6 space-y-5">
              {/* Authentic Telegram-inspired chat preview */}
              <div className="rounded-xl bg-[#EBF1F7] dark:bg-[#09111E] border border-slate-200/80 dark:border-slate-800 p-5 space-y-4">
                <div className="flex flex-col items-start">
                  <span className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                    {senderName || 'Pengirim'} ({chatType === 'private' ? 'Pribadi' : 'Grup'})
                  </span>
                  <div className="max-w-[85%] rounded-2xl rounded-tl-xs border border-slate-200/80 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-900 dark:text-slate-100 shadow-2xs">
                    {lastSubmittedText}
                  </div>
                </div>

                {result.shouldReply && result.renderedReply ? (
                  <motion.div
                    key={lastSubmittedText + result.renderedReply}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                    className="flex flex-col items-end"
                  >
                    <span className="text-xs font-medium text-sky-700 dark:text-sky-400 mb-1.5">
                      Akun Anda (Auto-Reply)
                    </span>
                    <div className="max-w-[85%] rounded-2xl rounded-tr-xs bg-gradient-to-br from-sky-600 via-blue-600 to-indigo-600 px-4 py-2.5 text-sm text-white shadow-sm shadow-sky-600/20 whitespace-pre-line">
                      <p>{result.renderedReply}</p>
                      <div className="mt-1 flex items-center justify-end gap-1 text-[11px] text-sky-100 tabular-nums">
                        <span>Baru saja</span>
                        <CheckCheck className="h-3.5 w-3.5" aria-hidden="true" />
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="text-xs text-slate-500 dark:text-slate-400 italic text-right pt-1">
                    Tidak ada balasan otomatis yang dikirim.
                  </div>
                )}
              </div>

              {/* Diagnostics */}
              <dl className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                <div className="py-2.5 flex items-center justify-between gap-4">
                  <dt className="text-slate-500 dark:text-slate-400">Aturan / Produk Terpilih</dt>
                  <dd className="font-semibold text-slate-900 dark:text-slate-100 text-right">
                    {result.matchedRule
                      ? result.matchedRule.name
                      : result.matchedProduct
                        ? `Produk: ${result.matchedProduct.name}`
                        : result.matchedDefaultReply
                          ? 'Balasan Default (Semua Pesan)'
                          : 'Tidak ada'}
                  </dd>
                </div>
                <div className="py-2.5 flex items-center justify-between gap-4">
                  <dt className="text-slate-500 dark:text-slate-400">Alasan Evaluasi</dt>
                  <dd className="text-slate-800 dark:text-slate-200 text-right">{result.reason}</dd>
                </div>
                {result.shouldReply && (
                  <div className="py-2.5 flex items-center justify-between gap-4">
                    <dt className="text-slate-500 dark:text-slate-400">Jeda Ketik & Kutip</dt>
                    <dd className="font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums">
                      {result.delayMs} ms · {result.quoteOriginal ? 'Kutip pesan' : 'Pesan biasa'}
                    </dd>
                  </div>
                )}
              </dl>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
