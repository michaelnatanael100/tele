import { useEffect, useState } from 'react';
import { KeyRound, Plus, Trash2, Upload, X } from 'lucide-react';
import { motion } from 'motion/react';
import {
  validateProductAccountInput,
  validateProductInput,
} from '../shared/autoReplyEngine';
import type { ProductAccountItem, ProductItem, ProductStockStatus } from '../shared/types';

interface ProductModalProps {
  open: boolean;
  editingProduct: ProductItem | null;
  onClose: () => void;
  onSave: (
    payload: Omit<ProductItem, 'id' | 'hitCount' | 'createdAt' | 'updatedAt'>,
    existingId?: string
  ) => Promise<void>;
}

const DEFAULT_TEMPLATE =
  'Halo {nama}, produk *{produk}* ({durasi}) tersedia dengan harga *{harga}* [{stok}].\n\nDetail:\n{deskripsi}\n\nBalas pesan ini dengan "order {produk}" jika ingin langsung bayar via QRIS GoPay!';

const STOCK_OPTIONS: { value: ProductStockStatus; label: string }[] = [
  { value: 'tersedia', label: 'Tersedia (Ready)' },
  { value: 'terbatas', label: 'Stok Terbatas' },
  { value: 'habis', label: 'Stok Habis' },
];

export function ProductModal({ open, editingProduct, onClose, onSave }: ProductModalProps) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Streaming');
  const [price, setPrice] = useState<number>(35000);
  const [duration, setDuration] = useState('1 Bulan');
  const [stockStatus, setStockStatus] = useState<ProductStockStatus>('tersedia');
  const [keywords, setKeywords] = useState('');
  const [description, setDescription] = useState('');
  const [replyTemplate, setReplyTemplate] = useState(DEFAULT_TEMPLATE);
  const [autoReplyEnabled, setAutoReplyEnabled] = useState(true);
  const [accounts, setAccounts] = useState<ProductAccountItem[]>([]);

  const [bulkMode, setBulkMode] = useState(false);
  const [accEmail, setAccEmail] = useState('');
  const [accPassword, setAccPassword] = useState('');
  const [accExtraData, setAccExtraData] = useState('');
  const [bulkText, setBulkText] = useState('');
  const [accError, setAccError] = useState<string | null>(null);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (editingProduct) {
      setName(editingProduct.name);
      setCategory(editingProduct.category);
      setPrice(editingProduct.price);
      setDuration(editingProduct.duration);
      setStockStatus(editingProduct.stockStatus);
      setKeywords(editingProduct.keywords);
      setDescription(editingProduct.description);
      setReplyTemplate(editingProduct.replyTemplate);
      setAutoReplyEnabled(editingProduct.autoReplyEnabled);
      setAccounts(Array.isArray(editingProduct.accounts) ? editingProduct.accounts : []);
    } else {
      setName('');
      setCategory('Streaming');
      setPrice(35000);
      setDuration('1 Bulan');
      setStockStatus('tersedia');
      setKeywords('');
      setDescription('');
      setReplyTemplate(DEFAULT_TEMPLATE);
      setAutoReplyEnabled(true);
      setAccounts([]);
    }
    setBulkMode(false);
    setAccEmail('');
    setAccPassword('');
    setAccExtraData('');
    setBulkText('');
    setAccError(null);
    setErrors({});
    setSubmitError(null);
  }, [open, editingProduct]);

  if (!open) return null;

  const insertVariable = (token: string) => {
    setReplyTemplate((prev) => (prev ? `${prev} ${token}` : token));
  };

  const handleAddSingleAccount = () => {
    const check = validateProductAccountInput({
      email: accEmail,
      password: accPassword,
      extraData: accExtraData,
    });
    if (!check.valid) {
      setAccError(Object.values(check.errors)[0] || 'Data akun tidak valid.');
      return;
    }

    const newItem: ProductAccountItem = {
      id: `acc_local_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      email: accEmail.trim(),
      password: accPassword.trim(),
      extraData: accExtraData.trim(),
      status: 'available',
      soldToOrderId: null,
      soldAt: null,
      createdAt: new Date().toISOString(),
    };

    setAccounts((prev) => [newItem, ...prev]);
    if (stockStatus === 'habis') setStockStatus('tersedia');
    setAccEmail('');
    setAccPassword('');
    setAccExtraData('');
    setAccError(null);
  };

  const handleAddBulkAccounts = () => {
    const lines = bulkText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
    if (lines.length === 0) {
      setAccError('Tempel minimal satu baris format email|password|data lain.');
      return;
    }

    const parsedItems: ProductAccountItem[] = [];
    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split('|').map((p) => p.trim());
      const email = parts[0] ?? '';
      const password = parts[1] ?? '';
      const extraData = parts.slice(2).join(' | ');
      const check = validateProductAccountInput({ email, password, extraData });
      if (!check.valid) {
        setAccError(`Baris ke-${i + 1}: ${Object.values(check.errors)[0]}`);
        return;
      }
      parsedItems.push({
        id: `acc_bulk_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 5)}`,
        email,
        password,
        extraData,
        status: 'available',
        soldToOrderId: null,
        soldAt: null,
        createdAt: new Date().toISOString(),
      });
    }

    setAccounts((prev) => [...parsedItems, ...prev]);
    if (stockStatus === 'habis') setStockStatus('tersedia');
    setBulkText('');
    setAccError(null);
    setBulkMode(false);
  };

  const handleRemoveAccount = (accountId: string) => {
    setAccounts((prev) => prev.filter((a) => a.id !== accountId));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate,
    });

    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    setSubmitError(null);
    setSaving(true);
    try {
      await onSave(
        {
          name: name.trim(),
          category: category.trim(),
          price: Math.round(Number(price) || 0),
          duration: duration.trim(),
          stockStatus,
          keywords: keywords.trim(),
          description: description.trim(),
          replyTemplate: replyTemplate.trim(),
          autoReplyEnabled,
          accounts,
        },
        editingProduct?.id
      );
      onClose();
    } catch (err) {
      const typedErr = err as Error & { fieldErrors?: Record<string, string> };
      if (typedErr.fieldErrors) setErrors(typedErr.fieldErrors);
      setSubmitError(typedErr.message || 'Gagal menyimpan produk.');
    } finally {
      setSaving(false);
    }
  };

  const availableCount = accounts.filter((a) => a.status === 'available').length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-modal-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.97, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-xl"
      >
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 px-6 py-4">
          <h2
            id="product-modal-title"
            className="text-base font-bold text-slate-900 dark:text-slate-100"
          >
            {editingProduct ? 'Edit Produk & Stok Akun' : 'Tambah Produk Jualan Baru'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup dialog produk"
            className="rounded-xl p-1.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {submitError && (
            <div
              role="alert"
              className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
            >
              {submitError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="product-name"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Nama Produk
              </label>
              <input
                id="product-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Misal: Netflix Premium 4K"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              {errors.name && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.name}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="product-category"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Kategori
              </label>
              <input
                id="product-category"
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="Misal: Streaming, Musik, Desain"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              {errors.category && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.category}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label
                htmlFor="product-price"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Harga (Rp)
              </label>
              <input
                id="product-price"
                type="number"
                min={0}
                step={500}
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
              />
              {errors.price && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.price}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="product-duration"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Durasi / Paket
              </label>
              <input
                id="product-duration"
                type="text"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="1 Bulan"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              {errors.duration && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.duration}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="product-stock"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Status Stok
              </label>
              <select
                id="product-stock"
                value={stockStatus}
                onChange={(e) => setStockStatus(e.target.value as ProductStockStatus)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              >
                {STOCK_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Account Credentials Auto-Delivery Stock Manager */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-sky-100 dark:bg-sky-950/70 text-sky-700 dark:text-sky-400">
                  <KeyRound className="h-4 w-4" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    Stok Detail Akun Otomatis ({availableCount} siap kirim · {accounts.length} total)
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Email, password, dan data lain dikirim otomatis ke pembeli begitu mutasi QRIS GoPay masuk.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setBulkMode((v) => !v);
                  setAccError(null);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{bulkMode ? 'Mode Input Satuan' : 'Tambah Massal'}</span>
              </button>
            </div>

            {accError && (
              <div className="rounded-lg border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 text-xs text-rose-700 dark:text-rose-300">
                {accError}
              </div>
            )}

            {bulkMode ? (
              <div className="space-y-2.5">
                <label
                  htmlFor="bulk-accounts-input"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  Paste Daftar Akun (1 baris = 1 akun, pisahkan dengan tanda{' '}
                  <code className="font-mono">|</code>)
                </label>
                <textarea
                  id="bulk-accounts-input"
                  rows={4}
                  value={bulkText}
                  onChange={(e) => setBulkText(e.target.value)}
                  placeholder={`user1@email.com|Pass123|Profil 1 • PIN 1122\nuser2@email.com|Pass456|Profil 2 • PIN 3344`}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400"
                />
                <button
                  type="button"
                  onClick={handleAddBulkAccounts}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-slate-900 dark:bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:hover:bg-sky-500"
                >
                  <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Tambahkan Semua Baris</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                <div className="sm:col-span-4">
                  <label
                    htmlFor="acc-email"
                    className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Email / Username
                  </label>
                  <input
                    id="acc-email"
                    type="text"
                    value={accEmail}
                    onChange={(e) => setAccEmail(e.target.value)}
                    placeholder="akun@domain.com"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label
                    htmlFor="acc-password"
                    className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Password
                  </label>
                  <input
                    id="acc-password"
                    type="text"
                    value={accPassword}
                    onChange={(e) => setAccPassword(e.target.value)}
                    placeholder="SandiAkun123"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label
                    htmlFor="acc-extra"
                    className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Data Lain (PIN/Profil/Link)
                  </label>
                  <input
                    id="acc-extra"
                    type="text"
                    value={accExtraData}
                    onChange={(e) => setAccExtraData(e.target.value)}
                    placeholder="Profil 1 · PIN 4455"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div className="sm:col-span-2">
                  <button
                    type="button"
                    onClick={handleAddSingleAccount}
                    className="w-full inline-flex items-center justify-center gap-1 rounded-xl bg-slate-900 dark:bg-sky-600 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:hover:bg-sky-500 whitespace-nowrap"
                  >
                    <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Tambah</span>
                  </button>
                </div>
              </div>
            )}

            {accounts.length > 0 ? (
              <div className="max-h-44 overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B111E] divide-y divide-slate-100 dark:divide-slate-800">
                {accounts.map((acc) => (
                  <div
                    key={acc.id}
                    className="flex items-center justify-between gap-3 px-3.5 py-2.5 text-xs"
                  >
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {acc.email || '(Tanpa Email)'}
                        </span>
                        {acc.password && (
                          <span className="font-mono text-slate-600 dark:text-slate-400">
                            · {acc.password}
                          </span>
                        )}
                      </div>
                      {acc.extraData && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {acc.extraData}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`text-[11px] font-semibold ${
                          acc.status === 'available'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : acc.status === 'reserved'
                              ? 'text-amber-700 dark:text-amber-400'
                              : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {acc.status === 'available'
                          ? 'Siap Kirim'
                          : acc.status === 'reserved'
                            ? 'Dipesan'
                            : 'Terjual'}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveAccount(acc.id)}
                        aria-label={`Hapus akun ${acc.email || acc.extraData}`}
                        className="rounded-lg p-1 text-slate-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-600 dark:hover:text-rose-400"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400 italic">
                Belum ada stok detail akun. Tambahkan di atas agar pembayaran QRIS GoPay langsung
                mengirim akun ke pembeli.
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="product-keywords"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Kata Kunci Pemicu Produk (pisahkan dengan koma)
            </label>
            <input
              id="product-keywords"
              type="text"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              placeholder="Misal: netflix, nf, netflik"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
            />
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Ketik nama produk untuk melihat detail, atau awali dengan{' '}
              <code className="font-mono">order</code> / <code className="font-mono">beli</code>{' '}
              (misal: <code className="font-mono">order netflix</code>) untuk langsung terbit QRIS GoPay.
            </p>
            {errors.keywords && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.keywords}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="product-description"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Deskripsi / Keunggulan Produk
            </label>
            <input
              id="product-description"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Misal: Private 1 profil, garansi penuh 30 hari, anti-hold."
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
            />
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <label
                htmlFor="product-template"
                className="text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Template Balasan Info Produk
              </label>
              <div className="flex flex-wrap items-center gap-1.5">
                {['{produk}', '{harga}', '{durasi}', '{stok}', '{deskripsi}', '{nama}'].map(
                  (tok) => (
                    <button
                      key={tok}
                      type="button"
                      onClick={() => insertVariable(tok)}
                      className="rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2 py-0.5 font-mono text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                    >
                      {tok}
                    </button>
                  )
                )}
              </div>
            </div>
            <textarea
              id="product-template"
              rows={4}
              value={replyTemplate}
              onChange={(e) => setReplyTemplate(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
            />
            {errors.replyTemplate && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">
                {errors.replyTemplate}
              </p>
            )}
          </div>

          <label className="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={autoReplyEnabled}
              onChange={(e) => setAutoReplyEnabled(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-sky-600"
            />
            <span>Aktifkan auto-reply & sertakan di variabel {'{katalog}'}</span>
          </label>

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all whitespace-nowrap"
            >
              {saving
                ? 'Menyimpan...'
                : editingProduct
                  ? 'Simpan Perubahan'
                  : 'Simpan Produk'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
