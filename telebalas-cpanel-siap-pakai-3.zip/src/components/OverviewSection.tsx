import {
  ArrowRight,
  CheckCircle2,
  Circle,
  FlaskConical,
  HardDriveDownload,
  MessageSquareReply,
  QrCode,
  Send,
  ShieldCheck,
  ShoppingBag,
  SlidersHorizontal,
  Wifi,
} from 'lucide-react';
import { motion } from 'motion/react';
import type {
  AutoReplyRule,
  BotSettings,
  DashboardStats,
  MessageLogEntry,
  TelegramAccountPublic,
} from '../shared/types';
import type { NavSection } from './Sidebar';

interface OverviewSectionProps {
  stats: DashboardStats;
  rules: AutoReplyRule[];
  logs: MessageLogEntry[];
  settings: BotSettings;
  account: TelegramAccountPublic;
  onNavigate: (section: NavSection) => void;
  onOpenNewRule: () => void;
}

function formatTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '-';
  return date.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function outcomeLabel(outcome: MessageLogEntry['outcome']): { text: string; className: string } {
  switch (outcome) {
    case 'replied':
      return { text: 'Terkirim', className: 'text-emerald-700 dark:text-emerald-400 font-semibold' };
    case 'simulated':
      return { text: 'Simulasi', className: 'text-sky-700 dark:text-sky-400 font-semibold' };
    case 'skipped':
      return { text: 'Dilewati', className: 'text-amber-700 dark:text-amber-400 font-semibold' };
    case 'failed':
      return { text: 'Gagal', className: 'text-rose-700 dark:text-rose-400 font-semibold' };
  }
}

export function OverviewSection({
  stats,
  rules,
  logs,
  settings,
  account,
  onNavigate,
  onOpenNewRule,
}: OverviewSectionProps) {
  const isConnected = account.status === 'connected';
  const topRules = [...rules].sort((a, b) => b.hitCount - a.hitCount).slice(0, 4);
  const recentLogs = logs.slice(0, 5);

  const checklist = [
    {
      done: isConnected,
      title: 'Hubungkan akun Telegram pribadi',
      desc: 'Masuk dengan API ID, API Hash, dan kode OTP atau StringSession.',
      actionLabel: isConnected ? 'Lihat Koneksi' : 'Hubungkan Akun',
      onClick: () => onNavigate('connection'),
    },
    {
      done: stats.activeRuleCount > 0,
      title: 'Aktifkan minimal satu aturan balasan',
      desc: 'Tentukan kata kunci pemicu, variabel nama, dan jeda anti-spam.',
      actionLabel: 'Kelola Aturan',
      onClick: () => onNavigate('rules'),
    },
    {
      done: stats.totalSimulated > 0,
      title: 'Uji skenario balasan di simulator',
      desc: 'Pastikan prioritas aturan dan template pesan sesuai harapan.',
      actionLabel: 'Buka Simulator',
      onClick: () => onNavigate('simulator'),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Sleek Gradient Hero Operational Strip */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0B0F17] via-[#101B34] to-[#0E294D] p-6 text-white shadow-xl shadow-slate-900/10 border border-white/10"
      >
        <div
          className="pointer-events-none absolute -right-14 -top-16 h-56 w-56 rounded-full bg-sky-500/20 blur-3xl"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute left-1/3 -bottom-20 h-44 w-44 rounded-full bg-indigo-500/20 blur-3xl"
          aria-hidden="true"
        />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-sky-300 font-medium">
              <span>Mode grup: {settings.ignoreGroupsByDefault ? 'Diabaikan' : 'Diizinkan'}</span>
              <span className="text-white/25" aria-hidden="true">
                ·
              </span>
              <span>
                Jadwal:{' '}
                {settings.schedule.enabled
                  ? `${settings.schedule.startTime}–${settings.schedule.endTime} WIB`
                  : '24 Jam / 7 Hari Non-Stop'}
              </span>
            </div>
            <h2 className="mt-2 text-2xl font-bold tracking-tight text-white">
              Ringkasan Bot Akun Pribadi
            </h2>
            <p className="mt-1 text-sm text-slate-300 max-w-2xl">
              Pantau koneksi Telegram, aturan balasan otomatis, katalog produk jualan, serta ekspor
              paket siap upload cPanel dari satu tempat.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('products')}
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-xs font-semibold text-white hover:bg-white/15 transition-colors whitespace-nowrap"
            >
              <ShoppingBag className="h-3.5 w-3.5 text-sky-300" aria-hidden="true" />
              <span>Produk Jualan</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('payment')}
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-xs font-semibold text-white hover:bg-white/15 transition-colors whitespace-nowrap"
            >
              <QrCode className="h-3.5 w-3.5 text-emerald-300" aria-hidden="true" />
              <span>QRIS GoPay</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('export')}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-md shadow-sky-500/25 hover:from-sky-400 hover:to-indigo-500 transition-all whitespace-nowrap"
            >
              <HardDriveDownload className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Download cPanel & DB</span>
            </button>
          </div>
        </div>
      </motion.section>

      {/* 4-column modern KPI strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22, delay: 0.03 }}
          className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none hover:-translate-y-0.5 hover:shadow-md hover:shadow-slate-900/[0.04] dark:hover:border-slate-700 transition-all duration-200"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Koneksi Telegram
            </span>
            <span
              className={`flex h-8 w-8 items-center justify-center rounded-xl border ${
                isConnected
                  ? 'bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/60 dark:to-teal-950/60 border-emerald-100 dark:border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                  : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-700 text-slate-400 dark:text-slate-500'
              }`}
            >
              <Wifi className="h-4 w-4" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-3 text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100 font-display">
            {isConnected ? 'Terhubung' : 'Belum Terhubung'}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 truncate">
            {isConnected
              ? `${account.firstName ?? 'Akun'} (${account.phoneMasked ?? 'Aktif'})`
              : 'Siap dihubungkan via MTProto'}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22, delay: 0.06 }}
          className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none hover:-translate-y-0.5 hover:shadow-md hover:shadow-slate-900/[0.04] dark:hover:border-slate-700 transition-all duration-200"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Aturan Aktif
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-sky-50 to-indigo-50 dark:from-sky-950/60 dark:to-indigo-950/60 border border-sky-100 dark:border-sky-500/30 text-sky-600 dark:text-sky-400">
              <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-3 text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {stats.activeRuleCount}
            <span className="text-base font-normal text-slate-400 dark:text-slate-500">
              {' '}
              / {stats.totalRuleCount}
            </span>
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {stats.activeProductCount} dari {stats.totalProductCount} produk jualan aktif
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22, delay: 0.09 }}
          className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none hover:-translate-y-0.5 hover:shadow-md hover:shadow-slate-900/[0.04] dark:hover:border-slate-700 transition-all duration-200"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Balasan Terkirim
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/60 dark:to-teal-950/60 border border-emerald-100 dark:border-emerald-500/30 text-emerald-600 dark:text-emerald-400">
              <Send className="h-4 w-4" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-3 text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {stats.totalReplied}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {stats.totalSimulated} uji simulasi tercatat
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22, delay: 0.12 }}
          className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none hover:-translate-y-0.5 hover:shadow-md hover:shadow-slate-900/[0.04] dark:hover:border-slate-700 transition-all duration-200"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Pesan Dilewati
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/60 dark:to-orange-950/60 border border-amber-100 dark:border-amber-500/30 text-amber-600 dark:text-amber-400">
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-3 text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {stats.totalSkipped}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Karena cooldown, grup, atau jadwal
          </div>
        </motion.div>
      </div>

      {/* Two-column operational grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section className="lg:col-span-5 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 px-5 py-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Langkah Persiapan
            </h3>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 tabular-nums">
              {checklist.filter((c) => c.done).length}/{checklist.length} selesai
            </span>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {checklist.map((step) => (
              <div key={step.title} className="flex items-start justify-between gap-4 px-5 py-4">
                <div className="flex items-start gap-3 min-w-0">
                  {step.done ? (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  ) : (
                    <Circle className="mt-0.5 h-4 w-4 text-slate-300 dark:text-slate-600 shrink-0" />
                  )}
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      {step.title}
                    </div>
                    <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={step.onClick}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-sky-700 dark:text-sky-400 hover:text-sky-800 dark:hover:text-sky-300 whitespace-nowrap shrink-0 py-1"
                >
                  <span>{step.actionLabel}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 px-5 py-3.5 flex items-center gap-3 bg-slate-50/70 dark:bg-slate-900/60 overflow-x-auto">
            <button
              type="button"
              onClick={onOpenNewRule}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white whitespace-nowrap shrink-0"
            >
              <MessageSquareReply className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
              <span>Buat aturan baru</span>
            </button>
            <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">
              ·
            </span>
            <button
              type="button"
              onClick={() => onNavigate('products')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
              <span>Kelola produk</span>
            </button>
            <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">
              ·
            </span>
            <button
              type="button"
              onClick={() => onNavigate('simulator')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white whitespace-nowrap shrink-0"
            >
              <FlaskConical className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
              <span>Uji di simulator</span>
            </button>
          </div>
        </section>

        <section className="lg:col-span-7 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 px-5 py-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Aturan Paling Sering Terpicu
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('rules')}
              className="text-xs font-semibold text-sky-700 dark:text-sky-400 hover:text-sky-800 dark:hover:text-sky-300 whitespace-nowrap"
            >
              Lihat semua aturan
            </button>
          </div>
          {topRules.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              Belum ada aturan balasan. Klik "Tambah Aturan" untuk memulai.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-5">Nama Aturan</th>
                    <th className="py-3 px-4">Kata Kunci</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-5 text-right">Terpicu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                  {topRules.map((rule) => (
                    <tr
                      key={rule.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-5 font-medium text-slate-900 dark:text-slate-100">
                        {rule.name}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-400 max-w-[200px] truncate">
                        {rule.matchType === 'all_incoming' ? 'Semua pesan' : rule.pattern}
                      </td>
                      <td className="py-3.5 px-4 text-xs">
                        <span
                          className={
                            rule.enabled
                              ? 'text-emerald-700 dark:text-emerald-400 font-semibold'
                              : 'text-slate-500 dark:text-slate-400'
                          }
                        >
                          {rule.enabled ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </td>
                      <td className="py-3.5 px-5 text-right font-mono text-xs font-medium text-slate-700 dark:text-slate-300 tabular-nums">
                        {rule.hitCount}x
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>

      {/* Recent Logs */}
      <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 px-5 py-4">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Aktivitas Terakhir
          </h3>
          <button
            type="button"
            onClick={() => onNavigate('logs')}
            className="text-xs font-semibold text-sky-700 dark:text-sky-400 hover:text-sky-800 dark:hover:text-sky-300 whitespace-nowrap"
          >
            Buka log lengkap
          </button>
        </div>

        {recentLogs.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500 dark:text-slate-400">
            Belum ada aktivitas pesan masuk yang tercatat.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-3 px-5">Waktu</th>
                  <th className="py-3 px-4">Pengirim</th>
                  <th className="py-3 px-4">Pesan Masuk</th>
                  <th className="py-3 px-4">Aturan</th>
                  <th className="py-3 px-5">Hasil</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {recentLogs.map((log) => {
                  const statusInfo = outcomeLabel(log.outcome);
                  return (
                    <tr
                      key={log.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-5 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
                        {formatTime(log.timestamp)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-900 dark:text-slate-100 font-medium whitespace-nowrap">
                        {log.senderName}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                        {log.incomingText}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-400 whitespace-nowrap">
                        {log.matchedRuleName ?? '-'}
                      </td>
                      <td className="py-3.5 px-5 text-xs whitespace-nowrap">
                        <span className={statusInfo.className}>{statusInfo.text}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
