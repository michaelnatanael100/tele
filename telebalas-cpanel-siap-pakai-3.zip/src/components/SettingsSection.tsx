import { useEffect, useState } from 'react';
import { KeyRound, MessageSquareReply, Save } from 'lucide-react';
import { DEFAULT_FALLBACK_REPLY_TEXT } from '../shared/autoReplyEngine';
import type { AdminAuthStatus, BotSettings } from '../shared/types';

interface SettingsSectionProps {
  settings: BotSettings;
  authStatus: AdminAuthStatus;
  onSaveSettings: (next: BotSettings) => Promise<void>;
  onChangePin: (currentPin: string, newPin: string) => Promise<void>;
}

function listToText(items: string[]): string {
  return items.join(', ');
}

function textToList(raw: string): string[] {
  return raw
    .split(/[\n,]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

interface SwitchRowProps {
  id: string;
  title: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

function SwitchRow({ id, title, description, checked, onChange }: SwitchRowProps) {
  return (
    <div className="flex items-start justify-between gap-4 py-1">
      <label htmlFor={id} className="cursor-pointer">
        <div className="text-sm font-medium text-slate-900 dark:text-slate-100">{title}</div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
          {description}
        </div>
      </label>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full transition-colors duration-150 ${
          checked ? 'bg-sky-600' : 'bg-slate-300 dark:bg-slate-700'
        }`}
      >
        <span
          className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-xs transition-transform duration-150 mt-0.5 ${
            checked ? 'translate-x-5.5' : 'translate-x-0.5'
          }`}
        />
      </button>
    </div>
  );
}

export function SettingsSection({
  settings,
  authStatus,
  onSaveSettings,
  onChangePin,
}: SettingsSectionProps) {
  const [botEnabled, setBotEnabled] = useState(settings.botEnabled);
  const [defaultReplyEnabled, setDefaultReplyEnabled] = useState(settings.defaultReplyEnabled);
  const [defaultReplyText, setDefaultReplyText] = useState(
    settings.defaultReplyText || DEFAULT_FALLBACK_REPLY_TEXT
  );
  const [ignoreGroupsByDefault, setIgnoreGroupsByDefault] = useState(
    settings.ignoreGroupsByDefault
  );
  const [ignoreContactsInWhitelistOnly, setIgnoreContactsInWhitelistOnly] = useState(
    settings.ignoreContactsInWhitelistOnly
  );
  const [whitelistText, setWhitelistText] = useState(listToText(settings.whitelist));
  const [blacklistText, setBlacklistText] = useState(listToText(settings.blacklist));
  const [defaultCooldownSeconds, setDefaultCooldownSeconds] = useState(
    settings.defaultCooldownSeconds
  );
  const [typingIndicator, setTypingIndicator] = useState(settings.typingIndicator);
  const [scheduleEnabled, setScheduleEnabled] = useState(settings.schedule.enabled);
  const [startTime, setStartTime] = useState(settings.schedule.startTime);
  const [endTime, setEndTime] = useState(settings.schedule.endTime);
  const [timezoneOffsetMinutes, setTimezoneOffsetMinutes] = useState(
    settings.schedule.timezoneOffsetMinutes
  );

  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmNewPin, setConfirmNewPin] = useState('');
  const [changingPin, setChangingPin] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);
  const [pinSuccess, setPinSuccess] = useState(false);

  useEffect(() => {
    setBotEnabled(settings.botEnabled);
    setDefaultReplyEnabled(settings.defaultReplyEnabled);
    setDefaultReplyText(settings.defaultReplyText || DEFAULT_FALLBACK_REPLY_TEXT);
    setIgnoreGroupsByDefault(settings.ignoreGroupsByDefault);
    setIgnoreContactsInWhitelistOnly(settings.ignoreContactsInWhitelistOnly);
    setWhitelistText(listToText(settings.whitelist));
    setBlacklistText(listToText(settings.blacklist));
    setDefaultCooldownSeconds(settings.defaultCooldownSeconds);
    setTypingIndicator(settings.typingIndicator);
    setScheduleEnabled(settings.schedule.enabled);
    setStartTime(settings.schedule.startTime);
    setEndTime(settings.schedule.endTime);
    setTimezoneOffsetMinutes(settings.schedule.timezoneOffsetMinutes);
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedNotice(false);
    setError(null);
    try {
      await onSaveSettings({
        botEnabled,
        defaultReplyEnabled,
        defaultReplyText: defaultReplyText.trim() || DEFAULT_FALLBACK_REPLY_TEXT,
        ignoreGroupsByDefault,
        ignoreContactsInWhitelistOnly,
        whitelist: textToList(whitelistText),
        blacklist: textToList(blacklistText),
        defaultCooldownSeconds: Math.max(0, Number(defaultCooldownSeconds) || 0),
        typingIndicator,
        schedule: {
          enabled: scheduleEnabled,
          startTime,
          endTime,
          timezoneOffsetMinutes,
        },
      });
      setSavedNotice(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal menyimpan pengaturan.');
    } finally {
      setSaving(false);
    }
  };

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);
    setPinSuccess(false);

    if (!/^\d{4,8}$/.test(currentPin)) {
      setPinError('PIN saat ini harus 4 hingga 8 digit angka.');
      return;
    }
    if (!/^\d{4,8}$/.test(newPin)) {
      setPinError('PIN baru harus terdiri dari 4 hingga 8 digit angka.');
      return;
    }
    if (newPin !== confirmNewPin) {
      setPinError('Konfirmasi PIN baru tidak cocok.');
      return;
    }

    setChangingPin(true);
    try {
      await onChangePin(currentPin, newPin);
      setCurrentPin('');
      setNewPin('');
      setConfirmNewPin('');
      setPinSuccess(true);
    } catch (err) {
      setPinError(err instanceof Error ? err.message : 'Gagal mengubah PIN admin.');
    } finally {
      setChangingPin(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
          Pengaturan Bot
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Atur perilaku global auto-reply, jadwal jam aktif 24/7, batasan grup, dan daftar kontak
          whitelist/blacklist.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 max-w-3xl">
        {error && (
          <div
            role="alert"
            className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/40 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
          >
            {error}
          </div>
        )}

        {savedNotice && (
          <div
            role="status"
            className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/40 px-4 py-3 text-sm text-emerald-800 dark:text-emerald-200"
          >
            Pengaturan berhasil disimpan.
          </div>
        )}

        {/* General behavior */}
        <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Perilaku Utama
          </h3>

          <div className="space-y-4">
            <SwitchRow
              id="switch-bot-enabled"
              title="Aktifkan Auto-Reply Global"
              description="Jika dimatikan, bot tidak akan membalas pesan apa pun meskipun akun terhubung."
              checked={botEnabled}
              onChange={setBotEnabled}
            />

            <SwitchRow
              id="switch-ignore-groups"
              title="Abaikan Semua Pesan Grup"
              description="Direkomendasikan agar akun pribadi hanya membalas chat pribadi (DM) dan tidak mengganggu obrolan grup."
              checked={ignoreGroupsByDefault}
              onChange={setIgnoreGroupsByDefault}
            />

            <SwitchRow
              id="switch-typing-indicator"
              title='Tampilkan Status "Sedang Mengetik..."'
              description="Mengirim indikator mengetik sesaat sebelum balasan terkirim agar terasa alami."
              checked={typingIndicator}
              onChange={setTypingIndicator}
            />
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <div className="max-w-xs">
              <label
                htmlFor="settings-default-cooldown"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Cooldown Default Anti-Spam (detik)
              </label>
              <input
                id="settings-default-cooldown"
                type="number"
                min={0}
                max={86400}
                value={defaultCooldownSeconds}
                onChange={(e) => setDefaultCooldownSeconds(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
              />
            </div>
          </div>
        </section>

        {/* Default Catch-All Auto Reply */}
        <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <div className="flex items-center gap-2">
            <MessageSquareReply
              className="h-4 w-4 text-sky-600 dark:text-sky-400"
              aria-hidden="true"
            />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Balasan Default Semua Pesan (Catch-All)
            </h3>
          </div>

          <SwitchRow
            id="switch-default-reply-enabled"
            title="Balas Otomatis Semua Pesan Jika Tidak Ada Aturan Cocok"
            description="Jika admin tidak memasukkan aturan atau pesan datang dalam kata apa pun, bot tetap membalas menggunakan pesan default di bawah ini."
            checked={defaultReplyEnabled}
            onChange={setDefaultReplyEnabled}
          />

          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <label
                htmlFor="settings-default-reply-text"
                className="text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Template Balasan Default
              </label>
              <div className="flex flex-wrap items-center gap-1.5">
                {['{nama}', '{username}', '{katalog}', '{waktu}', '{tanggal}', '{pesan}'].map(
                  (tok) => (
                    <button
                      key={tok}
                      type="button"
                      onClick={() =>
                        setDefaultReplyText((prev) => (prev ? `${prev} ${tok}` : tok))
                      }
                      className="rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2 py-0.5 font-mono text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      {tok}
                    </button>
                  )
                )}
              </div>
            </div>
            <textarea
              id="settings-default-reply-text"
              rows={4}
              value={defaultReplyText}
              onChange={(e) => setDefaultReplyText(e.target.value)}
              disabled={!defaultReplyEnabled}
              placeholder="Tulis balasan default untuk semua pesan masuk..."
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 disabled:bg-slate-50 dark:disabled:bg-slate-900/50 disabled:text-slate-400 dark:disabled:text-slate-500"
            />
          </div>
        </section>

        {/* Schedule */}
        <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <SwitchRow
            id="switch-schedule-enabled"
            title="Batasi Jadwal Jam Aktif (Opsional)"
            description="Biarkan nonaktif agar bot membalas otomatis 24 jam / 7 hari penuh. Aktifkan hanya jika ingin membatasi jam tertentu."
            checked={scheduleEnabled}
            onChange={setScheduleEnabled}
          />

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label
                htmlFor="schedule-start"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Jam Mulai
              </label>
              <input
                id="schedule-start"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                disabled={!scheduleEnabled}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 disabled:bg-slate-50 dark:disabled:bg-slate-900/50 disabled:text-slate-400 dark:disabled:text-slate-500"
              />
            </div>

            <div>
              <label
                htmlFor="schedule-end"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Jam Selesai
              </label>
              <input
                id="schedule-end"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                disabled={!scheduleEnabled}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 disabled:bg-slate-50 dark:disabled:bg-slate-900/50 disabled:text-slate-400 dark:disabled:text-slate-500"
              />
            </div>

            <div>
              <label
                htmlFor="schedule-tz"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Zona Waktu
              </label>
              <select
                id="schedule-tz"
                value={timezoneOffsetMinutes}
                onChange={(e) => setTimezoneOffsetMinutes(Number(e.target.value))}
                disabled={!scheduleEnabled}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 disabled:bg-slate-50 dark:disabled:bg-slate-900/50 disabled:text-slate-400 dark:disabled:text-slate-500"
              >
                <option value={420}>WIB (UTC+7)</option>
                <option value={480}>WITA (UTC+8)</option>
                <option value={540}>WIT (UTC+9)</option>
              </select>
            </div>
          </div>
        </section>

        {/* Whitelist & Blacklist */}
        <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Filter Kontak</h3>

          <div>
            <label
              htmlFor="settings-blacklist"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Blacklist (Jangan pernah balas username atau ID ini)
            </label>
            <textarea
              id="settings-blacklist"
              rows={2}
              value={blacklistText}
              onChange={(e) => setBlacklistText(e.target.value)}
              placeholder="Contoh: @bos_kantor, @bot_spam, 123456789"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
            />
          </div>

          <SwitchRow
            id="switch-whitelist-only"
            title="Mode Whitelist Saja"
            description="Hanya membalas pengirim yang terdaftar pada daftar whitelist di bawah ini."
            checked={ignoreContactsInWhitelistOnly}
            onChange={setIgnoreContactsInWhitelistOnly}
          />

          <div>
            <label
              htmlFor="settings-whitelist"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Whitelist (Username atau Telegram ID yang diizinkan)
            </label>
            <textarea
              id="settings-whitelist"
              rows={2}
              value={whitelistText}
              onChange={(e) => setWhitelistText(e.target.value)}
              placeholder="Contoh: @klien_vip, @rekan_kerja"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
            />
          </div>
        </section>

        <div>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all"
          >
            <Save className="h-4 w-4" />
            <span>{saving ? 'Menyimpan...' : 'Simpan Pengaturan'}</span>
          </button>
        </div>
      </form>

      {/* Admin Panel PIN Security */}
      <section className="max-w-3xl rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-none">
        <div className="flex items-center gap-2">
          <KeyRound className="h-4 w-4 text-sky-600 dark:text-sky-400" aria-hidden="true" />
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Keamanan Admin Panel (PIN)
          </h3>
        </div>

        {authStatus.managedByEnv ? (
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            PIN admin saat ini dikelola melalui secret server (<code className="font-mono">ADMIN_PIN</code>). Untuk mengubah PIN, perbarui nilai <code className="font-mono">ADMIN_PIN</code> di pengaturan Secrets atau file <code className="font-mono">.env</code> lalu mulai ulang server.
          </p>
        ) : (
          <form onSubmit={handlePinSubmit} className="space-y-4">
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Ubah PIN 4–8 digit yang digunakan untuk membuka Admin Panel TeleBalas.
            </p>

            {pinError && (
              <div
                role="alert"
                className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/40 px-4 py-3 text-xs font-medium text-rose-800 dark:text-rose-200"
              >
                {pinError}
              </div>
            )}

            {pinSuccess && (
              <div
                role="status"
                className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/40 px-4 py-3 text-xs font-medium text-emerald-800 dark:text-emerald-200"
              >
                PIN admin berhasil diperbarui.
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label
                  htmlFor="pin-current"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  PIN Saat Ini
                </label>
                <input
                  id="pin-current"
                  type="password"
                  inputMode="numeric"
                  maxLength={8}
                  value={currentPin}
                  onChange={(e) => setCurrentPin(e.target.value.replace(/\D/g, '').slice(0, 8))}
                  placeholder="••••"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
                />
              </div>

              <div>
                <label
                  htmlFor="pin-new"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  PIN Baru (4–8 digit)
                </label>
                <input
                  id="pin-new"
                  type="password"
                  inputMode="numeric"
                  maxLength={8}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 8))}
                  placeholder="••••••"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
                />
              </div>

              <div>
                <label
                  htmlFor="pin-confirm"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Ulangi PIN Baru
                </label>
                <input
                  id="pin-confirm"
                  type="password"
                  inputMode="numeric"
                  maxLength={8}
                  value={confirmNewPin}
                  onChange={(e) => setConfirmNewPin(e.target.value.replace(/\D/g, '').slice(0, 8))}
                  placeholder="••••••"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={changingPin}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-60 transition-colors"
              >
                <KeyRound className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{changingPin ? 'Menyimpan PIN...' : 'Perbarui PIN Admin'}</span>
              </button>
            </div>
          </form>
        )}
      </section>
    </div>
  );
}
