import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { motion } from 'motion/react';
import { validateRuleInput } from '../shared/autoReplyEngine';
import type { AutoReplyRule, ChatScope, MatchType } from '../shared/types';

interface RuleModalProps {
  open: boolean;
  editingRule: AutoReplyRule | null;
  onClose: () => void;
  onSave: (
    payload: Omit<AutoReplyRule, 'id' | 'hitCount' | 'createdAt' | 'updatedAt'>,
    existingId?: string
  ) => Promise<void>;
}

const MATCH_OPTIONS: { value: MatchType; label: string; hint: string }[] = [
  { value: 'contains', label: 'Mengandung kata', hint: 'Pisahkan beberapa kata kunci dengan koma' },
  { value: 'exact', label: 'Persis sama', hint: 'Cocok jika seluruh pesan sama persis' },
  { value: 'starts_with', label: 'Diawali kata', hint: 'Cocok jika pesan dimulai dengan kata ini' },
  { value: 'regex', label: 'Ekspresi Reguler (Regex)', hint: 'Pola lanjutan, misal ^order\\s+#?\\d+' },
  {
    value: 'all_incoming',
    label: 'Semua pesan masuk',
    hint: 'Membalas semua pesan jika tidak ada aturan di atasnya',
  },
];

export function RuleModal({ open, editingRule, onClose, onSave }: RuleModalProps) {
  const [name, setName] = useState('');
  const [matchType, setMatchType] = useState<MatchType>('contains');
  const [pattern, setPattern] = useState('');
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [chatScope, setChatScope] = useState<ChatScope>('private');
  const [replyText, setReplyText] = useState('');
  const [quoteOriginal, setQuoteOriginal] = useState(false);
  const [delayMs, setDelayMs] = useState(800);
  const [cooldownSeconds, setCooldownSeconds] = useState(60);
  const [priority, setPriority] = useState(10);
  const [enabled, setEnabled] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (editingRule) {
      setName(editingRule.name);
      setMatchType(editingRule.matchType);
      setPattern(editingRule.pattern);
      setCaseSensitive(editingRule.caseSensitive);
      setChatScope(editingRule.chatScope);
      setReplyText(editingRule.replyText);
      setQuoteOriginal(editingRule.quoteOriginal);
      setDelayMs(editingRule.delayMs);
      setCooldownSeconds(editingRule.cooldownSeconds);
      setPriority(editingRule.priority);
      setEnabled(editingRule.enabled);
    } else {
      setName('');
      setMatchType('contains');
      setPattern('');
      setCaseSensitive(false);
      setChatScope('private');
      setReplyText('Halo {nama}, terima kasih sudah menghubungi saya. Pesan Anda sudah diterima.');
      setQuoteOriginal(false);
      setDelayMs(800);
      setCooldownSeconds(60);
      setPriority(10);
      setEnabled(true);
    }
    setErrors({});
    setSubmitError(null);
  }, [open, editingRule]);

  if (!open) return null;

  const insertVariable = (token: string) => {
    setReplyText((prev) => (prev ? `${prev} ${token}` : token));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority,
    });

    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    setSubmitError(null);
    setSaving(true);
    try {
      await onSave(
        {
          name: name.trim(),
          matchType,
          pattern: matchType === 'all_incoming' ? '' : pattern.trim(),
          caseSensitive,
          chatScope,
          replyText: replyText.trim(),
          quoteOriginal,
          delayMs,
          cooldownSeconds,
          priority,
          enabled,
        },
        editingRule?.id
      );
      onClose();
    } catch (err) {
      const typedErr = err as Error & { fieldErrors?: Record<string, string> };
      if (typedErr.fieldErrors) setErrors(typedErr.fieldErrors);
      setSubmitError(typedErr.message || 'Gagal menyimpan aturan.');
    } finally {
      setSaving(false);
    }
  };

  const selectedMatchMeta = MATCH_OPTIONS.find((m) => m.value === matchType);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rule-modal-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.97, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F1624] shadow-xl"
      >
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 px-6 py-4">
          <h2
            id="rule-modal-title"
            className="text-base font-bold text-slate-900 dark:text-slate-100"
          >
            {editingRule ? 'Edit Aturan Balasan' : 'Tambah Aturan Balasan Baru'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup dialog aturan"
            className="rounded-xl p-1.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {submitError && (
            <div
              role="alert"
              className="rounded-xl border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/50 px-4 py-3 text-sm text-rose-800 dark:text-rose-200"
            >
              {submitError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label
                htmlFor="rule-name"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Nama Aturan
              </label>
              <input
                id="rule-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Misal: Informasi Harga Layanan"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              {errors.name && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.name}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="rule-priority"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Prioritas (1 = tertinggi)
              </label>
              <input
                id="rule-priority"
                type="number"
                min={1}
                max={999}
                value={priority}
                onChange={(e) => setPriority(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
              />
              {errors.priority && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.priority}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="rule-match-type"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Tipe Pencocokan
              </label>
              <select
                id="rule-match-type"
                value={matchType}
                onChange={(e) => setMatchType(e.target.value as MatchType)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              >
                {MATCH_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
              {selectedMatchMeta && (
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  {selectedMatchMeta.hint}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="rule-scope"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Berlaku di Chat
              </label>
              <select
                id="rule-scope"
                value={chatScope}
                onChange={(e) => setChatScope(e.target.value as ChatScope)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              >
                <option value="private">Chat Pribadi Saja</option>
                <option value="group">Grup Telegram Saja</option>
                <option value="all">Pribadi & Grup</option>
              </select>
            </div>
          </div>

          {matchType !== 'all_incoming' && (
            <div>
              <label
                htmlFor="rule-pattern"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Kata Kunci / Pola Pemicu
              </label>
              <input
                id="rule-pattern"
                type="text"
                value={pattern}
                onChange={(e) => setPattern(e.target.value)}
                placeholder={
                  matchType === 'regex' ? '^order\\s+#?\\d+$' : 'harga, pricelist, biaya'
                }
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              {errors.pattern && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.pattern}</p>
              )}
            </div>
          )}

          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <label
                htmlFor="rule-reply"
                className="text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Pesan Balasan Otomatis
              </label>
              <div className="flex flex-wrap items-center gap-1.5">
                {['{nama}', '{username}', '{katalog}', '{waktu}', '{tanggal}', '{pesan}'].map(
                  (tok) => (
                    <button
                      key={tok}
                      type="button"
                      onClick={() => insertVariable(tok)}
                      className="rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2 py-0.5 font-mono text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                    >
                      {tok}
                    </button>
                  )
                )}
              </div>
            </div>
            <textarea
              id="rule-reply"
              rows={4}
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Tulis balasan otomatis Anda di sini..."
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
            />
            {errors.replyText && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.replyText}</p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="rule-delay"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Jeda Sebelum Mengirim (ms)
              </label>
              <input
                id="rule-delay"
                type="number"
                min={0}
                max={30000}
                step={100}
                value={delayMs}
                onChange={(e) => setDelayMs(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
              />
              {errors.delayMs && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{errors.delayMs}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="rule-cooldown"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Cooldown Per Pengirim (detik)
              </label>
              <input
                id="rule-cooldown"
                type="number"
                min={0}
                max={86400}
                value={cooldownSeconds}
                onChange={(e) => setCooldownSeconds(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-slate-100 tabular-nums"
              />
              {errors.cooldownSeconds && (
                <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">
                  {errors.cooldownSeconds}
                </p>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-1">
            <label className="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-sky-600"
              />
              <span>Aktifkan aturan ini</span>
            </label>

            <label className="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={quoteOriginal}
                onChange={(e) => setQuoteOriginal(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-sky-600"
              />
              <span>Balas sambil kutip pesan (Reply)</span>
            </label>

            <label className="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={caseSensitive}
                onChange={(e) => setCaseSensitive(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-sky-600"
              />
              <span>Peka huruf besar/kecil</span>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all whitespace-nowrap"
            >
              {saving ? 'Menyimpan...' : editingRule ? 'Simpan Perubahan' : 'Simpan Aturan'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
