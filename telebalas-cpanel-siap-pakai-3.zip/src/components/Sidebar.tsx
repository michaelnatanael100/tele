import {
  Activity,
  FlaskConical,
  HardDriveDownload,
  LayoutDashboard,
  Link2,
  MessageSquareReply,
  QrCode,
  Send,
  Settings,
  ShoppingBag,
  X,
} from 'lucide-react';
import type { TelegramAccountPublic } from '../shared/types';

export type NavSection =
  | 'overview'
  | 'products'
  | 'payment'
  | 'rules'
  | 'simulator'
  | 'connection'
  | 'logs'
  | 'export'
  | 'settings';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  account: TelegramAccountPublic;
  botEnabled: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: { id: NavSection; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'overview', label: 'Ringkasan', icon: LayoutDashboard },
  { id: 'products', label: 'Produk Jualan', icon: ShoppingBag },
  { id: 'payment', label: 'QRIS GoPay', icon: QrCode },
  { id: 'rules', label: 'Aturan Balasan', icon: MessageSquareReply },
  { id: 'simulator', label: 'Simulasi Uji', icon: FlaskConical },
  { id: 'connection', label: 'Koneksi Akun', icon: Link2 },
  { id: 'logs', label: 'Log Aktivitas', icon: Activity },
  { id: 'export', label: 'Backup & cPanel', icon: HardDriveDownload },
  { id: 'settings', label: 'Pengaturan', icon: Settings },
];

export function Sidebar({
  activeSection,
  onSelectSection,
  account,
  botEnabled,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const isConnected = account.status === 'connected';
  const accountDisplayName =
    [account.firstName, account.lastName].filter(Boolean).join(' ') ||
    (account.username ? `@${account.username}` : 'Belum terhubung');

  const navContent = (
    <div className="flex h-full flex-col bg-gradient-to-b from-[#0B0F17] via-[#0D1424] to-[#080C14] text-slate-300 border-r border-slate-800/80">
      <div className="flex h-16 items-center justify-between px-5 border-b border-white/[0.07]">
        <a
          href="#overview"
          onClick={(e) => {
            e.preventDefault();
            onSelectSection('overview');
            onCloseMobile();
          }}
          className="inline-flex items-center gap-2.5 text-lg font-semibold tracking-tight text-white whitespace-nowrap shrink-0"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-sky-400 via-sky-500 to-indigo-600 text-white shadow-md shadow-sky-500/25">
            <Send className="h-3.5 w-3.5" aria-hidden="true" />
          </span>
          <span>TeleBalas</span>
        </a>
        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Tutup menu navigasi"
          className="lg:hidden rounded-lg p-2 text-slate-400 hover:bg-white/10 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <nav aria-label="Navigasi utama" className="flex-1 space-y-1 px-3 py-5 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectSection(item.id);
                onCloseMobile();
              }}
              aria-current={active ? 'page' : undefined}
              className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all duration-150 whitespace-nowrap shrink-0 ${
                active
                  ? 'bg-gradient-to-r from-sky-500/20 via-indigo-500/12 to-transparent border border-sky-400/25 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]'
                  : 'border border-transparent text-slate-400 hover:bg-white/[0.05] hover:text-slate-100'
              }`}
            >
              <Icon
                className={`h-4 w-4 shrink-0 ${active ? 'text-sky-400' : 'text-slate-500'}`}
              />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="border-t border-white/[0.08] bg-white/[0.02] p-4 space-y-3">
        <div>
          <div className="text-xs font-medium text-slate-400">Akun Telegram Pribadi</div>
          <div className="mt-1 text-sm font-semibold text-white truncate">{accountDisplayName}</div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          {isConnected ? (
            <>
              <span className="h-2 w-2 rounded-full bg-emerald-400 shrink-0" aria-hidden="true" />
              <span className="text-emerald-400 font-medium">Terhubung</span>
            </>
          ) : (
            <span className="text-slate-400">Belum terhubung</span>
          )}
          <span className="text-slate-600" aria-hidden="true">
            ·
          </span>
          <span className={botEnabled ? 'text-slate-200' : 'text-amber-400'}>
            {botEnabled ? 'Bot Aktif' : 'Bot Dijeda'}
          </span>
        </div>

        {!isConnected && (
          <button
            type="button"
            onClick={() => {
              onSelectSection('connection');
              onCloseMobile();
            }}
            className="w-full rounded-xl border border-sky-400/20 bg-gradient-to-r from-sky-500/15 to-indigo-500/15 px-3 py-2 text-xs font-medium text-white hover:from-sky-500/25 hover:to-indigo-500/25 transition-all whitespace-nowrap"
          >
            Hubungkan Akun
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block lg:w-64 lg:shrink-0 lg:sticky lg:top-0 lg:h-screen">
        {navContent}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-64 max-w-[80vw] h-full">{navContent}</aside>
        </div>
      )}
    </>
  );
}
