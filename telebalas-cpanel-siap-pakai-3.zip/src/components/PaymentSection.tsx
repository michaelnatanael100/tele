import { useEffect, useMemo, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  Eye,
  EyeOff,
  KeyRound,
  QrCode,
  RefreshCw,
  Send,
  ShieldCheck,
  Sparkles,
  Wallet,
  XCircle,
} from 'lucide-react';
import {
  cancelPaymentOrder,
  createTestQrisOrder,
  pollGopayMutationsNow,
  resendPaymentOrder,
  rotateGopayWebhookSecret,
  simulateGopayMutation,
  updateGopayConfig,
} from '../api/client';
import { formatRupiah, getAvailableAccountCount } from '../shared/autoReplyEngine';
import {
  extractMerchantNameFromQris,
  SAMPLE_GOPAY_STATIC_QRIS,
  validateStaticQris,
} from '../shared/qris';
import type {
  DashboardStats,
  GoPayMerchantPublicConfig,
  GoPayMutationEntry,
  PaymentOrder,
  ProductItem,
} from '../shared/types';

interface PaymentSectionProps {
  products: ProductItem[];
  orders: PaymentOrder[];
  mutations: GoPayMutationEntry[];
  gopayConfig: GoPayMerchantPublicConfig;
  stats: DashboardStats;
  onRefreshState: () => Promise<void>;
  onNavigateProducts: () => void;
}

function formatDateTime(iso: string | null): string {
  if (!iso) return '-';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '-';
  return d.toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function orderStatusMeta(order: PaymentOrder): { label: string; className: string } {
  if (order.status === 'delivered') {
    return {
      label: 'Terkirim',
      className: 'text-emerald-700 dark:text-emerald-400 font-semibold',
    };
  }
  if (order.status === 'paid') {
    return {
      label: order.deliveryPending ? 'Lunas (Pending Kirim)' : 'Lunas',
      className: 'text-sky-700 dark:text-sky-400 font-semibold',
    };
  }
  if (order.status === 'pending') {
    return {
      label: 'Menunggu Bayar',
      className: 'text-amber-700 dark:text-amber-400 font-semibold',
    };
  }
  if (order.status === 'expired') {
    return {
      label: 'Kedaluwarsa',
      className: 'text-slate-500 dark:text-slate-400 font-medium',
    };
  }
  return {
    label: 'Dibatalkan',
    className: 'text-rose-700 dark:text-rose-400 font-medium',
  };
}

export function PaymentSection({
  products,
  orders,
  mutations,
  gopayConfig,
  stats,
  onRefreshState,
  onNavigateProducts,
}: PaymentSectionProps) {
  const [enabled, setEnabled] = useState(gopayConfig.enabled);
  const [merchantName, setMerchantName] = useState(gopayConfig.merchantName);
  const [staticQris, setStaticQris] = useState(gopayConfig.staticQris);
  const [mutationApiUrl, setMutationApiUrl] = useState(gopayConfig.mutationApiUrl);
  const [apiToken, setApiToken] = useState('');
  const [clearApiToken, setClearApiToken] = useState(false);
  const [pollingEnabled, setPollingEnabled] = useState(gopayConfig.pollingEnabled);
  const [pollIntervalSeconds, setPollIntervalSeconds] = useState(gopayConfig.pollIntervalSeconds);
  const [orderExpiryMinutes, setOrderExpiryMinutes] = useState(gopayConfig.orderExpiryMinutes);

  const [savingConfig, setSavingConfig] = useState(false);
  const [configMsg, setConfigMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [pollingNow, setPollingNow] = useState(false);
  const [rotatingSecret, setRotatingSecret] = useState(false);
  const [revealedWebhookSecret, setRevealedWebhookSecret] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Simulator / Live QRIS Checkout Preview state
  const activeProducts = useMemo(
    () => products.filter((p) => p.price > 0),
    [products]
  );
  const [selectedProductId, setSelectedProductId] = useState<string>(
    activeProducts[0]?.id ?? ''
  );
  const [buyerName, setBuyerName] = useState('Raka Pembeli');
  const [creatingOrder, setCreatingOrder] = useState(false);
  const [simulatingMutation, setSimulatingMutation] = useState(false);
  const [activePreviewOrderId, setActivePreviewOrderId] = useState<string | null>(null);
  const [activeQrDataUrl, setActiveQrDataUrl] = useState<string | null>(null);
  const [simNotifText, setSimNotifText] = useState('');
  const [simFeedback, setSimFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [historyTab, setHistoryTab] = useState<'orders' | 'mutations'>('orders');
  const [revealedOrderAccIds, setRevealedOrderAccIds] = useState<Record<string, boolean>>({});
  const [busyOrderId, setBusyOrderId] = useState<string | null>(null);

  useEffect(() => {
    setEnabled(gopayConfig.enabled);
    setMerchantName(gopayConfig.merchantName);
    setStaticQris(gopayConfig.staticQris);
    setMutationApiUrl(gopayConfig.mutationApiUrl);
    setPollingEnabled(gopayConfig.pollingEnabled);
    setPollIntervalSeconds(gopayConfig.pollIntervalSeconds);
    setOrderExpiryMinutes(gopayConfig.orderExpiryMinutes);
  }, [gopayConfig]);

  useEffect(() => {
    if (!selectedProductId && activeProducts.length > 0) {
      setSelectedProductId(activeProducts[0].id);
    }
  }, [selectedProductId, activeProducts]);

  const staticCheck = useMemo(() => validateStaticQris(staticQris), [staticQris]);
  const detectedMerchant = useMemo(() => extractMerchantNameFromQris(staticQris), [staticQris]);
  const webhookUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/api/payment/gopay/webhook`
      : '/api/payment/gopay/webhook';

  const activePreviewOrder = useMemo(
    () => orders.find((o) => o.id === activePreviewOrderId) ?? null,
    [orders, activePreviewOrderId]
  );

  const copyText = (key: string, text: string) => {
    void navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey(null), 1800);
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    setConfigMsg(null);
    try {
      await updateGopayConfig({
        enabled,
        merchantName: merchantName.trim(),
        staticQris: staticQris.trim(),
        mutationApiUrl: mutationApiUrl.trim(),
        apiToken: apiToken.trim() || undefined,
        clearApiToken,
        pollingEnabled,
        pollIntervalSeconds,
        orderExpiryMinutes,
      });
      setApiToken('');
      setClearApiToken(false);
      await onRefreshState();
      setConfigMsg({
        type: 'ok',
        text: 'Konfigurasi QRIS GoPay Merchant berhasil disimpan.',
      });
    } catch (err) {
      setConfigMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Gagal menyimpan konfigurasi GoPay.',
      });
    } finally {
      setSavingConfig(false);
    }
  };

  const handlePollNow = async () => {
    setPollingNow(true);
    setConfigMsg(null);
    try {
      const res = await pollGopayMutationsNow();
      await onRefreshState();
      setConfigMsg({
        type: res.result.ok ? 'ok' : 'err',
        text: res.result.statusMessage,
      });
    } catch (err) {
      setConfigMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Gagal memeriksa mutasi API GoPay.',
      });
    } finally {
      setPollingNow(false);
    }
  };

  const handleRotateSecret = async () => {
    setRotatingSecret(true);
    setConfigMsg(null);
    try {
      const res = await rotateGopayWebhookSecret();
      setRevealedWebhookSecret(res.plainWebhookSecret);
      await onRefreshState();
      setConfigMsg({
        type: 'ok',
        text: 'Webhook secret baru dibuat. Salin sekarang untuk dipasang pada aplikasi listener notifikasi GoPay Anda.',
      });
    } catch (err) {
      setConfigMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Gagal membuat webhook secret baru.',
      });
    } finally {
      setRotatingSecret(false);
    }
  };

  const handleCreateTestOrder = async () => {
    if (!selectedProductId) return;
    setCreatingOrder(true);
    setSimFeedback(null);
    try {
      const res = await createTestQrisOrder({
        productId: selectedProductId,
        buyerName: buyerName.trim() || 'Pembeli Simulasi',
      });
      setActivePreviewOrderId(res.order.id);
      setActiveQrDataUrl(res.qrDataUrl);
      setSimNotifText(
        `Pembayaran QRIS GoPay Merchant sebesar Rp ${res.order.totalAmount.toLocaleString('id-ID')} berhasil diterima`
      );
      await onRefreshState();
    } catch (err) {
      setSimFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Gagal membuat invoice QRIS uji.',
      });
    } finally {
      setCreatingOrder(false);
    }
  };

  const handleSimulateMutation = async (amountOverride?: number) => {
    setSimulatingMutation(true);
    setSimFeedback(null);
    try {
      const payload =
        typeof amountOverride === 'number'
          ? {
              amount: amountOverride,
              notificationText: `Pembayaran QRIS GoPay Merchant sebesar Rp ${amountOverride.toLocaleString('id-ID')} berhasil`,
            }
          : {
              notificationText: simNotifText,
            };
      const res = await simulateGopayMutation(payload);
      await onRefreshState();
      if (res.outcome.matched && res.outcome.order) {
        setActivePreviewOrderId(res.outcome.order.id);
        setSimFeedback({
          type: 'ok',
          text: `Mutasi ${formatRupiah(res.outcome.mutation.amount)} cocok dengan ${res.outcome.order.orderCode}! Detail akun otomatis dikirim ke pembeli.`,
        });
      } else {
        setSimFeedback({
          type: 'err',
          text: `Mutasi ${formatRupiah(res.outcome.mutation.amount)} tercatat, tetapi tidak ada invoice Menunggu Bayar dengan nominal tersebut.`,
        });
      }
    } catch (err) {
      setSimFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Simulasi mutasi gagal diproses.',
      });
    } finally {
      setSimulatingMutation(false);
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    setBusyOrderId(orderId);
    try {
      await cancelPaymentOrder(orderId);
      await onRefreshState();
    } finally {
      setBusyOrderId(null);
    }
  };

  const handleResendOrder = async (orderId: string) => {
    setBusyOrderId(orderId);
    try {
      await resendPaymentOrder(orderId);
      await onRefreshState();
    } finally {
      setBusyOrderId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Payment Gateway QRIS GoPay Merchant
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Pembeli cukup ketik <code className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-200/70 dark:bg-slate-800">order netflix</code> di Telegram, bot menerbitkan QRIS Dinamis GoPay unik &amp; otomatis mengirim detail akun begitu mutasi masuk.
          </p>
        </div>

        <button
          type="button"
          onClick={onNavigateProducts}
          className="inline-flex items-center gap-2 self-start rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
        >
          <KeyRound className="h-3.5 w-3.5 text-sky-600 dark:text-sky-400" aria-hidden="true" />
          <span>Kelola Stok Akun Produk</span>
        </button>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Menunggu Pembayaran</span>
            <QrCode className="h-4 w-4 text-amber-600 dark:text-amber-400" aria-hidden="true" />
          </div>
          <div className="mt-2.5 text-3xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {stats.pendingOrdersCount}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Invoice QRIS aktif (kode unik)
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Transaksi Lunas</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
          </div>
          <div className="mt-2.5 text-3xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {stats.paidOrdersCount}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Terverifikasi mutasi GoPay
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Total Omzet QRIS</span>
            <Wallet className="h-4 w-4 text-sky-600 dark:text-sky-400" aria-hidden="true" />
          </div>
          <div className="mt-2.5 text-2xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {formatRupiah(stats.totalRevenue)}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Akumulasi order masuk
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Stok Akun Siap Kirim</span>
            <KeyRound className="h-4 w-4 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
          </div>
          <div className="mt-2.5 text-3xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums font-display">
            {stats.availableAccountStockCount}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Email/Password siap kirim otomatis
          </div>
        </div>
      </div>

      {/* Main 2-column workspace: Merchant Config & Live Checkout Test */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: GoPay Merchant Config */}
        <form
          onSubmit={handleSaveConfig}
          className="lg:col-span-7 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Pengaturan QRIS GoPay Merchant
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Konversi QRIS statis menjadi nominal dinamis otomatis + baca mutasi GoPay Merchant.
              </p>
            </div>

            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-sky-600"
              />
              <span>Aktifkan Checkout QRIS</span>
            </label>
          </div>

          {configMsg && (
            <div
              role="status"
              className={`rounded-xl border px-4 py-3 text-xs font-medium ${
                configMsg.type === 'ok'
                  ? 'border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                  : 'border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
              }`}
            >
              {configMsg.text}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label
                htmlFor="gopay-merchant-name"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Nama Merchant Tampil di Invoice
              </label>
              <input
                id="gopay-merchant-name"
                type="text"
                value={merchantName}
                onChange={(e) => setMerchantName(e.target.value)}
                placeholder="TOKO DIGITAL ANDA"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="gopay-expiry"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Batas Bayar (Menit)
              </label>
              <input
                id="gopay-expiry"
                type="number"
                min={3}
                max={180}
                value={orderExpiryMinutes}
                onChange={(e) => setOrderExpiryMinutes(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <label
                htmlFor="gopay-static-qris"
                className="text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Data String QRIS Statis GoPay Merchant
              </label>
              <button
                type="button"
                onClick={() => setStaticQris(SAMPLE_GOPAY_STATIC_QRIS)}
                className="text-xs font-medium text-sky-700 dark:text-sky-400 hover:underline"
              >
                Isi Contoh QRIS Uji
              </button>
            </div>
            <textarea
              id="gopay-static-qris"
              rows={3}
              value={staticQris}
              onChange={(e) => setStaticQris(e.target.value)}
              placeholder="Tempel hasil scan teks QRIS GoPay Merchant (000201010211...)"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-slate-100 break-all"
            />
            <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2 text-xs">
              {staticCheck.valid ? (
                <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                  Checksum QRIS EMVCo Valid{detectedMerchant ? ` · Merchant QR: ${detectedMerchant}` : ''}
                </span>
              ) : (
                <span className="text-rose-600 dark:text-rose-400 font-medium">
                  {staticCheck.error}
                </span>
              )}
            </div>
          </div>

          {/* Method 1: API Polling */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 p-4 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs font-bold text-slate-900 dark:text-slate-100">
                1. Polling API Mutasi GoPay Merchant (HTTPS)
              </div>
              <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={pollingEnabled}
                  onChange={(e) => setPollingEnabled(e.target.checked)}
                  className="h-3.5 w-3.5 rounded border-slate-300 text-sky-600"
                />
                <span>Polling Otomatis</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label
                  htmlFor="gopay-api-url"
                  className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
                >
                  URL Endpoint Mutasi (GoBiz / Gateway Anda)
                </label>
                <input
                  id="gopay-api-url"
                  type="url"
                  value={mutationApiUrl}
                  onChange={(e) => setMutationApiUrl(e.target.value)}
                  placeholder="https://api-merchant-anda.com/gopay/mutations"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label
                  htmlFor="gopay-poll-interval"
                  className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
                >
                  Interval Cek (Detik)
                </label>
                <input
                  id="gopay-poll-interval"
                  type="number"
                  min={10}
                  max={300}
                  value={pollIntervalSeconds}
                  onChange={(e) => setPollIntervalSeconds(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label
                  htmlFor="gopay-api-token"
                  className="text-[11px] font-medium text-slate-600 dark:text-slate-400"
                >
                  Bearer API Token {gopayConfig.hasApiToken ? `(Tersimpan: ${gopayConfig.apiTokenMasked})` : '(Opsional)'}
                </label>
                {gopayConfig.hasApiToken && (
                  <label className="inline-flex items-center gap-1.5 text-[11px] text-rose-600 dark:text-rose-400 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={clearApiToken}
                      onChange={(e) => setClearApiToken(e.target.checked)}
                    />
                    <span>Hapus token</span>
                  </label>
                )}
              </div>
              <input
                id="gopay-api-token"
                type="password"
                value={apiToken}
                onChange={(e) => setApiToken(e.target.value)}
                placeholder={
                  gopayConfig.hasApiToken
                    ? 'Biarkan kosong jika tidak ingin mengubah token tersimpan'
                    : 'Masukkan Bearer Token endpoint mutasi GoPay Anda'
                }
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                {gopayConfig.lastPollStatus
                  ? `${gopayConfig.lastPollStatus} (${formatDateTime(gopayConfig.lastPolledAt)})`
                  : 'Belum pernah polling manual/otomatis.'}
              </div>
              <button
                type="button"
                onClick={handlePollNow}
                disabled={pollingNow || !mutationApiUrl.trim()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${pollingNow ? 'animate-spin' : ''}`} />
                <span>Cek Mutasi Sekarang</span>
              </button>
            </div>
          </div>

          {/* Method 2: Real-Time Webhook */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-slate-100">
                <ShieldCheck className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                <span>2. Webhook Real-Time Notifikasi GoPay Merchant (GoBiz / Android)</span>
              </div>
              <button
                type="button"
                onClick={handleRotateSecret}
                disabled={rotatingSecret}
                className="text-xs font-semibold text-sky-700 dark:text-sky-400 hover:underline disabled:opacity-50"
              >
                {rotatingSecret ? 'Membuat...' : 'Generate Secret Baru'}
              </button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
                <div className="min-w-0">
                  <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                    POST Webhook URL
                  </div>
                  <div className="font-mono text-xs text-slate-800 dark:text-slate-200 truncate">
                    {webhookUrl}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => copyText('url', webhookUrl)}
                  aria-label="Salin URL webhook GoPay"
                  className="rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                >
                  {copiedKey === 'url' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>

              <div className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
                <div className="min-w-0">
                  <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                    Header X-Webhook-Secret / Bearer Token
                  </div>
                  <div className="font-mono text-xs text-slate-800 dark:text-slate-200 truncate">
                    {revealedWebhookSecret ?? gopayConfig.webhookSecretMasked ?? 'Belum dibuat'}
                  </div>
                </div>
                {revealedWebhookSecret && (
                  <button
                    type="button"
                    onClick={() => copyText('secret', revealedWebhookSecret)}
                    aria-label="Salin webhook secret"
                    className="rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                  >
                    {copiedKey === 'secret' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  </button>
                )}
              </div>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                Kirim JSON POST dari aplikasi pembaca notifikasi GoBiz Android (misal MacroDroid/AutoNotification):{' '}
                <code className="font-mono text-[11px] bg-slate-200/60 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                  {'{"text":"Pembayaran QRIS GoPay sebesar Rp 35.147 berhasil"}'}
                </code>
              </p>
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={savingConfig}
              className="rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2.5 text-xs font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60 transition-all"
            >
              {savingConfig ? 'Menyimpan...' : 'Simpan Konfigurasi GoPay'}
            </button>
          </div>
        </form>

        {/* Right: Test QRIS Invoice & Mutasi Simulator */}
        <section className="lg:col-span-5 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] p-6 space-y-5">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-sky-600 dark:text-sky-400" aria-hidden="true" />
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Uji QRIS &amp; Mutasi Otomatis
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Simulasikan alur pembeli memesan produk sampai mutasi GoPay terbaca dan akun terkirim.
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <label
                htmlFor="test-qris-product"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Pilih Produk untuk Uji Checkout
              </label>
              <select
                id="test-qris-product"
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              >
                {activeProducts.length === 0 ? (
                  <option value="">Belum ada produk berharga &gt; Rp 0</option>
                ) : (
                  activeProducts.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} — {formatRupiah(p.price)} ({getAvailableAccountCount(p)} akun siap)
                    </option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label
                htmlFor="test-qris-buyer"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Nama Pembeli Simulasi
              </label>
              <input
                id="test-qris-buyer"
                type="text"
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <button
              type="button"
              onClick={handleCreateTestOrder}
              disabled={creatingOrder || !selectedProductId}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-sm shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-60"
            >
              <QrCode className="h-4 w-4" aria-hidden="true" />
              <span>{creatingOrder ? 'Membuat QRIS...' : 'Buat Invoice QRIS Uji'}</span>
            </button>
          </div>

          {simFeedback && (
            <div
              role="status"
              className={`rounded-xl border px-3.5 py-2.5 text-xs font-medium ${
                simFeedback.type === 'ok'
                  ? 'border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                  : 'border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
              }`}
            >
              {simFeedback.text}
            </div>
          )}

          {activePreviewOrder && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/60 p-4 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                    {activePreviewOrder.orderCode}
                  </div>
                  <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {activePreviewOrder.productName}
                  </div>
                </div>
                <span className={`text-xs ${orderStatusMeta(activePreviewOrder).className}`}>
                  {orderStatusMeta(activePreviewOrder).label}
                </span>
              </div>

              {activeQrDataUrl && activePreviewOrder.status === 'pending' && (
                <div className="flex flex-col items-center bg-white rounded-xl p-4 border border-slate-200">
                  <img
                    src={activeQrDataUrl}
                    alt={`QRIS Dinamis ${activePreviewOrder.orderCode}`}
                    className="h-44 w-44 object-contain"
                  />
                  <div className="mt-2 text-center">
                    <div className="text-xs font-semibold text-slate-600">
                      {gopayConfig.merchantName || 'GOPAY MERCHANT'}
                    </div>
                    <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
                      {formatRupiah(activePreviewOrder.totalAmount)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Harga {formatRupiah(activePreviewOrder.basePrice)} + Kode Unik{' '}
                      {activePreviewOrder.uniqueCode}
                    </div>
                  </div>
                </div>
              )}

              {activePreviewOrder.status === 'pending' && (
                <div className="space-y-2.5">
                  <label
                    htmlFor="sim-mutasi-text"
                    className="block text-[11px] font-medium text-slate-600 dark:text-slate-400"
                  >
                    Teks Notifikasi / Nominal Mutasi GoPay
                  </label>
                  <input
                    id="sim-mutasi-text"
                    type="text"
                    value={simNotifText}
                    onChange={(e) => setSimNotifText(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                  />
                  <button
                    type="button"
                    onClick={() => void handleSimulateMutation()}
                    disabled={simulatingMutation}
                    className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
                  >
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>
                      {simulatingMutation
                        ? 'Memproses Mutasi...'
                        : 'Simulasikan Mutasi GoPay Masuk'}
                    </span>
                  </button>
                </div>
              )}

              {activePreviewOrder.deliveredAccount && (
                <div className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50/70 dark:bg-emerald-950/30 p-3.5 space-y-1.5 text-xs">
                  <div className="font-bold text-emerald-800 dark:text-emerald-300">
                    Detail Akun Otomatis Terkirim ke Pembeli:
                  </div>
                  {activePreviewOrder.deliveredAccount.email && (
                    <div className="font-mono text-slate-900 dark:text-slate-100">
                      Email: {activePreviewOrder.deliveredAccount.email}
                    </div>
                  )}
                  {activePreviewOrder.deliveredAccount.password && (
                    <div className="font-mono text-slate-900 dark:text-slate-100">
                      Password: {activePreviewOrder.deliveredAccount.password}
                    </div>
                  )}
                  {activePreviewOrder.deliveredAccount.extraData && (
                    <div className="text-slate-700 dark:text-slate-300">
                      Data Lain: {activePreviewOrder.deliveredAccount.extraData}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </section>
      </div>

      {/* Bottom History Tabs: Orders & GoPay Mutations */}
      <section className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#0F1624] overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 px-5 py-4">
          <div className="flex items-center gap-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 p-1">
            <button
              type="button"
              onClick={() => setHistoryTab('orders')}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                historyTab === 'orders'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Riwayat Order QRIS ({orders.length})
            </button>
            <button
              type="button"
              onClick={() => setHistoryTab('mutations')}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                historyTab === 'mutations'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Log Mutasi GoPay Masuk ({mutations.length})
            </button>
          </div>
        </div>

        {historyTab === 'orders' ? (
          orders.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Belum ada order QRIS GoPay yang masuk. Gunakan panel Uji QRIS di atas atau kirim{' '}
              <code className="font-mono text-xs">order netflix</code> di Telegram.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-5">Kode Order</th>
                    <th className="py-3 px-4">Produk &amp; Pembeli</th>
                    <th className="py-3 px-4">Nominal Unik</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Akun Terkirim</th>
                    <th className="py-3 px-5 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {orders.map((ord) => {
                    const meta = orderStatusMeta(ord);
                    const revealed = Boolean(revealedOrderAccIds[ord.id]);
                    return (
                      <tr
                        key={ord.id}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 align-top"
                      >
                        <td className="py-3.5 px-5 whitespace-nowrap">
                          <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                            {ord.orderCode}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {formatDateTime(ord.createdAt)}
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 dark:text-slate-100">
                            {ord.productName}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {ord.buyerName} ({ord.source === 'telegram' ? 'Telegram' : 'Simulasi'})
                          </div>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                          {formatRupiah(ord.totalAmount)}
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className={meta.className}>{meta.label}</span>
                          {ord.paidVia && (
                            <div className="text-[11px] text-slate-500 dark:text-slate-400">
                              {ord.paidVia}
                            </div>
                          )}
                        </td>
                        <td className="py-3.5 px-4 max-w-xs">
                          {ord.deliveredAccount ? (
                            <div className="space-y-0.5">
                              <button
                                type="button"
                                onClick={() =>
                                  setRevealedOrderAccIds((prev) => ({
                                    ...prev,
                                    [ord.id]: !prev[ord.id],
                                  }))
                                }
                                className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-700 dark:text-sky-400 hover:underline"
                              >
                                {revealed ? (
                                  <EyeOff className="h-3 w-3" />
                                ) : (
                                  <Eye className="h-3 w-3" />
                                )}
                                <span>{revealed ? 'Sembunyikan Akun' : 'Lihat Akun Terkirim'}</span>
                              </button>
                              {revealed && (
                                <div className="font-mono text-[11px] text-slate-700 dark:text-slate-300 space-y-0.5 pt-1">
                                  <div>{ord.deliveredAccount.email}</div>
                                  {ord.deliveredAccount.password && (
                                    <div>Pass: {ord.deliveredAccount.password}</div>
                                  )}
                                  {ord.deliveredAccount.extraData && (
                                    <div>{ord.deliveredAccount.extraData}</div>
                                  )}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-400 dark:text-slate-500">-</span>
                          )}
                        </td>
                        <td className="py-3.5 px-5 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            {ord.status === 'pending' && (
                              <>
                                <button
                                  type="button"
                                  disabled={busyOrderId === ord.id || simulatingMutation}
                                  onClick={() => void handleSimulateMutation(ord.totalAmount)}
                                  className="rounded-lg bg-emerald-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                                >
                                  Simulasi Bayar
                                </button>
                                <button
                                  type="button"
                                  disabled={busyOrderId === ord.id}
                                  onClick={() => void handleCancelOrder(ord.id)}
                                  aria-label={`Batalkan order ${ord.orderCode}`}
                                  className="rounded-lg border border-slate-200 dark:border-slate-700 p-1 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                                >
                                  <XCircle className="h-3.5 w-3.5" aria-hidden="true" />
                                </button>
                              </>
                            )}
                            {ord.status === 'paid' && ord.deliveryPending && (
                              <button
                                type="button"
                                disabled={busyOrderId === ord.id}
                                onClick={() => void handleResendOrder(ord.id)}
                                className="inline-flex items-center gap-1 rounded-lg bg-sky-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-sky-700"
                              >
                                <Send className="h-3 w-3" aria-hidden="true" />
                                <span>Kirim Ulang</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )
        ) : mutations.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-500 dark:text-slate-400">
            Belum ada log mutasi GoPay Merchant yang diterima melalui webhook, polling API, atau simulasi.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-3 px-5">Waktu</th>
                  <th className="py-3 px-4">Ref &amp; Sumber</th>
                  <th className="py-3 px-4">Nominal</th>
                  <th className="py-3 px-4">Order Cocok</th>
                  <th className="py-3 px-5">Keterangan Mutasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {mutations.map((mut) => (
                  <tr key={mut.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                    <td className="py-3.5 px-5 font-mono text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {formatDateTime(mut.receivedAt)}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                        {mut.mutationRef}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {mut.source === 'webhook'
                          ? 'Webhook GoPay'
                          : mut.source === 'api_poll'
                            ? 'API Polling'
                            : 'Simulasi'}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums whitespace-nowrap">
                      {formatRupiah(mut.amount)}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {mut.matchedOrderCode ? (
                        <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                          {mut.matchedOrderCode}
                        </span>
                      ) : (
                        <span className="text-slate-500 dark:text-slate-400">Tidak ada</span>
                      )}
                    </td>
                    <td className="py-3.5 px-5 text-slate-600 dark:text-slate-300 max-w-md truncate">
                      {mut.rawSummary}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
