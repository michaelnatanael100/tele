-- ============================================================
-- TeleBalas Database SQL Export (MySQL / MariaDB / phpMyAdmin)
-- Generated at: 2026-11-26T02:48:08.372Z
-- Catatan: Sesi Telegram & PIN Admin tidak disertakan demi keamanan.
-- ============================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `telebalas_products` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `name` VARCHAR(120) NOT NULL,
  `category` VARCHAR(80) NOT NULL,
  `price` INT NOT NULL DEFAULT 0,
  `duration` VARCHAR(64) NOT NULL,
  `stock_status` VARCHAR(20) NOT NULL DEFAULT 'tersedia',
  `keywords` TEXT NOT NULL,
  `description` TEXT NOT NULL,
  `reply_template` TEXT NOT NULL,
  `auto_reply_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `hit_count` INT NOT NULL DEFAULT 0,
  `created_at` VARCHAR(40) NOT NULL,
  `updated_at` VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `telebalas_rules` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `name` VARCHAR(120) NOT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `match_type` VARCHAR(32) NOT NULL,
  `pattern` TEXT NOT NULL,
  `case_sensitive` TINYINT(1) NOT NULL DEFAULT 0,
  `chat_scope` VARCHAR(16) NOT NULL DEFAULT 'private',
  `reply_text` TEXT NOT NULL,
  `quote_original` TINYINT(1) NOT NULL DEFAULT 0,
  `delay_ms` INT NOT NULL DEFAULT 800,
  `cooldown_seconds` INT NOT NULL DEFAULT 60,
  `priority` INT NOT NULL DEFAULT 10,
  `hit_count` INT NOT NULL DEFAULT 0,
  `created_at` VARCHAR(40) NOT NULL,
  `updated_at` VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `telebalas_settings` (
  `setting_key` VARCHAR(64) NOT NULL PRIMARY KEY,
  `setting_json` LONGTEXT NOT NULL,
  `updated_at` VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELETE FROM `telebalas_products`;
INSERT INTO `telebalas_products` (`id`, `name`, `category`, `price`, `duration`, `stock_status`, `keywords`, `description`, `reply_template`, `auto_reply_enabled`, `hit_count`, `created_at`, `updated_at`) VALUES ('prod_netflix', 'Netflix Premium 4K', 'Streaming Video', 35000, '1 Bulan', 'tersedia', 'netflix, nf', 'Profil private 1P1U UHD 4K, support Smart TV/HP/Laptop, garansi penuh 30 hari.', 'Halo {nama}, detail produk *{produk}*:\n• Durasi: {durasi}\n• Harga: {harga}\n• Status: {stok}\n• Keterangan: {deskripsi}\n\nBalas "order netflix" jika ingin lanjut pembayaran.', 1, 13, '2026-11-26T01:57:05.625Z', '2026-11-26T02:39:17.110Z');
INSERT INTO `telebalas_products` (`id`, `name`, `category`, `price`, `duration`, `stock_status`, `keywords`, `description`, `reply_template`, `auto_reply_enabled`, `hit_count`, `created_at`, `updated_at`) VALUES ('prod_spotify', 'Spotify Premium Individual', 'Streaming Musik', 25000, '1 Bulan', 'tersedia', 'spotify, musik', 'Akun legal bebas iklan, bisa pakai akun lama atau akun baru, garansi full.', 'Halo {nama}, detail produk *{produk}*:\n• Durasi: {durasi}\n• Harga: {harga}\n• Status: {stok}\n• Keterangan: {deskripsi}\n\nBalas "order spotify" untuk melanjutkan pemesanan.', 1, 8, '2026-11-26T01:57:05.625Z', '2026-11-26T01:57:05.625Z');
INSERT INTO `telebalas_products` (`id`, `name`, `category`, `price`, `duration`, `stock_status`, `keywords`, `description`, `reply_template`, `auto_reply_enabled`, `hit_count`, `created_at`, `updated_at`) VALUES ('prod_canva', 'Canva Pro Education / Team', 'Desain & Produktivitas', 18000, '1 Tahun', 'terbatas', 'canva, desain', 'Invite langsung ke email pribadi Anda, akses semua aset Pro & Brand Kit.', 'Halo {nama}, detail produk *{produk}*:\n• Durasi: {durasi}\n• Harga: {harga}\n• Status: {stok}\n• Keterangan: {deskripsi}\n\nKirim email Anda untuk proses invite.', 1, 4, '2026-11-26T01:57:05.625Z', '2026-11-26T01:57:05.625Z');

REPLACE INTO `telebalas_settings` (`setting_key`, `setting_json`, `updated_at`) VALUES ('bot_settings', '{"botEnabled":true,"defaultReplyEnabled":true,"defaultReplyText":"Halo {nama}, terima kasih sudah menghubungi saya di Telegram. Pesan Anda (\\"{pesan}\\") sudah diterima pada pukul {waktu} WIB dan akan segera saya balas.\\n\\nBerikut katalog layanan yang tersedia saat ini:\\n{katalog}","ignoreGroupsByDefault":true,"ignoreContactsInWhitelistOnly":false,"whitelist":[],"blacklist":[],"defaultCooldownSeconds":60,"typingIndicator":true,"schedule":{"enabled":false,"startTime":"08:00","endTime":"21:00","timezoneOffsetMinutes":420}}', '2026-11-26T02:48:08.372Z');
