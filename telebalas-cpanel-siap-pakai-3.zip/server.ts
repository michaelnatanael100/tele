import 'dotenv/config';
import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {
  matchMessageToRules,
  validateProductAccountInput,
  validateProductInput,
  validateRuleInput,
} from './src/shared/autoReplyEngine';
import {
  extractMerchantNameFromQris,
  parseGoPayNotificationAmount,
  validateStaticQris,
} from './src/shared/qris';
import type {
  AutoReplyRule,
  BotSettings,
  ChatScope,
  MatchType,
  ProductAccountItem,
  ProductItem,
  ProductStockStatus,
} from './src/shared/types';
import {
  checkLoginRateLimit,
  claimInitialPin,
  clearLoginFailures,
  extractBearerToken,
  getAuthStatus,
  issueSessionToken,
  recordLoginFailure,
  requireAdminAuth,
  revokeBearerToken,
  updateAdminPin,
  verifyAdminPin,
  verifySessionToken,
} from './server/auth';
import {
  buildCpanelBundleZip,
  buildPhpWebInstaller,
  buildSanitizedDatabaseExport,
  generateSqlDump,
  validateRestorePayload,
} from './server/exporter';
import {
  cancelOrder,
  createQrisOrder,
  expireStaleOrders,
  pollGoPayMerchantMutations,
  processIncomingMutation,
  retryOrderDelivery,
  startPaymentWatchdog,
  validateMutationApiUrl,
} from './server/gopayMerchant';
import {
  appendLog,
  buildPublicGopayConfig,
  computeStats,
  loadStore,
  saveStore,
} from './server/store';
import { telegramManager } from './server/telegramManager';

const isProd = process.env.NODE_ENV === 'production';
const PORT = isProd && process.env.PORT ? Number(process.env.PORT) || 3000 : 3000;
const simCooldownMap = new Map<string, number>();

const VALID_MATCH_TYPES = new Set<MatchType>([
  'exact',
  'contains',
  'starts_with',
  'regex',
  'all_incoming',
]);
const VALID_SCOPES = new Set<ChatScope>(['private', 'group', 'all']);
const VALID_STOCK_STATUSES = new Set<ProductStockStatus>(['tersedia', 'terbatas', 'habis']);

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '256kb' }));

  // Load persisted store & start background watchdogs
  loadStore();
  void telegramManager.initFromSavedSession();
  startPaymentWatchdog();

  // --- Public 24/7 Keep-Alive & Health Endpoints (cPanel Cron Jobs) ---
  app.get(['/api/keepalive', '/api/health'], async (_req, res) => {
    try {
      await telegramManager.ensureConnected();
    } catch {
      // Keep-alive response should still succeed so cPanel Passenger stays awake
    }
    const store = loadStore();
    expireStaleOrders(store);
    if (
      store.gopayConfig.enabled &&
      store.gopayConfig.pollingEnabled &&
      store.gopayConfig.mutationApiUrl.trim() &&
      store.orders.some((o) => o.status === 'pending')
    ) {
      void pollGoPayMerchantMutations();
    }
    const account = telegramManager.getPublicAccount();
    res.json({
      ok: true,
      mode24x7: true,
      telegramStatus: account.status,
      botEnabled: store.settings.botEnabled,
      pendingOrdersCount: store.orders.filter((o) => o.status === 'pending').length,
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    });
  });

  // --- Public Admin PIN Auth Endpoints ---
  app.get('/api/auth/status', (req, res) => {
    const token = extractBearerToken(req);
    const check = token ? verifySessionToken(token) : { valid: false };
    res.json(getAuthStatus(check.valid));
  });

  app.post('/api/auth/setup', (req, res) => {
    const pin = typeof req.body?.pin === 'string' ? req.body.pin.trim() : '';
    const result = claimInitialPin(pin);
    if (!result.ok) {
      res.status(result.error?.includes('pernah') || result.error?.includes('environment') ? 409 : 400).json({
        error: result.error || 'Gagal membuat PIN admin.',
      });
      return;
    }

    const issued = issueSessionToken();
    res.status(201).json({
      token: issued.token,
      expiresAt: issued.expiresAt,
      status: getAuthStatus(true),
    });
  });

  app.post('/api/auth/login', (req, res) => {
    const rate = checkLoginRateLimit(req);
    if (rate.blocked) {
      res.status(429).json({
        error: `Terlalu banyak percobaan PIN gagal. Coba lagi dalam ${rate.retryAfterSec} detik.`,
      });
      return;
    }

    const authStatus = getAuthStatus(false);
    if (authStatus.needsSetup) {
      res.status(400).json({ error: 'PIN admin belum dibuat. Silakan buat PIN terlebih dahulu.' });
      return;
    }

    const pin = typeof req.body?.pin === 'string' ? req.body.pin.trim() : '';
    if (!verifyAdminPin(pin)) {
      recordLoginFailure(req);
      res.status(401).json({ error: 'PIN salah. Periksa kembali PIN admin Anda.' });
      return;
    }

    clearLoginFailures(req);
    const issued = issueSessionToken();
    res.json({
      token: issued.token,
      expiresAt: issued.expiresAt,
      status: getAuthStatus(true),
    });
  });

  app.post('/api/auth/logout', requireAdminAuth, (req, res) => {
    revokeBearerToken(req);
    res.json({ status: getAuthStatus(false) });
  });

  app.post('/api/auth/change-pin', requireAdminAuth, (req, res) => {
    const currentPin = typeof req.body?.currentPin === 'string' ? req.body.currentPin.trim() : '';
    const newPin = typeof req.body?.newPin === 'string' ? req.body.newPin.trim() : '';

    const result = updateAdminPin(currentPin, newPin);
    if (!result.ok) {
      res.status(400).json({ error: result.error || 'Gagal mengubah PIN.' });
      return;
    }

    revokeBearerToken(req);
    const issued = issueSessionToken();
    res.json({
      token: issued.token,
      expiresAt: issued.expiresAt,
      status: getAuthStatus(true),
    });
  });

  // --- Protected Admin State & Mutation Routes ---
  app.get('/api/state', requireAdminAuth, (_req, res) => {
    const store = loadStore();
    expireStaleOrders(store);
    res.json({
      rules: [...store.rules].sort((a, b) => a.priority - b.priority),
      products: store.products,
      settings: store.settings,
      account: telegramManager.getPublicAccount(),
      logs: store.logs,
      orders: store.orders,
      mutations: store.mutations,
      gopayConfig: buildPublicGopayConfig(store),
      stats: computeStats(store),
    });
  });

  app.post('/api/rules', requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const matchType: MatchType = VALID_MATCH_TYPES.has(body.matchType)
      ? body.matchType
      : 'contains';
    const pattern = typeof body.pattern === 'string' ? body.pattern.trim() : '';
    const caseSensitive = Boolean(body.caseSensitive);
    const chatScope: ChatScope = VALID_SCOPES.has(body.chatScope) ? body.chatScope : 'private';
    const replyText = typeof body.replyText === 'string' ? body.replyText.trim() : '';
    const quoteOriginal = Boolean(body.quoteOriginal);
    const delayMs = Number(body.delayMs ?? 800);
    const cooldownSeconds = Number(body.cooldownSeconds ?? 60);
    const priority = Number(body.priority ?? 10);
    const enabled = body.enabled !== undefined ? Boolean(body.enabled) : true;

    const validation = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority,
    });

    if (!validation.valid) {
      res.status(400).json({ error: 'Validasi aturan gagal.', errors: validation.errors });
      return;
    }

    const now = new Date().toISOString();
    const newRule: AutoReplyRule = {
      id: `rule_${crypto.randomUUID().slice(0, 8)}`,
      name,
      enabled,
      matchType,
      pattern: matchType === 'all_incoming' ? '' : pattern,
      caseSensitive,
      chatScope,
      replyText,
      quoteOriginal,
      delayMs,
      cooldownSeconds,
      priority,
      hitCount: 0,
      createdAt: now,
      updatedAt: now,
    };

    const store = loadStore();
    store.rules.push(newRule);
    saveStore(store);

    res.status(201).json({ rule: newRule, stats: computeStats(store) });
  });

  app.put('/api/rules/:id', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const existing = store.rules.find((r) => r.id === id);

    if (!existing) {
      res.status(404).json({ error: 'Aturan tidak ditemukan.' });
      return;
    }

    const body = req.body ?? {};
    const name = body.name !== undefined ? String(body.name).trim() : existing.name;
    const matchType: MatchType =
      body.matchType !== undefined && VALID_MATCH_TYPES.has(body.matchType)
        ? body.matchType
        : existing.matchType;
    const pattern = body.pattern !== undefined ? String(body.pattern).trim() : existing.pattern;
    const caseSensitive =
      body.caseSensitive !== undefined ? Boolean(body.caseSensitive) : existing.caseSensitive;
    const chatScope: ChatScope =
      body.chatScope !== undefined && VALID_SCOPES.has(body.chatScope)
        ? body.chatScope
        : existing.chatScope;
    const replyText =
      body.replyText !== undefined ? String(body.replyText).trim() : existing.replyText;
    const quoteOriginal =
      body.quoteOriginal !== undefined ? Boolean(body.quoteOriginal) : existing.quoteOriginal;
    const delayMs = body.delayMs !== undefined ? Number(body.delayMs) : existing.delayMs;
    const cooldownSeconds =
      body.cooldownSeconds !== undefined
        ? Number(body.cooldownSeconds)
        : existing.cooldownSeconds;
    const priority = body.priority !== undefined ? Number(body.priority) : existing.priority;
    const enabled = body.enabled !== undefined ? Boolean(body.enabled) : existing.enabled;

    const validation = validateRuleInput({
      name,
      matchType,
      pattern,
      replyText,
      delayMs,
      cooldownSeconds,
      priority,
    });

    if (!validation.valid) {
      res.status(400).json({ error: 'Validasi aturan gagal.', errors: validation.errors });
      return;
    }

    existing.name = name;
    existing.matchType = matchType;
    existing.pattern = matchType === 'all_incoming' ? '' : pattern;
    existing.caseSensitive = caseSensitive;
    existing.chatScope = chatScope;
    existing.replyText = replyText;
    existing.quoteOriginal = quoteOriginal;
    existing.delayMs = delayMs;
    existing.cooldownSeconds = cooldownSeconds;
    existing.priority = priority;
    existing.enabled = enabled;
    existing.updatedAt = new Date().toISOString();

    saveStore(store);
    res.json({ rule: existing, stats: computeStats(store) });
  });

  app.delete('/api/rules/:id', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const prevLen = store.rules.length;
    store.rules = store.rules.filter((r) => r.id !== id);
    if (store.rules.length === prevLen) {
      res.status(404).json({ error: 'Aturan tidak ditemukan.' });
      return;
    }
    saveStore(store);
    res.json({ deletedId: id, stats: computeStats(store) });
  });

  function sanitizeAccountsPayload(raw: unknown): ProductAccountItem[] | null {
    if (!Array.isArray(raw)) return null;
    const now = new Date().toISOString();
    const result: ProductAccountItem[] = [];
    for (const item of raw.slice(0, 500)) {
      if (!item || typeof item !== 'object') continue;
      const rec = item as Record<string, unknown>;
      const email = typeof rec.email === 'string' ? rec.email.trim().slice(0, 160) : '';
      const password = typeof rec.password === 'string' ? rec.password.trim().slice(0, 160) : '';
      const extraData = typeof rec.extraData === 'string' ? rec.extraData.trim().slice(0, 1000) : '';
      const check = validateProductAccountInput({ email, password, extraData });
      if (!check.valid) continue;
      const status =
        rec.status === 'reserved' || rec.status === 'sold' ? rec.status : 'available';
      result.push({
        id:
          typeof rec.id === 'string' && rec.id.trim()
            ? rec.id.trim().slice(0, 64)
            : `acc_${crypto.randomUUID().slice(0, 8)}`,
        email,
        password,
        extraData,
        status,
        soldToOrderId: typeof rec.soldToOrderId === 'string' ? rec.soldToOrderId : null,
        soldAt: typeof rec.soldAt === 'string' ? rec.soldAt : null,
        createdAt: typeof rec.createdAt === 'string' ? rec.createdAt : now,
      });
    }
    return result;
  }

  // --- Product Catalog CRUD ---
  app.post('/api/products', requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const category = typeof body.category === 'string' ? body.category.trim() : '';
    const price = Number(body.price ?? 0);
    const duration = typeof body.duration === 'string' ? body.duration.trim() : '';
    const stockStatus: ProductStockStatus = VALID_STOCK_STATUSES.has(body.stockStatus)
      ? body.stockStatus
      : 'tersedia';
    const keywords = typeof body.keywords === 'string' ? body.keywords.trim() : '';
    const description = typeof body.description === 'string' ? body.description.trim() : '';
    const replyTemplate = typeof body.replyTemplate === 'string' ? body.replyTemplate.trim() : '';
    const autoReplyEnabled =
      body.autoReplyEnabled !== undefined ? Boolean(body.autoReplyEnabled) : true;
    const accounts = sanitizeAccountsPayload(body.accounts) ?? [];

    const validation = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate,
    });

    if (!validation.valid) {
      res.status(400).json({ error: 'Validasi produk gagal.', errors: validation.errors });
      return;
    }

    const now = new Date().toISOString();
    const newProduct: ProductItem = {
      id: `prod_${crypto.randomUUID().slice(0, 8)}`,
      name,
      category,
      price: Math.round(price),
      duration,
      stockStatus,
      keywords,
      description,
      replyTemplate,
      autoReplyEnabled,
      accounts,
      hitCount: 0,
      createdAt: now,
      updatedAt: now,
    };

    const store = loadStore();
    store.products.push(newProduct);
    saveStore(store);

    res.status(201).json({ product: newProduct, stats: computeStats(store) });
  });

  app.put('/api/products/:id', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const existing = store.products.find((p) => p.id === id);

    if (!existing) {
      res.status(404).json({ error: 'Produk tidak ditemukan.' });
      return;
    }

    const body = req.body ?? {};
    const name = body.name !== undefined ? String(body.name).trim() : existing.name;
    const category =
      body.category !== undefined ? String(body.category).trim() : existing.category;
    const price = body.price !== undefined ? Number(body.price) : existing.price;
    const duration =
      body.duration !== undefined ? String(body.duration).trim() : existing.duration;
    const stockStatus: ProductStockStatus =
      body.stockStatus !== undefined && VALID_STOCK_STATUSES.has(body.stockStatus)
        ? body.stockStatus
        : existing.stockStatus;
    const keywords =
      body.keywords !== undefined ? String(body.keywords).trim() : existing.keywords;
    const description =
      body.description !== undefined ? String(body.description).trim() : existing.description;
    const replyTemplate =
      body.replyTemplate !== undefined ? String(body.replyTemplate).trim() : existing.replyTemplate;
    const autoReplyEnabled =
      body.autoReplyEnabled !== undefined
        ? Boolean(body.autoReplyEnabled)
        : existing.autoReplyEnabled;
    const parsedAccounts = sanitizeAccountsPayload(body.accounts);

    const validation = validateProductInput({
      name,
      category,
      price,
      duration,
      keywords,
      replyTemplate,
    });

    if (!validation.valid) {
      res.status(400).json({ error: 'Validasi produk gagal.', errors: validation.errors });
      return;
    }

    existing.name = name;
    existing.category = category;
    existing.price = Math.round(price);
    existing.duration = duration;
    existing.stockStatus = stockStatus;
    existing.keywords = keywords;
    existing.description = description;
    existing.replyTemplate = replyTemplate;
    existing.autoReplyEnabled = autoReplyEnabled;
    if (parsedAccounts !== null) {
      existing.accounts = parsedAccounts;
    }
    existing.updatedAt = new Date().toISOString();

    saveStore(store);
    res.json({ product: existing, stats: computeStats(store) });
  });

  app.delete('/api/products/:id', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const prevLen = store.products.length;
    store.products = store.products.filter((p) => p.id !== id);
    if (store.products.length === prevLen) {
      res.status(404).json({ error: 'Produk tidak ditemukan.' });
      return;
    }
    saveStore(store);
    res.json({ deletedId: id, stats: computeStats(store) });
  });

  app.post('/api/products/:id/accounts', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    const product = store.products.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: 'Produk tidak ditemukan.' });
      return;
    }

    const items = Array.isArray(req.body?.accounts) ? req.body.accounts : [req.body];
    const now = new Date().toISOString();
    const added: ProductAccountItem[] = [];

    for (const raw of items.slice(0, 200)) {
      if (!raw || typeof raw !== 'object') continue;
      const rec = raw as Record<string, unknown>;
      const email = typeof rec.email === 'string' ? rec.email.trim() : '';
      const password = typeof rec.password === 'string' ? rec.password.trim() : '';
      const extraData = typeof rec.extraData === 'string' ? rec.extraData.trim() : '';
      const check = validateProductAccountInput({ email, password, extraData });
      if (!check.valid) {
        res.status(400).json({ error: Object.values(check.errors)[0] || 'Data akun tidak valid.' });
        return;
      }
      added.push({
        id: `acc_${crypto.randomUUID().slice(0, 8)}`,
        email: email.slice(0, 160),
        password: password.slice(0, 160),
        extraData: extraData.slice(0, 1000),
        status: 'available',
        soldToOrderId: null,
        soldAt: null,
        createdAt: now,
      });
    }

    if (added.length === 0) {
      res.status(400).json({ error: 'Minimal satu data akun wajib diisi.' });
      return;
    }

    product.accounts = [...(product.accounts ?? []), ...added].slice(0, 500);
    if (product.stockStatus === 'habis') {
      product.stockStatus = 'tersedia';
    }
    product.updatedAt = now;
    saveStore(store);

    res.status(201).json({ product, addedCount: added.length, stats: computeStats(store) });
  });

  app.delete('/api/products/:id/accounts/:accountId', requireAdminAuth, (req, res) => {
    const { id, accountId } = req.params;
    const store = loadStore();
    const product = store.products.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: 'Produk tidak ditemukan.' });
      return;
    }
    const prevLen = (product.accounts ?? []).length;
    product.accounts = (product.accounts ?? []).filter((a) => a.id !== accountId);
    if (product.accounts.length === prevLen) {
      res.status(404).json({ error: 'Data akun tidak ditemukan.' });
      return;
    }
    product.updatedAt = new Date().toISOString();
    saveStore(store);
    res.json({ product, stats: computeStats(store) });
  });

  // --- GoPay Merchant QRIS Payment Gateway Routes ---
  app.put('/api/payment/gopay/config', requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const store = loadStore();
    const cur = store.gopayConfig;

    const nextStaticQris =
      typeof body.staticQris === 'string' ? body.staticQris.trim() : cur.staticQris;
    const qrisCheck = validateStaticQris(nextStaticQris);
    if (!qrisCheck.valid) {
      res.status(400).json({ error: qrisCheck.error || 'Format QRIS Statis tidak valid.' });
      return;
    }

    const nextUrl =
      typeof body.mutationApiUrl === 'string' ? body.mutationApiUrl.trim() : cur.mutationApiUrl;
    const urlCheck = validateMutationApiUrl(nextUrl);
    if (!urlCheck.valid) {
      res.status(400).json({ error: urlCheck.error || 'URL API Mutasi tidak valid.' });
      return;
    }

    const nextMerchantName =
      typeof body.merchantName === 'string' && body.merchantName.trim()
        ? body.merchantName.trim().slice(0, 60)
        : extractMerchantNameFromQris(nextStaticQris) || cur.merchantName;

    let nextApiToken = cur.apiToken;
    if (body.clearApiToken === true) {
      nextApiToken = '';
    } else if (typeof body.apiToken === 'string' && body.apiToken.trim()) {
      nextApiToken = body.apiToken.trim().slice(0, 500);
    }

    let nextWebhookSecret = cur.webhookSecret;
    if (typeof body.webhookSecret === 'string' && body.webhookSecret.trim()) {
      if (body.webhookSecret.trim().length < 12) {
        res.status(400).json({ error: 'Webhook secret minimal 12 karakter.' });
        return;
      }
      nextWebhookSecret = body.webhookSecret.trim().slice(0, 200);
    }

    store.gopayConfig = {
      ...cur,
      enabled: body.enabled !== undefined ? Boolean(body.enabled) : cur.enabled,
      merchantName: nextMerchantName,
      staticQris: nextStaticQris,
      mutationApiUrl: nextUrl,
      apiToken: nextApiToken,
      webhookSecret: nextWebhookSecret,
      pollingEnabled:
        body.pollingEnabled !== undefined ? Boolean(body.pollingEnabled) : cur.pollingEnabled,
      pollIntervalSeconds: Math.max(
        10,
        Math.min(300, Number(body.pollIntervalSeconds ?? cur.pollIntervalSeconds) || 20)
      ),
      orderExpiryMinutes: Math.max(
        3,
        Math.min(180, Number(body.orderExpiryMinutes ?? cur.orderExpiryMinutes) || 15)
      ),
    };
    saveStore(store);

    res.json({
      gopayConfig: buildPublicGopayConfig(store),
      stats: computeStats(store),
    });
  });

  app.post('/api/payment/gopay/rotate-secret', requireAdminAuth, (_req, res) => {
    const store = loadStore();
    const newSecret = crypto.randomBytes(24).toString('hex');
    store.gopayConfig.webhookSecret = newSecret;
    saveStore(store);
    res.json({
      gopayConfig: buildPublicGopayConfig(store),
      plainWebhookSecret: newSecret,
    });
  });

  app.post('/api/payment/gopay/poll-now', requireAdminAuth, async (_req, res) => {
    const result = await pollGoPayMerchantMutations();
    const store = loadStore();
    res.json({
      result,
      gopayConfig: buildPublicGopayConfig(store),
      orders: store.orders,
      mutations: store.mutations,
      products: store.products,
      stats: computeStats(store),
    });
  });

  app.post('/api/payment/gopay/test-order', requireAdminAuth, async (req, res) => {
    const productId = typeof req.body?.productId === 'string' ? req.body.productId.trim() : '';
    const buyerName =
      typeof req.body?.buyerName === 'string' && req.body.buyerName.trim()
        ? req.body.buyerName.trim().slice(0, 60)
        : 'Pembeli Simulasi';

    if (!productId) {
      res.status(400).json({ error: 'Pilih produk terlebih dahulu.' });
      return;
    }

    const result = await createQrisOrder({
      productId,
      buyerChatId: 'sim_checkout',
      buyerSenderId: 'sim_checkout',
      buyerName,
      buyerUsername: 'pembeli_uji',
      source: 'simulator',
    });

    if (!result.ok || !result.order) {
      res.status(400).json({ error: result.error || 'Gagal membuat invoice QRIS.' });
      return;
    }

    const store = loadStore();
    res.status(201).json({
      order: result.order,
      qrDataUrl: result.qrDataUrl,
      invoiceCaption: result.invoiceCaption,
      orders: store.orders,
      products: store.products,
      stats: computeStats(store),
    });
  });

  app.post('/api/payment/gopay/simulate-mutation', requireAdminAuth, async (req, res) => {
    const rawAmount = req.body?.amount;
    const rawText = typeof req.body?.notificationText === 'string' ? req.body.notificationText : '';
    const amount =
      typeof rawAmount === 'number' && Number.isFinite(rawAmount) && rawAmount > 0
        ? Math.round(rawAmount)
        : parseGoPayNotificationAmount(rawText);

    if (!amount || amount <= 0) {
      res.status(400).json({ error: 'Nominal mutasi harus lebih dari Rp 0.' });
      return;
    }

    const senderName =
      typeof req.body?.senderName === 'string' && req.body.senderName.trim()
        ? req.body.senderName.trim().slice(0, 60)
        : 'GoPay Customer';

    const outcome = await processIncomingMutation({
      amount,
      source: 'simulation',
      senderName,
      rawSummary: rawText.trim() || `Simulasi mutasi GoPay Merchant masuk Rp ${amount.toLocaleString('id-ID')}`,
    });

    const store = loadStore();
    res.json({
      outcome,
      orders: store.orders,
      mutations: store.mutations,
      products: store.products,
      logs: store.logs,
      stats: computeStats(store),
    });
  });

  app.post('/api/payment/orders/:id/cancel', requireAdminAuth, (req, res) => {
    const result = cancelOrder(req.params.id);
    if (!result.ok) {
      res.status(400).json({ error: result.error || 'Gagal membatalkan order.' });
      return;
    }
    const store = loadStore();
    res.json({
      order: result.order,
      orders: store.orders,
      products: store.products,
      stats: computeStats(store),
    });
  });

  app.post('/api/payment/orders/:id/resend', requireAdminAuth, async (req, res) => {
    const result = await retryOrderDelivery(req.params.id);
    if (!result.ok) {
      res.status(400).json({ error: result.error || 'Gagal mengirim ulang detail akun.' });
      return;
    }
    const store = loadStore();
    res.json({
      order: result.order,
      orders: store.orders,
      logs: store.logs,
      stats: computeStats(store),
    });
  });

  // Public Authenticated GoPay Merchant Webhook Receiver (e.g. GoBiz / MacroDroid / AutoNotification)
  app.post('/api/payment/gopay/webhook', async (req, res) => {
    const store = loadStore();
    const expectedSecret = store.gopayConfig.webhookSecret?.trim() ?? '';
    if (!expectedSecret) {
      res.status(403).json({ error: 'Webhook secret belum dikonfigurasi pada server.' });
      return;
    }

    const authHeader = req.header('authorization');
    const bearerSecret =
      authHeader && authHeader.toLowerCase().startsWith('bearer ')
        ? authHeader.slice(7).trim()
        : '';
    const headerSecret = (req.header('x-webhook-secret') || '').trim();
    const suppliedSecret = bearerSecret || headerSecret;

    const expectedDigest = crypto.createHash('sha256').update(expectedSecret).digest();
    const suppliedDigest = crypto.createHash('sha256').update(suppliedSecret).digest();

    if (!suppliedSecret || !crypto.timingSafeEqual(expectedDigest, suppliedDigest)) {
      res.status(401).json({ error: 'Webhook secret tidak valid.' });
      return;
    }

    const body = (req.body && typeof req.body === 'object' ? req.body : {}) as Record<
      string,
      unknown
    >;

    const txType = String(body.type ?? body.mutation_type ?? body.direction ?? '').toLowerCase();
    if (txType === 'db' || txType === 'debit' || txType === 'out') {
      res.json({ ok: true, ignored: true, reason: 'Mutasi keluar/debit diabaikan.' });
      return;
    }

    let amount: number | null = null;
    for (const candidate of [body.amount, body.nominal, body.gross_amount, body.credit]) {
      if (typeof candidate === 'number' && Number.isFinite(candidate) && candidate > 0) {
        amount = Math.round(candidate);
        break;
      }
      if (typeof candidate === 'string' && candidate.trim()) {
        const parsed = parseGoPayNotificationAmount(`Rp ${candidate.trim()}`);
        if (parsed) {
          amount = parsed;
          break;
        }
      }
    }

    const notifText =
      typeof body.text === 'string'
        ? body.text
        : typeof body.message === 'string'
          ? body.message
          : typeof body.notification === 'string'
            ? body.notification
            : typeof body.title === 'string'
              ? body.title
              : '';

    if (!amount && notifText) {
      amount = parseGoPayNotificationAmount(notifText);
    }

    if (!amount || amount <= 0) {
      res.status(400).json({ error: 'Nominal mutasi GoPay tidak terbaca dari payload webhook.' });
      return;
    }

    const refRaw = body.mutation_id ?? body.transaction_id ?? body.reference_id ?? body.id;
    const senderName =
      typeof body.sender_name === 'string'
        ? body.sender_name
        : typeof body.customer_name === 'string'
          ? body.customer_name
          : null;

    const outcome = await processIncomingMutation({
      amount,
      mutationRef: refRaw ? String(refRaw) : undefined,
      source: 'webhook',
      senderName,
      rawSummary: notifText || `Webhook GoPay masuk Rp ${amount.toLocaleString('id-ID')}`,
    });

    res.json({
      ok: true,
      matched: outcome.matched,
      duplicate: outcome.duplicate,
      orderCode: outcome.order?.orderCode ?? null,
    });
  });

  app.put('/api/settings', requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const store = loadStore();
    const cur = store.settings;

    const nextSettings: BotSettings = {
      botEnabled: body.botEnabled !== undefined ? Boolean(body.botEnabled) : cur.botEnabled,
      defaultReplyEnabled:
        body.defaultReplyEnabled !== undefined
          ? Boolean(body.defaultReplyEnabled)
          : cur.defaultReplyEnabled,
      defaultReplyText:
        typeof body.defaultReplyText === 'string'
          ? body.defaultReplyText.trim().slice(0, 4000)
          : cur.defaultReplyText,
      ignoreGroupsByDefault:
        body.ignoreGroupsByDefault !== undefined
          ? Boolean(body.ignoreGroupsByDefault)
          : cur.ignoreGroupsByDefault,
      ignoreContactsInWhitelistOnly:
        body.ignoreContactsInWhitelistOnly !== undefined
          ? Boolean(body.ignoreContactsInWhitelistOnly)
          : cur.ignoreContactsInWhitelistOnly,
      whitelist: Array.isArray(body.whitelist)
        ? body.whitelist.map((s: unknown) => String(s).trim()).filter(Boolean).slice(0, 200)
        : cur.whitelist,
      blacklist: Array.isArray(body.blacklist)
        ? body.blacklist.map((s: unknown) => String(s).trim()).filter(Boolean).slice(0, 200)
        : cur.blacklist,
      defaultCooldownSeconds:
        body.defaultCooldownSeconds !== undefined
          ? Math.max(0, Math.min(86400, Number(body.defaultCooldownSeconds) || 0))
          : cur.defaultCooldownSeconds,
      typingIndicator:
        body.typingIndicator !== undefined ? Boolean(body.typingIndicator) : cur.typingIndicator,
      schedule: {
        enabled:
          body.schedule?.enabled !== undefined
            ? Boolean(body.schedule.enabled)
            : cur.schedule.enabled,
        startTime:
          typeof body.schedule?.startTime === 'string' &&
          /^([01]\d|2[0-3]):([0-5]\d)$/.test(body.schedule.startTime)
            ? body.schedule.startTime
            : cur.schedule.startTime,
        endTime:
          typeof body.schedule?.endTime === 'string' &&
          /^([01]\d|2[0-3]):([0-5]\d)$/.test(body.schedule.endTime)
            ? body.schedule.endTime
            : cur.schedule.endTime,
        timezoneOffsetMinutes:
          body.schedule?.timezoneOffsetMinutes !== undefined &&
          Number.isFinite(Number(body.schedule.timezoneOffsetMinutes))
            ? Number(body.schedule.timezoneOffsetMinutes)
            : cur.schedule.timezoneOffsetMinutes,
      },
    };

    store.settings = nextSettings;
    saveStore(store);
    res.json({ settings: nextSettings, stats: computeStats(store) });
  });

  app.post('/api/simulate', requireAdminAuth, (req, res) => {
    const body = req.body ?? {};
    const senderName =
      typeof body.senderName === 'string' && body.senderName.trim()
        ? body.senderName.trim().slice(0, 80)
        : 'Pengguna Uji';
    const senderUsername =
      typeof body.senderUsername === 'string' && body.senderUsername.trim()
        ? body.senderUsername.trim().slice(0, 60)
        : null;
    const chatType = body.chatType === 'group' ? 'group' : 'private';
    const text = typeof body.text === 'string' ? body.text.trim() : '';
    const ignoreConstraints = Boolean(body.ignoreConstraints);

    if (!text) {
      res.status(400).json({ error: 'Isi pesan uji wajib diisi.' });
      return;
    }

    const store = loadStore();
    const senderId = `sim_${senderUsername || senderName.toLowerCase().replace(/\s+/g, '_')}`;
    const evaluation = matchMessageToRules(
      {
        senderId,
        senderName,
        senderUsername,
        chatId: senderId,
        chatType,
        text,
      },
      store.rules,
      store.settings,
      simCooldownMap,
      new Date(),
      { ignoreScheduleAndCooldown: ignoreConstraints },
      store.products
    );

    if (evaluation.shouldReply && evaluation.cooldownKey && !ignoreConstraints) {
      simCooldownMap.set(evaluation.cooldownKey, Date.now());
    }

    const matchedLabel = evaluation.matchedRule
      ? evaluation.matchedRule.name
      : evaluation.matchedProduct
        ? `Produk: ${evaluation.matchedProduct.name}`
        : evaluation.matchedDefaultReply
          ? 'Balasan Default (Semua Pesan)'
          : null;

    const logEntry = appendLog({
      senderId,
      senderName,
      senderUsername,
      chatType,
      incomingText: text.slice(0, 300),
      matchedRuleId:
        evaluation.matchedRule?.id ??
        evaluation.matchedProduct?.id ??
        (evaluation.matchedDefaultReply ? 'default_reply' : null),
      matchedRuleName: matchedLabel,
      replyText: evaluation.renderedReply,
      outcome: evaluation.shouldReply ? 'simulated' : 'skipped',
      reason: evaluation.reason,
    });

    res.json({
      evaluation,
      logEntry,
      stats: computeStats(loadStore()),
    });
  });

  app.post('/api/logs/clear', requireAdminAuth, (_req, res) => {
    const store = loadStore();
    store.logs = [];
    saveStore(store);
    res.json({ logs: [], stats: computeStats(store) });
  });

  // Telegram MTProto Authentication Endpoints (Protected)
  app.post('/api/telegram/login/start', requireAdminAuth, async (req, res) => {
    const body = req.body ?? {};
    const apiId = Number(body.apiId);
    const apiHash = typeof body.apiHash === 'string' ? body.apiHash.trim() : '';
    const phoneNumber = typeof body.phoneNumber === 'string' ? body.phoneNumber.trim() : '';

    if (!Number.isInteger(apiId) || apiId <= 0) {
      res.status(400).json({ error: 'API ID harus berupa angka positif dari my.telegram.org.' });
      return;
    }
    if (!/^[a-fA-F0-9]{16,64}$/.test(apiHash)) {
      res.status(400).json({ error: 'Format API Hash tidak valid.' });
      return;
    }
    if (!/^\+?\d{8,16}$/.test(phoneNumber.replace(/[\s-]/g, ''))) {
      res
        .status(400)
        .json({ error: 'Nomor telepon harus diawali kode negara, misal +628123456789.' });
      return;
    }

    try {
      const account = await telegramManager.startPhoneLogin({
        apiId,
        apiHash,
        phoneNumber: phoneNumber.replace(/[\s-]/g, ''),
      });
      res.json({ account });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Gagal memulai login Telegram.',
        account: telegramManager.getPublicAccount(),
      });
    }
  });

  app.post('/api/telegram/login/verify-code', requireAdminAuth, async (req, res) => {
    const code = typeof req.body?.code === 'string' ? req.body.code.trim() : '';
    if (!/^\d{4,8}$/.test(code)) {
      res.status(400).json({ error: 'Kode verifikasi OTP Telegram harus berupa angka 4–8 digit.' });
      return;
    }

    try {
      const account = await telegramManager.submitOtpCode(code);
      res.json({ account });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Verifikasi OTP gagal.',
        account: telegramManager.getPublicAccount(),
      });
    }
  });

  app.post('/api/telegram/login/verify-password', requireAdminAuth, async (req, res) => {
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!password) {
      res.status(400).json({ error: 'Kata sandi 2FA wajib diisi.' });
      return;
    }

    try {
      const account = await telegramManager.submitTwoFactorPassword(password);
      res.json({ account });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Verifikasi kata sandi 2FA gagal.',
        account: telegramManager.getPublicAccount(),
      });
    }
  });

  app.post('/api/telegram/login/session', requireAdminAuth, async (req, res) => {
    const body = req.body ?? {};
    const apiId = Number(body.apiId);
    const apiHash = typeof body.apiHash === 'string' ? body.apiHash.trim() : '';
    const sessionString =
      typeof body.sessionString === 'string' ? body.sessionString.trim() : '';

    if (!Number.isInteger(apiId) || apiId <= 0) {
      res.status(400).json({ error: 'API ID harus berupa angka positif.' });
      return;
    }
    if (!/^[a-fA-F0-9]{16,64}$/.test(apiHash)) {
      res.status(400).json({ error: 'Format API Hash tidak valid.' });
      return;
    }
    if (sessionString.length < 32) {
      res.status(400).json({ error: 'StringSession terlalu pendek atau tidak valid.' });
      return;
    }

    const account = await telegramManager.connectClientWithSession(apiId, apiHash, sessionString);
    if (account.status === 'error') {
      res.status(400).json({ error: account.errorMessage || 'Gagal terhubung.', account });
      return;
    }
    res.json({ account });
  });

  app.post('/api/telegram/disconnect', requireAdminAuth, async (_req, res) => {
    const account = await telegramManager.disconnectOnly();
    res.json({ account });
  });

  app.post('/api/telegram/logout', requireAdminAuth, async (_req, res) => {
    const account = await telegramManager.logoutAndClearSession();
    res.json({ account });
  });

  // --- Protected Backup, Database Export & cPanel Bundle Installer Routes ---
  app.get('/api/export/database.json', requireAdminAuth, (req, res) => {
    const includeLogs = req.query.includeLogs !== 'false';
    const store = loadStore();
    const sanitized = buildSanitizedDatabaseExport(store, includeLogs);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="telebalas-database.json"');
    res.send(JSON.stringify(sanitized, null, 2));
  });

  app.get('/api/export/database.sql', requireAdminAuth, (_req, res) => {
    const store = loadStore();
    const sql = generateSqlDump(store);
    res.setHeader('Content-Type', 'application/sql; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="telebalas-database.sql"');
    res.send(sql);
  });

  app.get('/api/export/install.php', requireAdminAuth, (_req, res) => {
    const phpInstaller = buildPhpWebInstaller();
    res.setHeader('Content-Type', 'application/x-httpd-php; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="install.php"');
    res.send(phpInstaller);
  });

  app.get('/api/export/bundle', requireAdminAuth, async (req, res) => {
    try {
      const includeLogs = req.query.includeLogs !== 'false';
      const store = loadStore();
      const zipBuffer = await buildCpanelBundleZip(store, includeLogs);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="telebalas-cpanel-siap-pakai.zip"'
      );
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Gagal membuat paket cPanel ZIP.',
      });
    }
  });

  app.post('/api/export/restore-database', requireAdminAuth, (req, res) => {
    const check = validateRestorePayload(req.body);
    if (!check.ok || !check.data) {
      res.status(400).json({ error: check.error || 'Data database tidak valid.' });
      return;
    }

    const store = loadStore();
    store.rules = check.data.rules;
    store.products = check.data.products;
    store.settings = check.data.settings;
    if (check.data.logs) {
      store.logs = check.data.logs;
    }
    saveStore(store);

    res.json({
      stats: computeStats(store),
      restoredRulesCount: store.rules.length,
      restoredProductsCount: store.products.length,
    });
  });

  // Vite middleware in development, static dist in production
  const distPath = path.resolve(process.cwd(), 'dist');

  if (!isProd || !fs.existsSync(distPath)) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const inPassenger = Boolean(
    process.env.PASSENGER_APP_ENV ||
      process.env.IN_PASSENGER ||
      process.env.PASSENGER_BASE_URI
  );

  if (inPassenger) {
    app.listen(PORT, () => {
      console.log(`TeleBalas server running under Phusion Passenger on port ${PORT}`);
    });
  } else {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`TeleBalas server running on http://0.0.0.0:${PORT}`);
    });
  }
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
